#include <bits/stdc++.h>

using namespace std;

int n,m,k,b;
vector<int> A[500000],L[500000],R[500000],U[500000],D[500000];
vector<pair<int,pair<int,int>>> V;
stack<int> S;

int main()
{
    scanf("%d %d %d",&n,&m,&k);
    for(int i=1; i<=n; i++)
    {
        A[i].push_back(0);
        for(int j=1; j<=m; j++)
        {
            scanf("%d",&b);
            A[i].push_back(b);
            V.push_back({A[i][j],{i,j}});
        }
    }
    for(int i=1; i<=n; i++)
    {
        L[i] = vector<int>(m+1,0);
        R[i] = vector<int>(m+1,0);
        U[i] = vector<int>(m+1,0);
        D[i] = vector<int>(m+1,0);
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=m; j++)
        {
            while(!S.empty())
            {
                if(A[i][S.top()]<=A[i][j]) S.pop();
                break;
            }
            if(S.empty()) L[i][j] = 0;
            else L[i][j] = S.top();
            S.push(j);
        }
        while(!S.empty()) S.pop();
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=m; j>=1; j--)
        {
            while(!S.empty())
            {
                if(A[i][S.top()]<=A[i][j]) S.pop();
                break;
            }
            if(S.empty()) R[i][j] = 0;
            else R[i][j] = S.top();
            S.push(j);
        }
        while(!S.empty()) S.pop();
    }
    for(int i=1; i<=m; i++)
    {
        for(int j=1; j<=n; j++)
        {
            while(!S.empty())
            {
                if(A[S.top()][i]<=A[j][i]) S.pop();
                break;
            }
            if(S.empty()) U[j][i] = 0;
            else U[j][i] = S.top();
            S.push(j);
        }
        while(!S.empty()) S.pop();
    }
    for(int i=1; i<=m; i++)
    {
        for(int j=n; j>=1; j--)
        {
            while(!S.empty())
            {
                if(A[S.top()][i]<=A[j][i]) S.pop();
                break;
            }
            if(S.empty()) D[j][i] = 0;
            else D[j][i] = S.top();
            S.push(j);
        }
        while(!S.empty()) S.pop();
    }
    sort(V.rbegin(),V.rend());
    int l=-1,r=1e9+1;
    while(l+1<r)
    {
        int s = (l+r)/2;
        b = k;
        bool p = 0;
        for(int i=0; i<V.size(); i++)
        {
            int ci=V[i].second.first,cj=V[i].second.second;
            bool f = 0;
            if(L[ci][cj] && A[ci][L[ci][cj]]-s<=A[ci][cj]) f = 1;
            if(R[ci][cj] && A[ci][R[ci][cj]]-s<=A[ci][cj]) f = 1;
            if(U[ci][cj] && A[U[ci][cj]][cj]-s<=A[ci][cj]) f = 1;
            if(D[ci][cj] && A[D[ci][cj]][cj]-s<=A[ci][cj]) f = 1;
            if(f) continue;
            if(!b)
            {
                p = 1;
                break;
            }
            b--;
        }
        if(p) l = s;
        else r = s;
    }
    if(r==1e9+1) r = -1;
    printf("%d\n",r);
    if(r==-1) return 0;
    b = k;
    for(int i=0; i<V.size(); i++)
    {
        int ci=V[i].second.first,cj=V[i].second.second;
        bool f = 0;
        if(L[ci][cj] && A[ci][L[ci][cj]]-r<=A[ci][cj]) f = 1;
        if(R[ci][cj] && A[ci][R[ci][cj]]-r<=A[ci][cj]) f = 1;
        if(U[ci][cj] && A[U[ci][cj]][cj]-r<=A[ci][cj]) f = 1;
        if(D[ci][cj] && A[D[ci][cj]][cj]-r<=A[ci][cj]) f = 1;
        if(f) continue;
        b--;
        printf("%d %d\n",ci,cj);
    }
    while(b--) printf("1 1\n");
    return 0;
}
