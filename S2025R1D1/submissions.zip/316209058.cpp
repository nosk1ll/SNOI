#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 5e5 + 3;
const int inf = 1e9;
int lf[N], up[N], dw[N], rg[N];
vector<pair<int, int>> res;

const int POM[4][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

void solve() {
    int n, m, k; cin >> n >> m >> k;
    for (int i = 0; i < N; i++) {
        lf[i] = inf; up[i] = inf; dw[i] = inf; rg[i] = inf;
    }
    vector<vector<int>> a(n+3, vector<int>(m+3));
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> a[i][j];

    for (int i = 1; i <= n; i++) {
        set<int> st;
        for (int j = 1; j <= m; j++) {
            auto it = st.lower_bound(a[i][j]);
            if (it != st.begin()) {
                int x = *prev(it);
                rg[x] = a[i][j];
            }
            st.insert(a[i][j]);
        }
    }
    for (int i = 1; i <= n; i++) {
        set<int> st;
        for (int j = m; j >= 1; j--) {
            auto it = st.lower_bound(a[i][j]);
            if (it != st.begin()) {
                int x = *prev(it);
                lf[x] = a[i][j];
            }
            st.insert(a[i][j]);
        }
    }
    for (int j = 1; j <= m; j++) {
        set<int> st;
        for (int i = 1; i <= n; i++) {
            auto it = st.lower_bound(a[i][j]);
            if (it != st.begin()) {
                int x = *prev(it);
                dw[x] = a[i][j];
            }
            st.insert(a[i][j]);
        }
    }
    for (int j = 1; j <= m; j++) {
        set<int> st;
        for (int i = n; i >= 1; i--) {
            auto it = st.lower_bound(a[i][j]);
            if (it != st.begin()) {
                int x = *prev(it);
                up[x] = a[i][j];
            }
            st.insert(a[i][j]);
        }
    }

    auto moze = [&](int d) {
        vector<vector<bool>> vis(n+3, vector<bool>(m+3));
        vector<pair<int, int>> ans;
        priority_queue<tuple<int, int, int>> pq;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                pq.emplace(a[i][j], i, j);
        int can = k;
        while (!pq.empty()) {
            auto [w, i, j] = pq.top(); pq.pop();
            bool ima = false;
            //dbg(w, lf[w], rg[w], up[w], dw[w]);
            if (rg[w]-d <= w || up[w]-d <= w || dw[w]-d <= w || lf[w]-d <= w)
                ima = true;

            if (ima) {
                continue;
            }
            //dbg(i, j);
            can--;
            ans.push_back({i, j});
        }

        if (can < 0) return false;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                if (can > 0) ans.push_back({i, j}), can--;

        res = ans;
        return true;
    };
    //dbg(moze(1));
    int low = 0, high = n*m;
    while (low < high) {
        int mid = (low + high) / 2;
        if (moze(mid))
            high = mid;
        else
            low = mid+1;
    }
    if (!moze(low)) {
        cout << -1 << "\n"; return;
    }

    cout << low << "\n";
    for (auto [x, y] : res)
        cout << x << " " << y << "\n";
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}
