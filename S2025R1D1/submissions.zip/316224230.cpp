#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
void Unique(vector<ll>&a){sort(a.begin(),a.end());int m=unique(a.begin(),a.end())-a.begin();a.resize(m);}
ll Bin(ll a,ll b){
	ll res=1;
	for(ll i=a;i>=a-b+1;i--) res*=i;
	for(ll i=1;i<=b;i++) res/=i;
	return res;
}
void Sredi(vector<pair<int,int>>&res){
	int n=1;
	for(auto [i,j]:res) n=max({n,i,j});
	bool was[n+10][n+10];memset(was,0,sizeof(was));
	vector<pair<int,int>>res1;
	for(auto [i,j]:res){
		if(!was[i][j]) res1.pb({i,j});
		was[i][j]=true;
	}
	res=res1;
	was[1][1]=true;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(!was[i][j]) res.pb({i,j});
		}
	}
}
void Ispis(vector<pair<int,int>>res){
	int n=1;
	for(auto [i,j]:res) n=max({n,i,j});
	printf("%i\n",n);
	for(auto [i,j]:res) printf("%i %i\n",i,j);
}
ll Check(vector<pair<int,int>>res){
	int n=1;for(auto [i,j]:res) n=max({n,i,j});
	ll dp[n+10][n+10];memset(dp,0,sizeof(dp));dp[1][1]=1;
	for(auto [i,j]:res){
		printf("%i %i:\n",i,j);
		dp[i][j]=dp[i-1][j]+dp[i][j-1];
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				printf("%i ",dp[i][j]);
			}
			printf("\n");
		}
	}
	return dp[n][n];
}
int main(){
	/*vector<ll>c;
    for(int n=3;n<=3;n++){
		vector<ll>a;
		//for(int i=2;i<=n;i++){ll x=Bin(2*n-1-i,n-1);a.pb(x),a.pb(x);}
		ll Dp[n+10][n+10];memset(Dp,0,sizeof(Dp));Dp[0][1]=1;
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) Dp[i][j]=Dp[i-1][j]+Dp[i][j-1];
		//for(int i=1;i<=n;i++){for(int j=1;j<=n;j++) printf("%lld ",Dp[i][j]);printf("\n");}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if((i==1&&j==1)) continue;
				ll dp[n+10][n+10];memset(dp,0,sizeof(dp));dp[0][1]=1;
				for(int x=1;x<=n;x++){
					for(int y=1;y<=n;y++){
						if(!(x==i&&y==j)) dp[x][y]=dp[x-1][y]+dp[x][y-1];
					}
				}
				a.pb(Dp[n][n]-dp[n][n]);
			}
		}
		for(auto i:a) printf("%lld ",i);printf("\n");
		vector<ll>b={0};
		for(int i=0;i<a.size();i++){
			int m=b.size();
			for(int j=0;j<m;j++){
				b.pb(b[j]+a[i]);
			}
			Unique(b);
		}
		//for(auto i:b) printf("%lld ",i);printf("\n");
		for(auto i:b) c.pb(i);
		Unique(c);
    }
    //printf("da\n");
    for(auto i:c) printf("%lld ",i);printf("\n");
    for(int i=0;i+1<c.size();i++){
		if(c[i]+1!=c[i+1]){
			printf("%lld\n",c[i]);

		}
    }*/
    /*int t;scanf("%i",&t);
    while(t--){
		int K;scanf("%i",&K);
		int n=K;
		vector<pair<int,int>>res;
		if(K>=2){
			for(int i=2;i<=n;i++) res.pb({1,i});
			for(int i=1;i<=n;i++) res.pb({2,i});
			for(int i=3;i<=n;i++) res.pb({i,n});
		}
		Ispis(n,res);
    }*/
    int t;scanf("%i",&t);
    while(t--){
		int K;scanf("%i",&K);
		if(K==1){
			printf("1\n");
			continue;
		}
		/*int n=1,temp=K;
		while(temp>>=1)n++;
		vector<pair<int,int>>res;
		for(int i=1;i<n;i++){
			res.pb({i,i+1});
			res.pb({i+1,i});
			res.pb({i+1,i+1});
		}
		res.pb({n,n+1});
		for(int i=n-1;i>=1;i--){
			int bit=(K>>(i-1))%2;
			//printf("%i\n",bit);
			if(!bit) continue;
			for(int j=i+2;j<=n+1;j++){
				res.pb({i,j});
			}
		}
		for(int i=1;i<=n+2;i++) res.pb({i,n+2});
		Dodaj(res);
		Ispis(res);*/
		int n=1,temp=K;
		while(temp>>=1)n++;
		cerr<<n<<endl;
		vector<pair<int,int>>res;
		for(int i=1;i<=n-3;i++){
			res.pb({i,i+1});
			res.pb({i+1,i});
			res.pb({i+1,i+1});
		}
		//res.pb({n,n+1});
		for(int i=n-2;i>=1;i--){
			int bit=(K>>(i-1))%2;
			//printf("%i\n",bit);
			if(!bit) continue;
			for(int j=i+1;j<=n-1;j++){
				res.pb({i,j});
			}
		}
		for(int i=1;i<=n-1;i++) res.pb({i,n});
		bool bul=false;
		for(auto [i,j]:res) if(i==n-2&&j==n-1) bul=true;


		if(bul){
			res.pb({n-1,n-1});
			res.pb({n-1,n-2});
		}
		else{
			res.pb({n-1,n-2});
			res.pb({n-1,n-1});
		}

		res.pb({n,n-2});
		res.pb({n,n-1});
		res.pb({n,n});
		res.pb({n+1,n-1});
		res.pb({n+1,n});
		res.pb({n+1,n+1});
		//for(int i=1;i<=n+2;i++) res.pb({i,n+2});
		Sredi(res);
		Ispis(res);
		//printf("  %lld\n",Check(res));
    }
    return 0;
}
