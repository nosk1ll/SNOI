#include<bits/stdc++.h>
#define int long long
#define MAXN (int)1e5+5
#define pii pair<int,int>
#define fi first
#define se second
#define MAXLG 21
using namespace std;
vector<int>g[MAXN];
vector<int>z[MAXN];
int l[MAXN][MAXLG],lg[MAXN],dep[MAXN],c[MAXN],z2[MAXN];
set<tuple<int,int,int>>s2;
int n,m,q;
void precompute(){
	lg[0]=lg[1]=0;
	for(int i=2;i<MAXN;i++){
		lg[i]=lg[i/2]+1;
	}
}
void dfs(int x,int p){
	for(int i=1;i<=lg[n];i++){
		int h=l[x][i-1];
		if(h==-1){
			l[x][i]=-1;
		}else{
			l[x][i]=l[h][i-1];
		}
	}
	for(int&y:g[x]){
		if(y^p){
			l[y][0]=x;
			dep[y]=dep[x]+1;
			dfs(y,x);
		}
	}
}
void dfs2(int x,int p,int e){
	for(int&y:g[x]){
		if(y^p){
			for(int&o:z[x]){
				for(int&o2:z[y]){
					s2.insert({min(o,o2),max(o,o2),e});
				}
			}
			for(int&o:z[y]){
				z[x].push_back(o);
				z2[o]=x;
			}
			z[y].clear();
			dfs2(y,x,e);
		}
	}
}
int lift(int x,int k){
	int h=x;
	for(int i=0;(1<<i)<=k;i++){
		if((1<<i)&k){
			h=l[h][i];
			if(h==-1){break;}
		}
	}
	return h;
}
int lca(int a,int b){
	if(dep[b]>dep[a]){swap(a,b);}
	a=lift(a,dep[a]-dep[b]);
	if(a==b){return dep[b];}
	for(int i=lg[n];i>=0;i--){
		if(l[a][i]!=l[b][i]){
			a=l[a][i];
			b=l[b][i];
		}
	}
	return dep[l[a][0]];
}
void solve() {
	cin>>n>>m>>q;
	for(int i=0;i<n-1;i++){
		int a,b;cin>>a>>b;
		g[a].push_back(b);
		g[b].push_back(a);
	}
	int mm=0;
	for(int i=0;i<m;i++){
		cin>>c[i];
		mm=max(c[i],mm);
	}

	if(mm==1&&n==m){
		l[1][0]=-1;
		dep[1]=0;
		dfs(1,0);
		while(q--){
			int a,b;cin>>a>>b;
			if(dep[a]==dep[b]){
				int x=dep[a]-lca(a,b);
				if(x<=m){
					cout<<x<<'\n';
				}else{
					cout<<-1<<'\n';
				}
			}else{
				if(max(dep[a],dep[b])<=m){
					cout<<max(dep[a],dep[b])<<'\n';
				}else{
					cout<<-1<<'\n';
				}
			}
		}
	}else{
		for(int i=1;i<=n;i++){
			z[i].push_back(i);
			z2[i]=i;
		}
		for(int i=0;i<m;i++){
			dfs2(c[i],l[c[i]][0],i+1);
		}
		while(q--){
			int a,b;cin>>a>>b;
			if(a>b){
				swap(a,b);
			}
			auto lb=s2.lower_bound({a,b,0});
			int uu,vv,ee;tie(uu,vv,ee)=*lb;
			if(uu==a&&vv==b){
				cout<<ee<<'\n';
			}else{
				cout<<-1<<'\n';
			}
		}
	}
}
int32_t main() {
	ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	precompute();
	int32_t T=1;//cin>>T;
	while(T--) {
		solve();
	}
	return 0;
}