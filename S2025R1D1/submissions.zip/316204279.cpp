#include <bits/stdc++.h>
#define Debug(x) cout << #x << " = " << x << ";\n"
using namespace std;
int N, M, Q, glob;
int D[100096];
int A[100096];
struct QUERY
{
  int u, v;
  int L, R;
}QR[100096];
vector <int> V[100096];
vector <int> ST[400096];
inline void Setup()
{
  for(int i = 1; i <= N; i++) {D[i] = i; ST[i] = {i};}
  return;
}
inline void DFS(int i)
{
  if(ST[i << 1].size())
  {
    for(int x : ST[i << 1]) {D[x] >>= 1; ST[i].push_back(x);}
    ST[i << 1] = vector <int>();
    DFS(i << 1);
  }
  if(ST[(i << 1) + 1].size())
  {
    for(int x : ST[(i << 1) + 1]) {D[x] >>= 1; ST[i].push_back(x);}
    ST[(i << 1) + 1] = vector <int>();
    DFS((i << 1) + 1);
  }
  return;
}
inline void ParallelBS()
{
  for(int i = 1; i <= Q; i++) {QR[i].L = 1; QR[i].R = M;}
  int block = M;
  while(block >= 1)
  {
//    Debug(block);
    for(int i = 0; V[i].size(); i++) V[i] = vector <int>(); ///do M?
    for(int i = 1; i <= Q; i++) V[QR[i].L / block].push_back(i); ///od 0 indeksirano, L ili R?
    Setup();
    for(int i = 0; (i <= M) || V[i].size(); i++) ///do M?
    {
      int L = i * block + 1, R = min(M, (i + 1) * block), S = (L + R) >> 1;
//      Debug(i);
//      Debug(L);
//      Debug(R);
//      Debug(S);
      for(int j = L; j <= S; j++) DFS(A[j]);
      for(int x : V[i])
      {
        ///kako -1???
        if(D[QR[x].u] == D[QR[x].v]) QR[x].R = S;
        else QR[x].L = S + 1;
      }
      for(int j = S + 1; j <= R; j++) DFS(A[j]);
    }
    if(block == 1) break;
    block = (block + 0) >> 1; ///smanjenje ok?
  }
  return;
}
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> Q;
  int u, v;
  for(int i = 1; i < N; i++) cin >> u >> v;
  for(int i = 1; i <= M; i++) cin >> A[i];
  for(int i = 1; i <= Q; i++) cin >> QR[i].u >> QR[i].v;
  ParallelBS();
  for(int i = 1; i <= Q; i++)
  {
    if(QR[i].L <= M) cout << QR[i].L << '\n';
    else cout << "-1\n";
  }

  return 0;
}
