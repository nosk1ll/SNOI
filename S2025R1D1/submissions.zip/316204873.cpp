#include <bits/stdc++.h>
#define ll long long
using namespace std;
vector<vector<ll> > a;
vector<pair<ll,pair<ll,ll> > > val;
ll n,m,k;
vector<vector<bool> > up,down,leftt,rightt,V;
void Solve_Up(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;x<i;x++)
    {
        if (up[i-x][j])
            break;
        while (s.top()<a[i-x][j])
            s.pop();
        if (s.top()-d<=a[i-x][j])
        {
            V[i-x][j]=true;
            s.push(a[i-x][j]);
        }
        up[i-x][j]=true;
    }
}
void Solve_Down(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;i+x<=n;x++)
    {
        if (down[i+x][j])
            break;
        while (s.top()<a[i+x][j])
            s.pop();
        if (s.top()-d<=a[i+x][j])
        {
            V[i+x][j]=true;
            s.push(a[i+x][j]);
        }
        down[i+x][j]=true;
    }
}
void Solve_Left(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;x<j;x++)
    {
        if (leftt[i][j-x])
            break;
        while (s.top()<a[i][j-x])
            s.pop();
        if (s.top()-d<=a[i][j-x])
        {
            V[i][j-x]=true;
            s.push(a[i][j-x]);
        }
        leftt[i][j-x]=true;
    }
}
void Solve_Right(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;j+x<=m;x++)
    {
        if (rightt[i][j+x])
            break;
        while (s.top()<a[i][j+x])
            s.pop();
        if (s.top()-d<=a[i][j+x])
        {
            V[i][j+x]=true;
            s.push(a[i][j+x]);
        }
        rightt[i][j+x]=true;
    }
}
vector<pair<ll,ll> > w;
bool Check(ll d)
{
    for (ll i=1;i<=n;i++)
    {
        for (ll j=1;j<=m;j++)
        {
            V[i][j]=false;
            up[i][j]=false;
            down[i][j]=false;
            leftt[i][j]=false;
            rightt[i][j]=false;
        }
    }
    ll cnt=0;
    vector<pair<ll,ll> > cur;
    for (auto v : val)
    {
        ll i=v.second.first,j=v.second.second;
        if (!V[i][j])
        {
            cnt++;
            cur.push_back({i,j});
            V[i][j]=true;
        }
        if (!up[i][j])
        {
            up[i][j]=true;
            Solve_Up(i,j,d);
        }
        if (!down[i][j])
        {
            down[i][j]=true;
            Solve_Down(i,j,d);
        }
        if (!leftt[i][j])
        {
            leftt[i][j]=true;
            Solve_Left(i,j,d);
        }
        if (!rightt[i][j])
        {
            rightt[i][j]=true;
            Solve_Right(i,j,d);
        }
    }
    if (cnt<=k)
    {
        w=cur;
        while (w.size()<k)
            w.push_back(cur[0]);
        return true;
    }
    return false;
}
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cin >> n >> m >> k;
    a.resize(n+2);
    up.resize(n+2);
    down.resize(n+2);
    leftt.resize(n+2);
    rightt.resize(n+2);
    V.resize(n+2);
    for (ll i=1;i<=n;i++)
    {
        a[i].resize(m+2);
        up[i].resize(m+2);
        down[i].resize(m+2);
        leftt[i].resize(m+2);
        rightt[i].resize(m+2);
        V[i].resize(m+2);
        for (ll j=1;j<=m;j++)
        {
            cin >> a[i][j];
            val.push_back({a[i][j],{i,j}});
        }
    }
    sort(val.begin(),val.end(),greater<pair<ll,pair<ll,ll> > > ());
    ll l=0,r=1e9,mid,ans=-1;
    while (l<=r)
    {
        mid=(l+r)/2;
        if (Check(mid))
        {
            ans=mid;
            r=mid-1;
        }
        else
            l=mid+1;
    }
    cout << ans << "\n";
    for (auto i : w)
        cout << i.first << " " << i.second << "\n";
    return 0;
}
