#include <bits/stdc++.h>
using namespace std;
int N, M, Q, glob;
int D[100096];
vector <int> ST[400096];
int A[100096], O[100096];
int B[1006][1006];
inline void Setup()
{
  for(int i = 1; i <= N; i++) {D[i] = i; ST[i] = {i};}
  return;
}
inline void DFS(int i)
{
  if(ST[i << 1].size())
  {
    for(int x : ST[i << 1])
    {
      for(int y : ST[i]) B[x][y] = B[y][x] = glob;
    }
    for(int x : ST[i << 1]) {D[x] >>= 1; ST[i].push_back(x);}
    ST[i << 1] = vector <int>();
    DFS(i << 1);
  }
  if(ST[(i << 1) + 1].size())
  {
    for(int x : ST[(i << 1) + 1])
    {
      for(int y : ST[i]) B[x][y] = B[y][x] = glob;
    }
    for(int x : ST[(i << 1) + 1]) {D[x] >>= 1; ST[i].push_back(x);}
    ST[(i << 1) + 1] = vector <int>();
    DFS((i << 1) + 1);
  }
  return;
}
inline void ParallelBS()
{
  return;
}
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> Q;
  int u, v;
  for(int i = 1; i < N; i++) cin >> u >> v; ///mora uvek isto?
  for(int i = 1; i <= M; i++) cin >> A[i];
  Setup();
  for(int i = 1; i <= M; i++)
  {
    glob = i;
    DFS(A[i]);
  }
  for(int i = 1; i <= Q; i++)
  {
    cin >> u >> v;
    cout << B[u][v] - !(B[u][v]) << '\n';
  }

  return 0;
}
