#include <bits/stdc++.h>

using namespace std;

// Macros
#define f first
#define s second
#define ll long long
#define db double
#define vi vector<int>
#define vl vector<ll>
#define vp vector<pair<ll, ll>>
#define vvi vector<vi>
#define mi map<int, int>
#define beg begin
#define nl "\n"
#define yes "YES\n"
#define no "NO\n"

// Loops
#define FOR(i, a, b) for(int i = a; i < b; i++)
#define ROF(i, a, b) for(int i = a - 1; a >= b; i--)

void solve(){
    int n, m, k;
    cin >> n >> m >> k;
    vvi a(n, vi(m));
    FOR(i, 0, n){
        FOR(j, 0, m){
            cin >> a[i][j];
        }
    }
    if(n > 1 && m > 1){
        cout << -1 << nl;
    }
    else if(n == 1){
        int i1;
        FOR(i, 0, m){
            if(a[0][i] == n * m){
                i1 = i;
                break;
            }
        }
        int l = i1, r = i1;
        if(i1 != 0) l = i1 - 1;
        if(i1 != m - 1) r = i1 + 1;
        bool b = true;
        while(l >= 0){
            if(a[0][l] <= a[0][l + 1]) l--;
            else{
                b = false;
                break;
            }
        }
        if(b){
            while(r < m){
                if(a[0][r] <= a[0][r - 1]) r++;
                else{
                    b = false;
                    break;
                }
            }
        }
        if(b){
            cout << max(m - 1 - i1, i1) << nl;
            cout << 1 << " " << i1 << nl;
        }
        else cout << -1 << nl;
    }
    else{
        int i1;
        FOR(i, 0, n){
            if(a[i][0] == n * m){
                i1 = i;
                break;
            }
        }
        int l = i1, r = i1;
        if(i1 != 0) l = i1 - 1;
        if(i1 != n - 1) r = i1 + 1;
        bool b = true;
        while(l >= 0){
            if(a[0][l] <= a[0][l + 1]) l--;
            else{
                b = false;
                break;
            }
        }
        if(b){
            while(r < n){
                if(a[0][r] <= a[0][r - 1]) r++;
                else{
                    b = false;
                    break;
                }
            }
        }
        if(b){
            cout << max(n - 1 - i1, i1) << nl;
            cout << 1 << " " << i1 << nl;
        }
        else cout << -1 << nl;
    }
}

int main(){
    cin.tie(0);cout.tie(0);ios_base::sync_with_stdio(false);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
