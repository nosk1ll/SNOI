#include <bits/stdc++.h>
#define endl '\n'
#define int long long

using namespace std;

const long long longlongmax=9223372036854775807;
const int modul=998244353;
const long long mod = 1e9 + 7;


mt19937 mt(chrono::steady_clock::now().time_since_epoch().count());

const int N=500000;




signed main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    //freopen("seating.in","r",stdin);
    //freopen("seating.out","w",stdout);

    int n,m,k;
    cin >> n >> m >> k;
    int matr[n+1][m+1];
    for(int i=1; i<=n; i++){
        for(int j=1; j<=m; j++) cin >> matr[i][j];
    }
    map<int,pair<int,int>> koor;
    for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) koor[matr[i][j]]={i,j};
    bool checked[n+1][m+1];
    int l=0,d=1000000000,rez=-1;vector<int> rezz;
    while(l<=d){
        int s=l+d>>1;
        for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) checked[i][j]=0;
        int domet=s;
        set<int> skup;
        for(int i=1; i<=n; i++) for(int j=1; j<=m; j++) skup.insert(matr[i][j]);
        int potrebno=0;
        vector<int> ruteri;
        queue<pair<int,int>> red;
        while(skup.size()){
            potrebno++;
            int poc=*prev(skup.end());
            ruteri.push_back(poc);
            red.push({koor[poc].first,koor[poc].second});
            stack<int> mini;
            while(red.size()){
                int i=red.front().first,j=red.front().second;
                red.pop();
                skup.erase(matr[i][j]);
                checked[i][j]=true;
                while(mini.size()) mini.pop();mini.push(matr[i][j]);
                for(int I=i+1; I<=n; I++){
                    if(checked[I][j]) break;
                    if(matr[I][j]>matr[i][j]) break;
                    if(matr[I][j]<mini.top()-domet) continue;
                    checked[I][j]=true;
                    while(mini.top()<matr[I][j]) mini.pop();
                    mini.push(matr[I][j]);
                    red.push({I,j});
                }
                while(mini.size()) mini.pop();mini.push(matr[i][j]);
                for(int I=i-1; I>0; I--){
                    if(checked[I][j]) break;
                    if(matr[I][j]>matr[i][j]) break;
                    if(matr[I][j]<mini.top()-domet) continue;
                    checked[I][j]=true;
                    while(mini.top()<matr[I][j]) mini.pop();
                    mini.push(matr[I][j]);
                    red.push({I,j});
                }
                while(mini.size()) mini.pop();mini.push(matr[i][j]);
                for(int J=j+1; J<=m; J++){
                    if(checked[i][J]) break;
                    if(matr[i][J]>matr[i][j]) break;
                    if(matr[i][J]<mini.top()-domet) continue;
                    checked[i][J]=true;
                    while(mini.top()<matr[i][J]) mini.pop();
                    mini.push(matr[i][J]);
                    red.push({i,J});
                }
                while(mini.size()) mini.pop();mini.push(matr[i][j]);
                for(int J=j-1; J>0; J--){
                    if(checked[i][J]) break;
                    if(matr[i][J]>matr[i][j]) break;
                    if(matr[i][J]<mini.top()-domet) continue;
                    checked[i][J]=true;
                    while(mini.top()<matr[i][J]) mini.pop();
                    mini.push(matr[i][J]);
                    red.push({i,J});
                }

            }

        }



        if(potrebno<=k){
            rez=s;
            rezz=ruteri;
            d=s-1;
        }
        else
            l=s+1;

    }
    if(rez==-1) {cout << rez; return 0;}
    cout << rez << endl;
    while(rezz.size()!=k) rezz.push_back(rezz.back());
    for(auto&x:rezz) cout << koor[x].first << " " << koor[x].second << endl;


    return 0;
}
/*
1 5 2
4 3 2 5 1


1 6 1
10 9 8 6 7 4

resenje za d:3


*/
