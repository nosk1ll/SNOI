#include <bits/stdc++.h>

const int N = 1e5 + 5;

struct Lca{
    std::vector<int>adj[N];
    int in[N];
    int out[N];
    int timer=1;
    int P[N];
    int depth[N];
    int Log(int n){
        int logs[n+1];
        logs[1]=0;
        for(int i=2;i<=n;i++)logs[i]=logs[i/2]+1;
        return logs[n];
    }
    int up[N][30];
    void build(int n){
        up[1][0]=1;
        for(int i=2;i<=n;i++)up[i][0]=P[i];
        for(int i=1;i<=29;i++){
            for(int j=1;j<=n;j++){
                up[j][i]=up[up[j][i-1]][i-1];
            }
        }
    }
    void connect(int u,int v){
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    void dfs(int x,int cale, int dep){
        in[x]=timer++;
        P[x]=cale;
        depth[x] = dep;
        for(auto it:adj[x]){
            if(it!=cale)dfs(it,x, dep + 1);
        }
        out[x]=timer;
    }
    int in_tree(int u,int v){
        return in[u]<=in[v]&&out[u]>=out[v];
    }
    int lca(int u,int v){
        if(u==v)return u;
        if(in_tree(u,v))return u;
        if(in_tree(v,u))return v;
        for(int i=29;i>=0;i--){
            if(!in_tree(up[u][i],v)){
                u=up[u][i];
            }
        }
        return up[u][0];
    }
    int dist(int u, int v) {
      return depth[u] + depth[v] - 2 * depth[lca(u, v)];
    }
}lca;

void solve() {
  int n, m, q;
  std::cin >> n >> m >> q;
  for(int i = 1; i < n; i++) {
    int u, v;
    std::cin >> u >> v;
    lca.connect(u, v);
  }
  lca.dfs(1, 0, 0);
  lca.build(n);
  std::vector<int> c(m + 1);
  for(int i = 1; i <= m; i++) {
    std::cin >> c[i];
    assert(c[i] == 1);
  }
  for(int i = 1; i <= q; i++) {
    int u, v;
    std::cin >> u >> v;
    int node = lca.lca(u, v);
    if(lca.depth[u] != lca.depth[v]) {
      std::cout << std::max(lca.depth[u], lca.depth[v]) << "\n";
    }
    else {
      std::cout << lca.dist(u, node) << "\n";
    }
  }
}

int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

