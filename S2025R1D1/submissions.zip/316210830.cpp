#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll t,k;
    cin >> t;
    while (t--)
    {
        cin >> k;
        cout << k << "\n";
        if (k==1)
            break;
        cout << "1 2\n";
        for (ll i=2;i<=k;i++)
            cout << "1 " << i << "\n";
        for (ll i=2;i<=k;i++)
            cout << "2 " << i << "\n";
        for (ll i=3;i<=k;i++)
            cout << k << " " << i << "\n";
        for (ll i=1;i<k;i++)
        {
            for (ll j=3;j<=k;j++)
                cout << i << " " << j << "\n";
        }
    }
    return 0;
}
