#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 2e5 + 3;
vector<pair<int, int>> res;

const int POM[4][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

void solve() {
    int n, m, k; cin >> n >> m >> k;
    vector<vector<int>> a(n+3, vector<int>(m+3));
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> a[i][j];

    auto moze = [&](int d) {
        vector<vector<bool>> vis(n+3, vector<bool>(m+3));
        vector<pair<int, int>> ans;
        priority_queue<tuple<int, int, int>> pq;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                pq.emplace(a[i][j], i, j);
        int can = k;
        while (!pq.empty()) {
            auto [w, i, j] = pq.top(); pq.pop();
            if (vis[i][j]) {
                for (int dx = 0; dx < 4; dx++) {
                    set<int> st;
                    int curi = i, curj = j;
                    st.insert(a[i][j]);
                    while (curi >= 1 && curi <= n && curj >= 1 && curj <= m && vis[curi][curj]) {
                        int ik = curi + POM[dx][0], jk = curj + POM[dx][1];
                        auto ww = st.upper_bound(a[ik][jk]+d);
                        if (ww == st.begin()) break;
                        int val = *prev(ww);
                        if (a[ik][jk] <= val)
                            vis[ik][jk] = true;
                        curi = ik; curj = jk;
                        if (vis[ik][jk])
                            st.insert(a[ik][jk]);
                    }
                }
                continue;
            }
            vis[i][j] = true;

            for (int dx = 0; dx < 4; dx++) {
                set<int> st;
                int curi = i, curj = j;
                st.insert(a[i][j]);
                while (curi >= 1 && curi <= n && curj >= 1 && curj <= m && vis[curi][curj]) {
                    int ik = curi + POM[dx][0], jk = curj + POM[dx][1];
                    auto ww = st.upper_bound(a[ik][jk]+d);
                    if (ww == st.begin()) break;
                    int val = *prev(ww);
                    if (a[ik][jk] <= val)
                        vis[ik][jk] = true;
                    curi = ik; curj = jk;
                    if (vis[ik][jk])
                        st.insert(a[ik][jk]);
                }
            }
            //dbg(i, j);
            can--;
            ans.push_back({i, j});
        }

        if (can < 0) return false;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                if (can > 0) ans.push_back({i, j}), can--;

        res = ans;
        return true;
    };

    int low = 0, high = n*m;
    while (low < high) {
        int mid = (low + high) / 2;
        if (moze(mid))
            high = mid;
        else
            low = mid+1;
    }
    if (!moze(low)) {
        cout << -1 << "\n"; return;
    }

    cout << low << "\n";
    for (auto [x, y] : res)
        cout << x << " " << y << "\n";
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}
