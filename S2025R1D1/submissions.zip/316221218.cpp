#include <bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);cerr.tie(0);

vector<int>h;
vector<int> ulaznist;

int main(){
    ubrzaj
int n,m,k,pom,N;
cin>>n>>m>>k;
vector< set<int> > rs1(n),cs1(m);
pom=m*m;
N=m*n;
h.resize(N);
for(int i=0;i<N;i++)cin>>h[i];
pom-=n;
ulaznist.resize(N);
vector<pair<int,int>>red(N);
for(int i=0;i<N;i++) red[i]={h[i], i};
sort(red.rbegin(),red.rend());
auto rez=[&](int d){
for(int i=0;i<n;i++) rs1[i].clear();
for(int j=0;j<m;j++) cs1[j].clear();
fill(ulaznist.begin(),ulaznist.end(),0);
pom=0;
//if (pom==0) cout<<"RS1 CS1 clear\n";
int poms=0;
for(auto &pr:red){
int i,j,hcur,idx;
hcur=pr.first;
idx=pr.second;
i=idx/m;
j=idx%m;
poms++;
auto &rs = rs1[i];

        auto it = rs.lower_bound(j);
if(it!=rs.begin())
    { int hi,j2,idx2,hnei;
j2=*prev(it);
idx2=m*i+j2;
hnei=h[idx2];
  //  cout<<h[npomi]<<" "<<h[pomi]<<"\n";
    if(hnei<=hcur+d)
if(ulaznist[idx]++==0) poms--;
}
if(it != rs.end()){
int hi,j2,idx2,hnei;
    j2=*it;
idx2=m*i+j2; hnei=h[idx2];
if(hnei<=hcur+d)
     if(ulaznist[idx]++ == 0) poms--;
}
    rs.insert(j);
auto &cs=cs1[j]; pom=0;
//if (pom==0) cout<<max_element(h.begin(),h.end());
//else cout<<min_element(h.begin(),h.end());
auto it2=cs.lower_bound(i);
if(it2!=cs.begin()){
//cout<<m<<" "<<j<<" "<<*veci;
//int npomi=j+(veci)*m;
//cout<<npomi<<"\n";
int hi,i2,idx2,hnei;
i2=*prev(it2);
idx2=j+m*i2;
hnei=h[idx2];
if(hnei<=hcur+d)
    if(ulaznist[idx]++==0) poms--;
    }
if(it2!=cs.end())
   {int hi,i2,idx2,hnei;
i2=*it2;
idx2=m*i2+j;
hnei=h[idx2];
        if(hnei<=hcur+d)
         if(ulaznist[idx]++==0) poms--;

    }
cs.insert(i);

if(poms>k) return false;
        }
        return poms<=k;
    };

int pisi,lpoc;
lpoc=0;
pisi=-1;
//if (pom==0) cout<<max_element(h.begin(),h.end());
//else cout<<min_element(h.begin(),h.end());
int hi = *max_element(h.begin(), h.end())
                  - *min_element(h.begin(), h.end());
//BS po resenju
while(lpoc<=hi)
    {
        int sp=(lpoc+hi)>> 1;
        if(rez(sp)){pisi=sp;hi=sp-1;
        } else lpoc = sp + 1;
    }
    if(pisi<0){
cout <<-1<< "\n";
        return 0;
    }
cout <<pisi<< "\n";
rez(pisi);
vector<pair<int,int>> niz;
niz.reserve(k);
vector<char> seen(N,0);
for(auto &pr:red){
    int idx=pr.second;
        if(ulaznist[idx]==0 && !seen[idx])
    {seen[idx]=1;
niz.emplace_back(1+idx/m,1+idx%m );
if((int)niz.size()==k) break;
}
    }
 while((int)niz.size()<k)niz.push_back(niz[0]);
for(auto &p:niz)cout <<p.first<<" "<<p.second<<"\n";
return 0;
}
