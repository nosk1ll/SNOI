#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 1e5 + 3;
const int logn = 19;
vector<int> adj[N];
int up[N][logn];
int dep[N], c[N];
int tin[N], tout[N], timer = 0;
vector<int> vreme[N];

void dfs(int u, int p) {
    tin[u] = ++timer;
    dep[u] = dep[p]+1;
    up[u][0] = p;
    for (int j = 1; j < logn; j++)
        up[u][j] = up[up[u][j-1]][j-1];
    for (auto x : adj[u]) if (x != p) {
        dfs(x, u);
    }
    tout[u] = timer;
}

bool IsAncestor(int u, int v) {
    return (tin[u] <= tin[v] && tout[u] >= tout[v]);
}

int get_lca(int u, int v) {
    if (IsAncestor(u, v)) return u;
    if (IsAncestor(v, u)) return v;

    for (int j = logn-1; j >= 0; j--) {
        if (up[u][j] != 0 && !IsAncestor(up[u][j], v))
            u = up[u][j];
    }
    return up[u][0];
}

void solve() {
    int n, m, q; cin >> n >> m >> q;
    for (int i = 0; i < n-1; i++) {
        int u, v; cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    for (int i = 1; i <= m; i++) cin >> c[i], vreme[c[i]].push_back(i);
    dfs(1, 0);


    if (*max_element(c + 1, c + m + 1) == 1) {
        while (q--) {
            int u, v; cin >> u >> v;
            if (dep[u] == dep[v]) {
                int lca = get_lca(u, v);
                cout << dep[u]-dep[lca] << "\n";
            } else {
                cout << max(dep[u], dep[v])-1 << "\n";
            }
        }
        return;
    }

    while (q--) {
        int u, v; cin >> u >> v;
        map<int, int> mp;
        mp[u] = u; mp[v] = v;
        int ans = -1;
        vector<tuple<int, int, int>> vec;
        int cur = up[u][0];
        while (cur != 0) {
            if (!vreme[cur].empty()) {
                for (auto x : vreme[cur])
                    vec.push_back({x, cur, u});
            }
            cur = up[cur][0];
        }

        cur = up[v][0];
        while (cur != 0) {
            if (!vreme[cur].empty()) {
                for (auto x : vreme[cur])
                    vec.push_back({x, cur, v});
            }
            cur = up[cur][0];
        }
        sort(vec.begin(), vec.end());
        int pu = u, pv = v;

        for (auto [vv, to, k] : vec) {
            //dbg(u, v, vv, to, k);
            if (k == pu) {
                if (to != u && IsAncestor(to, u)) {
                    u = up[u][0];
                }
                mp[pu] = u;
            } else {
                if (to != v && IsAncestor(to, v)) {
                    v = up[v][0];
                }
                mp[pv] = v;
            }
            if (u == v) {
                //dbg(vv, u, v);
                ans = vv; break;
            }
        }

        cout << ans << "\n";
    }
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}

/*
6 2 1
2 4
2 5
1 3
1 2
6 3
3 3
3 1

6 2 1
2 4
2 5
1 3
1 2
6 3
3 3
6 3

10 10 1
1 2
1 3
2 4
2 5
3 6
3 7
4 8
4 9
5 10
1 2 2 1 1 7 2 9 1 10
6 1
*/
