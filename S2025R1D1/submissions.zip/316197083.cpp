#include<bits/stdc++.h>
using namespace std;
using ll=long long;

ll a[35][35];

void solve(){
	ll k;
	cin>>k;

	if(!(k&(k-1))){
		ll x=log2(k)+1;
		cout<<x<<'\n';
		for(int i=0;i<35;++i)
			for(int j=0;j<35;++j)
				a[i][j]=0;
		a[1][1]=1;
		for(int i=1;i<x;++i){
			cout<<i<<' '<<i+1<<'\n';
			cout<<i+1<<' '<<i<<'\n';
			cout<<i+1<<' '<<i+1<<'\n';
			a[i][i+1]=a[i+1][i]=a[i+1][i+1]=1;
		}
		for(int i=1;i<=x;++i){
			for(int j=1;j<=x;++j){
				if(!a[i][j])cout<<i<<' '<<j<<'\n';
			}
		}
		return;
	}
	
	ll n=0;
	while((1ll<<(n+1))<=k)++n;
	n+=3;
	cout<<n<<'\n';

	for(int i=0;i<35;++i)
		for(int j=0;j<35;++j)
			a[i][j]=0;
	a[1][1]=1;

	for(int i=1;i+3<=n;++i){
		cout<<i<<' '<<i+1<<'\n';
		cout<<i+1<<' '<<i<<'\n';
		cout<<i+1<<' '<<i+1<<'\n';
		a[i][i+1]=a[i+1][i]=a[i+1][i+1]=1;
	}

	ll lsb=0;
	for(int i=0;i<n;++i){
		if((k>>i)&1){
			lsb=1+i;break;
		}
	}

	for(int i=n-3;i>=0;--i){
		if(((k>>i)&1)&&i+1!=lsb){
			ll lik=(i+3==n?i+2:i+3);
			for(int j=lik;j<n;++j){
				cout<<j<<' '<<i+1<<'\n';
				a[j][i+1]=1;
			}
		}
	}

	for(int i=lsb+2;i<=n;++i){
		cout<<i<<' '<<lsb<<'\n';
		a[i][lsb]=1;
	}

	for(int i=lsb+1;i<=n;++i){
		cout<<n<<' '<<i<<'\n';
		a[n][i]=1;
	}

	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			if(!a[i][j]){
				cout<<i<<' '<<j<<'\n';
			}
		}
	}
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    ll T;cin>>T;
    while(T--)solve();
}