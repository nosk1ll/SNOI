#include <bits/stdc++.h>
//#define int long long
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define sc second
#define endl "\n"
#define pii pair<int,int>

using namespace std;

const int MAXN = 1e5+5;
const int mod7 = 1e9+7;
const long long inf = 1e18;

struct str{int x,a,b;};

class cmp {
    public:
       bool operator()(str a, str b){
           if(a.x == b.x)
           {
               if(a.a == b.a)return a.b > b.b;
               return a.a > b.a;
           }
           return a.x > b.x;
      }
};

signed main()
{
    ios_base::sync_with_stdio(false),cin.tie(0), cout.tie(0);
    int tt=1;
    //cin >> tt;
    while(tt--)
    {
        int n,m,k;
        cin >> n >> m >> k;
        set<str, cmp>pq;
        vector<vector<int>> mat(n+1, vector<int>(m+1));
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m; j++)
            {
                int x;cin >> x;
                mat[i][j] = x;
                pq.insert({x,i,j});
            }
        }
        int l = 1;
        int r = n*m;
        int resenje = n*m+1;
        vector<pii> prethodnoresenje;
        while(l<=r)
        {
            int mid = l+ r >> 1;
            int broj_oznacenih = 0;
            int k2 = k;
            set<str, cmp>pq2 = pq;
            vector<vector<bool>> visited(n+1, vector<bool>(m+1, false));
            vector<pii> trresenje;
            while(broj_oznacenih < n*m && k2>0)
            {
                str tr = *pq2.begin();
                k2--;
                trresenje.pb({tr.a, tr.b});
                int x = tr.x;
                queue<pii> q;
                q.push({tr.a, tr.b});
                while(!q.empty())
                {
                    pii trenutno = q.front();
                    int i = trenutno.fi;
                    int j = trenutno.sc;
                    q.pop();
                    if(visited[i][j])continue;
                    visited[i][j] = 1;
                    pq2.erase({mat[i][j], i, j});
                    broj_oznacenih++;
                    if(i> 1 && !visited[i-1][j] && mat[i-1][j] >= mat[i][j] - mid && mat[i][j] > mat[i-1][j])q.push({i-1,j});
                    if(j> 1 && !visited[i][j-1] && mat[i][j-1] >= mat[i][j] - mid && mat[i][j] > mat[i][j-1])q.push({i,j-1});
                    if(i<n && !visited[i+1][j] && mat[i+1][j] >= mat[i][j] - mid && mat[i][j] > mat[i+1][j])q.push({i+1,j});
                    if(j<m && !visited[i][j+1] && mat[i][j+1] >= mat[i][j] - mid && mat[i][j] > mat[i][j+1])q.push({i,j+1});
                }
            }
            bool moze;
            if(broj_oznacenih == n*m)moze = 1;
            else moze = 0;
            if(moze)
            {
                prethodnoresenje = trresenje;
                resenje = mid;
                r = mid - 1;
            }
            else l = mid+1;
        }
        if(resenje == n*m + 1)cout << -1 << endl;
        else
        {
            cout << resenje << endl;
            int a = prethodnoresenje.size();
            if(prethodnoresenje.size() < k)for(int i=0; i<k - prethodnoresenje.size(); i++)prethodnoresenje.pb(prethodnoresenje.back());
            for(auto x: prethodnoresenje)cout << x.fi << " " << x.sc << endl;
        }
    }
}
