#include <bits/stdc++.h>

using namespace std;
#define pb push_back

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, m, q, tr;
    cin >> n >> m >> q;
    for (int i = 1; i <= n-1; ++i)    cin >> tr >> tr;
    int c[m+1], a[n+1];
    vector<int> up[n+1], h[2*n+2];
    iota(a+1, a+n+1, 1);
    for (int i = 1; i <= n; ++i)    h[i].pb(i);
    for (int i = 1; i <= m; ++i) {
        cin >> c[i];
        queue<int> Q;
        Q.push(c[i]);
        while (!Q.empty()) {
            int s = Q.front(); Q.pop();
            // if (2*s <= n && a[2*s] > c[i]) {
            //     a[2*s] /= 2;
            //     up[2*s].pb(i);
            // }
            // if (2*s+1 <= n && a[2*s+1] > c[i]) {
            //     a[2*s+1] /= 2;
            //     up[2*s+1].pb(i);
            // }
            // if (2*s <= n)   Q.push(2*s);
            // if (2*s+1 <= n) Q.push(2*s+1);
            if (!h[2*s].empty()) {
                for (auto x : h[2*s])   up[x].pb(i), h[s].pb(x);
                Q.push(2*s);
                h[2*s].clear();
            }
            if (!h[2*s+1].empty()) {
                for (auto x : h[2*s+1]) up[x].pb(i), h[s].pb(x);
                Q.push(2*s+1);
                h[2*s+1].clear();
            }
        }
    }
    for (int i = 1; i <= q; ++i) {
        int u, v;
        cin >> u >> v;
        int i1 = 0, i2 = 0, U = u, V = v;
        while (i1 < up[U].size() && i2 < up[V].size() && u != v) {
            if (up[U][i1] == up[V][i2]) {
                u /= 2, v /= 2, i1++, i2++;
            }
            else {
                if (up[U][i1] < up[V][i2])  
                    u /= 2, i1++;
                else
                    v /= 2, i2++;
            }
        }
        while (i1 < up[U].size() && u != v) u /= 2, i1++;
        while (i2 < up[V].size() && u != v) v /= 2, i2++;
        cout << (u == v ? max((i1 ? up[U][i1-1] : 0), (i2 ? up[V][i2-1] : 0)) : -1) << '\n';
    }
}