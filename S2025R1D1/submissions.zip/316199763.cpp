#include <bits/stdc++.h>

using namespace std;

stack<int> st;


void stack_clear(){
    while (!st.empty()) st.pop();
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n, m, k;
    cin >> n >> m >> k;
    vector<vector<int>> nums(n, vector<int>(m));
    for (int i = 0; i < n; i++){
        for (int j = 0; j < m; j++){
            cin >> nums[i][j];
        }
    }
    int low = 0;
    int high = n * m;
    int mid, ans = -1;
    vector<pair<int, int>> ans_coords;
    while (low <= high){
        mid = low + (high - low) / 2;
        vector<vector<bool>> reachable(n, vector<bool>(m, false));
        for (int i = 0; i < n; i++){
            stack_clear();
            for (int j = 0; j < m; j++){
                while (!st.empty() && st.top() <= nums[i][j]) st.pop();
                if (!st.empty() && st.top() - mid <= nums[i][j]) reachable[i][j] = true;
                st.push(nums[i][j]);
            }
            stack_clear();
            for (int j = m - 1; j >= 0; j--){
                while (!st.empty() && st.top() <= nums[i][j]) st.pop();
                if (!st.empty() && st.top() - mid <= nums[i][j]) reachable[i][j] = true;
                st.push(nums[i][j]);
            }
        }
        for (int j = 0; j < m; j++){
            stack_clear();
            for (int i = 0; i < n; i++){
                while (!st.empty() && st.top() <= nums[i][j]) st.pop();
                if (!st.empty() && st.top() - mid <= nums[i][j]) reachable[i][j] = true;
                st.push(nums[i][j]);
            }
            stack_clear();
            for (int i = n - 1; i >= 0; i--){
                while (!st.empty() && st.top() <= nums[i][j]) st.pop();
                if (!st.empty() && st.top() - mid <= nums[i][j]) reachable[i][j] = true;
                st.push(nums[i][j]);
            }
        }
        vector<pair<int, int>> coords, extra_coords;
        for (int i = 0; i < n; i++){
            for (int j = 0; j < m; j++){
                if (!reachable[i][j]) coords.push_back(make_pair(i, j));
                else extra_coords.push_back(make_pair(i, j));
            }
        }
        if (coords.size() <= k){
            ans = mid;
            high = mid - 1;
            ans_coords.clear();
            for (int i = 0; i < coords.size(); i++) ans_coords.push_back(coords[i]);
            for (int i = 0; i < k - coords.size(); i++) ans_coords.push_back(extra_coords[i]);
        }
        else{
            low = mid + 1;
        }
    }
    cout << ans << endl;
    if (ans != -1){
        for (int i = 0; i < ans_coords.size(); i++)
            cout << ans_coords[i].first + 1 << " " << ans_coords[i].second + 1<< endl;
    }
    return 0;
}
/*

*/
