#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 490000 + 10;

const int inf = 1e16;

int n, m, in[N], niz[N], k, vatafak[N];
vector<vector<int>> a, dp;
vector<int> g[N];

int kod(int i, int j) {
  return ((i - 1) * m + j);
}

int check(int d) {
  dp.resize(n + 1);
  for(int i = 1; i <= n; i++) dp[i].resize(m + 1);
  for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) dp[i][j] = inf;
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
     // int pos1 =
    }
  }
}

void init() {
  for(int i = 1; i <= n * m; i++) vatafak[i] = inf;
}

pair<int,int> inverz(int val) {
  return {(val - 1) / m + 1, (val - 1) % m + 1};
}

void Dfs(int x) {
  int cost = 0, cnt = 0;
  queue<int> q;
  q.push(x);
  vatafak[x] = 0;
  while(!q.empty()) {
    int u = q.front();
    q.pop();
    cnt++;
    for(int j : g[u]) {
      in[j]--;
      if(!in[j]) {
        vatafak[j] = min(vatafak[j], niz[u] - niz[j]);
        q.push(j);
      }
    }
  }
  /*vector<pair<int,int>> vec;
  for(int i = 1; i <= n * m; i++) vec.push_back({vatafak[i], i});
  sort(vec.rbegin(), vec.rend());
  for(int i = 0; i <= k; i++) cout << vec[i].first << " " << vec[i].second << endl;*/
  //return cost;
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> n >> m >> k;
  a.resize(n + 1);
  init();
  for(int i = 1; i <= n; i++) a[i].resize(m + 1);
  int x, y;
  for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) cin >> a[i][j];
  vector<pair<int, int>> v;
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      niz[kod(i, j)] = a[i][j];
      v.push_back({a[i][j], kod(i, j)});
      if(a[i][j] == m * n) {
        x = i;
        y = j;
      }
      /*if(i + 1 <= n && a[i][j] > a[i + 1][j]) {
        g[kod(i, j)].push_back(kod(i + 1, j)), in[kod(i + 1, j)]++;
      }
      if(i - 1 >= 1 && a[i][j] > a[i - 1][j]) {
        g[kod(i, j)].push_back(kod(i - 1, j)), in[kod(i - 1, j)]++;
      }
      if(j + 1 <= m && a[i][j] > a[i][j + 1]) {
        g[kod(i, j)].push_back(kod(i, j + 1)), in[kod(i, j + 1)]++;
      }
      if(j - 1 >= 1 && a[i][j] > a[i][j - 1]) {
        g[kod(i, j)].push_back(kod(i, j - 1)), in[kod(i, j - 1)]++;
      }*/
      for(int k = j + 1; k <= m; k++) {
        if(a[i][k] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(i, k));
        in[kod(i, k)]++;
      }
      for(int k = j - 1; k >= 1; k--) {
        if(a[i][k] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(i, k));
        in[kod(i, k)]++;
      }
      for(int k = i + 1; k <= n; k++) {
        if(a[k][j] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(k, j));
        in[kod(k, j)]++;
      }
      for(int k = i - 1; k >= 1; k--) {
        if(a[k][j] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(k, j));
        in[kod(k, j)]++;
      }
    }
  }
  //cout << kod(x, y) << endl;
 // cout << inverz(kod(x, y)).first << " " << inverz(kod(x, y)).second << endl;
  sort(v.rbegin(), v.rend());
  vector<pair<int,int>> skr;
  for(auto xx : v) {
    if(vatafak[xx.second] == inf) {
      if(k == 0) {
        cout << -1;
        return 0;
      }
      skr.push_back(inverz(xx.second));
      Dfs(xx.second);
      k--;
    }
  }
  vector<pair<int,int>> sol;
  for(int i = 1; i <= n * m; i++) sol.push_back({vatafak[i], i});
  sort(sol.rbegin(), sol.rend());
  for(int i = 0; i < k; i++) skr.push_back(inverz(sol[i].second));
  cout << sol[k].first << endl;
  for(auto g : skr) cout << g.first << " " << g.second << endl;
}
//(i - 1)*m + j = x
// (i - 1) = (x - j) / m
