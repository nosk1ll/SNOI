#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define ios ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define endl '\n'
#define pb push_back
using namespace std;
using namespace __gnu_pbds;
typedef tree<pair<int,int>, null_type, less<pair<int,int>>, rb_tree_tag, tree_order_statistics_node_update> os;
typedef unsigned long long ull;
typedef long long ll;
int main(){
    int n, m, q;
    cin>>n>>m>>q;
    vector<vector<int>> g(n+1);
    vector<int> dog(m);
    for(int i = 0;i<n-1;i++){
        int u, v;
        cin>>u>>v;
        g[u].pb(v);
        g[v].pb(u);
    }
    for(int i = 0;i<m;i++)cin>>dog[i];
    while(q--){
        int a, b;
        cin>>a>>b;
        int tr = 0;
        while(a!=b){
            a=max(1, a/2);
            b = max(1, b/2);
            tr++;
        }
        if(tr>m)cout<<-1<<endl;
        else cout<<tr<<endl;
    }


}