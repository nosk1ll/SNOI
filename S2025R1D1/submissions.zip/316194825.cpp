#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;
const ll maxn = 35;
bool a[maxn][maxn];
ll dp[maxn][maxn];
ll n = 31;
void tc(){
	ll k;
	cin >> k;
	vector<pll> ans;
	for(ll i = 1;i<n-1;i++) {
		if(i>1) ans.pb({i,i});
		if(i+1<n-1) {
			ans.pb({i,i+1});
			ans.pb({i+1,i});
		}
	}
	a[1][1] = 1;
	for(pll p : ans) a[p.fi][p.sc] = 1;
	for(ll i = 1;i<=n;i++) for(ll j = 1;j<=n;j++) dp[i][j] = 0;
	dp[1][1] = 1;
	ll x = k/2;
	ll y = k-x;
	for(ll j = 0;j<n-1;j++) {
		if((1LL<<j)&x) {
			//dbg(j);
			for(ll c = j+2;c<n;c++) if(!a[c][j+1]) ans.pb({c,j+1});
		}
	}
	for(ll j = 0;j<n-1;j++) {
		if((1LL<<j)&y) {
			//dbg(j);
			for(ll c = j+2;c<n;c++) if(!a[j+1][c]) ans.pb({j+1,c});
		}
	}
	//for(pll p : ans) cerr<<p.fi<<" "<<p.sc<<endl;
	for(ll i = 1;i<n;i++) ans.pb({n,i});
	for(ll i = 1;i<n;i++) ans.pb({i,n});
	ans.pb({n,n});
	for(pll p : ans) a[p.fi][p.sc] = 1;
	for(ll i = 1;i<=n;i++) for(ll j = 1;j<=n;j++) if(!a[i][j]) ans.pb({i,j});
	cout<<n<<endl;
	for(pll p : ans) cout<<p.fi<<" "<<p.sc<<endl;
	for(ll i = 1;i<=n;i++) for(ll j = 1;j<=n;j++) a[i][j] = 0;
	return;
	for(pll p : ans) {
		ll x = p.fi,y = p.sc;
		dp[x][y] = dp[x-1][y] + dp[x][y-1];
		cerr<<x<< " "<<y<< " "<<dp[x][y]<<endl;
	}
	dbg(dp[n][n]);
}

int main(){
	ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
	int t; t = 1;
	cin >> t;
	while(t--){
		tc();
	}
	return (0-0);
}