#include<bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;

void solve() {
	int k;cin>>k;
	if(k==1){
		cout<<0<<'\n';return;
	}
	if(k<=150){
		cout<<k<<'\n';
		vector<pii>v;
		for(int i=2;i<k;i++){
			for(int j=0;j<k;j++){
				if(j==k-1){continue;}
				v.emplace_back(i+1,j+1);
			}
		}
		sort(v.begin(),v.end());
		for(int i=2;i<=k;i++){
			cout<<1<<' '<<i<<'\n';

		}
		for(int i=1;i<=k;i++){
			cout<<2<<' '<<i<<'\n';
		}
		for(int j=3;j<=k;j++){
			cout<<j<<' '<<k<<'\n';
		}
		for(pii&x:v){
			cout<<x.fi<<' '<<x.se<<'\n';
		}
	}else{
		cout<<0<<'\n';
	}
}
int32_t main() {
	ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int32_t T=1;cin>>T;
	while(T--) {
		solve();
	}
	return 0;
}