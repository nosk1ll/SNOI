#include <bits/stdc++.h>

using namespace std;


void solve(){
    int k, kc;
    cin >> k;
    if (k == 1){
        cout << 1 << endl;
        return;
    }
    cout << k << endl;
    for (int j = 2; j <= k; j++) cout << 1 << " " << j << endl;
    for (int j = 1; j <= k; j++) cout << 2 << " " << j << endl;
    for (int i = 3; i <= k; i++) cout << i << " " << k << endl;
    for (int i = 3; i <= k; i++){
        for (int j = 1; j < k; j++) cout << i << " " << j << endl;
    }
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) solve();
    return 0;
}
/*

*/
