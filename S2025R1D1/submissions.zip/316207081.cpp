#include <bits/stdc++.h>

using namespace std;
#define pb push_back

const int N = 1e6 + 5;
vector<int> ord, g[N];
bool vis[N];
void dfs(int s) {
    vis[s] = 1;
    for (auto u : g[s]) {
        if (vis[u]) continue;
        dfs(u);
    }
    ord.pb(s);
}
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, m, K;
    cin >> n >> m >> K;
    int a[n+1][m+1];
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j)    cin >> a[i][j];
    }                                                                                                                                                                                                                                                                                                                               
    int l = 0, r = 1e9;
    pair<int, vector<int>> ans = {-1, {}};
    auto H = [&](int x, int y) {
        return (m+1) * x + y;
    };
    while (l <= r) {
        int d = (l + r)/2;
        for (int i = H(1, 1); i <= H(n, m); ++i)    g[i].clear();
        fill(vis+H(1, 1), vis+H(n, m)+1, 0);
        ord.clear();
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= m; ++j) {
                for (int k = i-1; k >= 1 && a[k][j] <= a[i][j]; --k) {
                    if (a[k][j] >= a[i][j] - d) g[H(i, j)].pb(H(k, j));
                }
                for (int k = i+1; k <= n && a[k][j] <= a[i][j]; ++k) {
                    if (a[k][j] >= a[i][j] - d) g[H(i, j)].pb(H(k, j));
                }
                for (int k = j-1; k >= 1 && a[i][k] <= a[i][j]; --k) {
                    if (a[i][k] >= a[i][j] - d) g[H(i, j)].pb(H(i, k));
                }
                for (int k = j+1; k <= m && a[i][k] <= a[i][j]; ++k) {
                    if (a[i][k] >= a[i][j] - d) g[H(i, j)].pb(H(i, k));
                }
            }
        }
        for (int i = H(1, 1); i <= H(n, m); ++i) {
            if (i % (m + 1) == 0)   continue;
            if (!vis[i])    dfs(i);
        }
        reverse(ord.begin(), ord.end());
        fill(vis+H(1, 1), vis+H(n, m)+1, 0);
        vector<int> v;
        for (int i = 0; i < ord.size(); ++i) {
            for (auto u : g[ord[i]])    vis[u] = 1;
            if (vis[ord[i]])    continue;
            v.pb(ord[i]);
        }
        if (v.size() <= K)
            r = d-1, ans = {d, v};
        else
            l = d+1;
    }
    if (ans.first == -1) {
        cout << -1 << '\n';
        return 0;
    }
    cout << ans.first << '\n';
    for (auto x : ans.second) {
        cout << x / (m+1) << ' ' << x % (m+1) << '\n';
    }
    for (int i = 1; i <= K - ans.second.size(); ++i)    cout << "1 1\n";
}