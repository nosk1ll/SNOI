#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define ios ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define endl '\n'
#define pb push_back
using namespace std;
using namespace __gnu_pbds;
typedef tree<pair<int,int>, null_type, less<pair<int,int>>, rb_tree_tag, tree_order_statistics_node_update> os;
typedef unsigned long long ull;
typedef long long ll;
void dfs(int n, int m, const vector<vector<int>>& a, vector<vector<bool>>& visited, int itr, int jtr, int d){
    visited[itr][jtr]=true;
    for(int i = itr - 1;i>=0;i--){
        if(a[i][jtr]>a[itr][jtr])break;
        if(a[itr][jtr]-d<=a[i][jtr]){
            if(!visited[i][jtr]){
                visited[i][jtr]=true;
                dfs(n, m, a, visited, i, jtr, d);
            }
        }
    }
    for(int i = itr + 1;i<n;i++){
        if(a[i][jtr]>a[itr][jtr])break;
        if(a[itr][jtr]-d<=a[i][jtr]){
            if(!visited[i][jtr]){
                visited[i][jtr]=true;
                dfs(n, m, a, visited, i, jtr, d);
            }
        }
    }
    for(int j = jtr - 1;j>=0;j--){
        if(a[itr][j]>a[itr][jtr])break;
        if(a[itr][jtr]-d<=a[itr][j]){
            if(!visited[itr][j]){
                visited[itr][j]=true;
                dfs(n, m, a, visited, itr, j, d);
            }
        }
    }
    for(int j = jtr + 1;j<m;j++){
        if(a[itr][j]>a[itr][jtr])break;
        if(a[itr][jtr]-d<=a[itr][j]){
            if(!visited[itr][j]){
                visited[itr][j]=true;
                dfs(n, m, a, visited, itr, j, d);
            }
        }
    }
}
bool check(int n, int m, const vector<vector<int>>& a, const vector<pair<int, pair<int,int>>>& sorted, int d, int k, vector<vector<bool>>& visited){
    for(int i = 0;i<n;i++)for(int j = 0;j<m;j++)visited[i][j]=false;
    int tr = 0;
    for(int ii = sorted.size()-1; ii>=0;ii--){
        int i = sorted[ii].second.first;
        int j = sorted[ii].second.second;
        if(!visited[i][j]){
            tr++;
            dfs(n, m, a, visited, i, j, d);
        }
    }
    //cout<<tr<<endl;
    if(tr<=k)return true;
    else return false;
}
void vrati(int n, int m, const vector<vector<int>>& a, const vector<pair<int, pair<int,int>>>& sorted, int d, vector<pair<int, int>>& ruteri, vector<vector<bool>>& visited){
    for(int i = 0;i<n;i++)for(int j = 0;j<m;j++)visited[i][j]=false;
    int tr = 0;
    for(int ii = sorted.size()-1; ii>=0;ii--){
        int i = sorted[ii].second.first;
        int j = sorted[ii].second.second;
        if(!visited[i][j]){
            tr++;
            ruteri.push_back({i + 1, j + 1});
            dfs(n, m, a, visited, i, j, d);
        }
    }
}
int main(){
    int n, m, k;
    cin>>n>>m>>k;
    vector<vector<int>> a(n, vector<int>(m));
    vector<pair<int, pair<int,int>>> sorted;
    vector<vector<bool>> visited(n, vector<bool>(m, false));
    for(int i = 0;i<n;i++){
        for(int j = 0;j<m;j++){
            cin>>a[i][j];
            sorted.push_back({a[i][j], {i, j}});
        }
    }
    sort(sorted.begin(), sorted.end());
    int l = 0, r = 1e9;
    int res = -1;
    while(l<=r){
        int mid = (l + r)/2;
        if(check(n, m, a, sorted, mid, k, visited)){//ako je broj postavljenih <= k
            res = mid;
            r = mid - 1;
        }  
        else l = mid + 1;
    }
    cout<<res<<endl;
    if(res!=-1){
        vector<pair<int,int>> ruteri;
        vrati(n, m, a, sorted, res, ruteri, visited);
        for(pair<int,int> x : ruteri){
            cout<<x.first<<" "<<x.second<<endl;
        }
    }

}