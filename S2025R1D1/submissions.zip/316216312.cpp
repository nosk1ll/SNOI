#include <bits/stdc++.h>
#define Debug(x) cout << #x << " = " << x << ";\n"
using namespace std;
int N, M, K;
int A[106][106];
int IN[106][106];
struct EDGE
{
  int i, j, k, l, w;
  const bool operator < (const EDGE &e) {return w < e.w;}
};
vector <EDGE> E;
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> K;
  if(K == (N * M))
  {
    cout << "0\n";
    for(int i = 1; i <= N; i++)
    {
      for(int j = 1; j <= M; j++) cout << i << ' ' << j << '\n';
    }
    return 0;
  }
  for(int i = 1; i <= N; i++)
  {
    for(int j = 1; j <= M; j++) cin >> A[i][j];
  }
  for(int i = 1; i <= N; i++)
  {
    for(int j = 1; j <= M; j++)
    {
      for(int k = i - 1; (k >= 1) && (A[k][j] < A[i][j]); k--) E.push_back({i, j, k, j, A[i][j] - A[k][j]});
      for(int k = i + 1; (k <= N) && (A[k][j] < A[i][j]); k++) E.push_back({i, j, k, j, A[i][j] - A[k][j]});
      for(int k = j - 1; (k >= 1) && (A[i][k] < A[i][j]); k--) E.push_back({i, j, i, k, A[i][j] - A[i][k]});
      for(int k = j + 1; (k <= M) && (A[i][k] < A[i][j]); k++) E.push_back({i, j, i, k, A[i][j] - A[i][k]});
    }
  }
  sort(E.begin(), E.end());
  E.push_back({0, 0, 0, 0, INT_MAX});
  int temp = N * M;
  for(int i = 0; i < (E.size() - 1); i++)
  {
    auto Check = [&]()
    {
      if(temp != K) return;
      cout << E[i].w << '\n';
      for(int k = 1; k <= N; k++)
      {
        for(int l = 1; l <= M; l++) if(!IN[k][l]) cout << k << ' ' << l << '\n';
      }
      exit(0);
    };
    while(E[i].w == E[i + 1].w)
    {
      temp -= !IN[E[i].k][E[i].l];
      IN[E[i].k][E[i].l]++;
      Check();
      i++;
    }
    temp -= !IN[E[i].k][E[i].l];
    IN[E[i].k][E[i].l]++;
    Check();
  }
  cout << "-1\n";

  return 0;
}
