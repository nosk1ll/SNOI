#include<bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);cerr.tie(0);

int main(){
ubrzaj

int iBrojTestova;
cin>>iBrojTestova;
while(iBrojTestova--){
long long llUlazK;
cin>>llUlazK;
if(llUlazK==1){
cout<<1<<"\n";
continue;
}
vector<int>viBitovi;
long long llPrivremeno=llUlazK;
while(llPrivremeno>0){
viBitovi.push_back(llPrivremeno&1);
llPrivremeno>>=1;
}
// string s="";
//reverse(s.begin(),s.end());

int iBrojBitova=viBitovi.size();
int iDimenzija=max(iBrojBitova+1,30);
cout<<iDimenzija<<"\n";

vector<pair<int,int>>vpiOperacije;
vpiOperacije.reserve(iDimenzija*iDimenzija-1);


// int iB=42;
//

for(int iKol=2;iKol<=iDimenzija;iKol++)
vpiOperacije.emplace_back(1,iKol);

for(int iRed=2;iRed<=iDimenzija;iRed++)
vpiOperacije.emplace_back(iRed,1);

for(int iIndeks=1;iIndeks<iBrojBitova;iIndeks++)
if(!viBitovi[iIndeks])continue;
else{
int iSuma=iIndeks+2;
for(int iRed=1;iRed<=iDimenzija;iRed++){
int iKolona=iSuma-iRed;
if(iKolona<1||iKolona>iDimenzija)continue;
if(iRed==1||iKolona==1)continue;
vpiOperacije.emplace_back(iRed,iKolona);
}
}

for(int iRed=2;iRed<=iDimenzija;iRed++)
for(int iKolona=2;iKolona<=iDimenzija;iKolona++){
int iSuma=iRed+iKolona;
int iIndeks=iSuma-2;
if(iIndeks>=0&&iIndeks<iBrojBitova&&viBitovi[iIndeks])continue;
vpiOperacije.emplace_back(iRed,iKolona);
}

for(int iIndeks=0;iIndeks<iDimenzija*iDimenzija-1;iIndeks++)
cout<<vpiOperacije[iIndeks].first<<" "<<vpiOperacije[iIndeks].second<<"\n";
}
return 0;
}
