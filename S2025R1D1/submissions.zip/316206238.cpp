#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define ll long long
#define int ll
#define ldb long double
typedef pair<ll, ll> pl;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend() 
const int N=1e5+10, M=1e3+10;

int n, m, q, par[N], dep[N];
bool da[M][M]; 
vi g[N];
set<pi> anc[N]; 

void dfs(int x, int p) {
	par[x]=p;
	if (p!=-1) 
		dep[x]=dep[p]+1; 
	if (x!=1) {
		for (auto z:anc[p]) { 
			anc[x].ins(mp(z.f, z.s+1));
			da[x][z.f]=true; 
		}
		anc[x].ins(mp(p, 1)); 
		da[x][p]=true;
	}
	for (int u:g[x]) 
		if (u!=p)
			dfs(u, x);  
}

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

	cin >> n >> m >> q;
	for (int i=1; i<n; i++) {
		int u, v; cin >> u >> v;
		g[u].pb(v);
		g[v].pb(u);
	}	
	vi c(m);
	for (int i=0; i<m; i++) 
		cin >> c[i];  
	if (max(n, m)<=1000) { //21p
		for (int i=1; i<=n; i++) 
			for (int j=1; j<=m; j++) 
				da[i][j]=false; 
		dfs(1, -1);    
		while (q--) {
			int a, b; cin >> a >> b; 
			int res=-1; 
			for (int i=0; i<m; i++) {
				if (a==b) {
 					res=i;
					break;
				} 
				if (da[a][c[i]]) 
					a=par[a];
				if (da[b][c[i]]) 
					b=par[b];  
			}
			cout << res << nl;
		}
	} 
	return 0;
}