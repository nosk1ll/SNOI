#include <bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);cerr.tie(0);

vector<int>h;
vector<int>red;
vector<int> ulaznist;
int main(){
    
ubrzaj
int n,m,k,pom,N;
cin>>n>>m>>k;
vector< set<int> > rs1(n),cs1(m);
pom=m*m;
N=m*n;
h.resize(N);
for(int i=0;i<N;i++)cin>>h[i];
pom-=n;
ulaznist.resize(N);
red.resize(N);
pom++;
//if (pom>m*m) cout<<"Red\n";
iota(red.begin(),red.end(),0);
pom=0;
  sort(red.begin(),red.end(),
  [&](int a,int b){return h[a] > h[b]; });
//if (pom==0) cout<<"Red SORT\n";

auto rez=[&](int d){
for(int i=0; i<n; i++) rs1[i].clear();
for(int j=0; j<m; j++) cs1[j].clear();
pom=0;
//if (pom==0) cout<<"RS1 CS1 clear\n";
fill(ulaznist.begin(),ulaznist.end(),0);
int bio=0;
pom=0;
//if (pom==0) cout<<"RS1 CS1 clear\n";
for(int pomi : red){
bio++;
int i,j;
    i=pomi/m; j=pomi%m;
//cout<<bio<<" "<<i<<" "<<j;
auto &rs=rs1[i];
auto it=rs.lower_bound(j);
if(it != rs.begin()){
    auto manji=prev(it);
 //cout<<m<<" "<<i<<" "<<*manji;
int npomi=m*i+*manji;
//  cout<<h[npomi]<<" "<<h[pomi]<<"\n";
 if(h[npomi]-h[pomi]<=d)
    {if(ulaznist[pomi]==0) bio--; ulaznist[pomi]++;
    }
  }

    if(it!=rs.end())
    {
  int npomi=m*i+*it;
 //  cout<<h[npomi]<<" "<<h[pomi]<<"\n";
        if(h[npomi]-h[pomi]<=d)
    {
            if(ulaznist[pomi]==0) bio--;
        ulaznist[pomi]++;
    }
    }
rs.insert(j);
auto &cs=cs1[j];
    auto it2=cs.lower_bound(i);
if(it2!=cs.begin())
    {
auto veci=prev(it2);
//cout<<m<<" "<<j<<" "<<*veci;
//int npomi=j+(veci)*m;
//cout<<npomi<<"\n";
int npomi=j+(*veci)*m;
 //  cout<<h[npomi]<<" "<<h[pomi]<<"\n";
    if(h[npomi]-h[pomi]<=d){
        if(ulaznist[pomi]==0) bio--;
    ulaznist[pomi]++;
 }
}
    if(it2!=cs.end()){
int npomi=j+(*it2)*m;
 if(h[npomi]-h[pomi]<=d)
    {
        //  cout<<h[npomi]<<" "<<h[pomi]<<"\n";
    if(ulaznist[pomi]==0) bio--;
   ulaznist[pomi]++;
    }
  }
cs.insert(i);
 if(bio>k) return false;
}
 return bio<=k;
};
//BS po resenju
int lpoc=0;
pom=0;
//if (pom==0) cout<<max_element(h.begin(),h.end());
//else cout<<min_element(h.begin(),h.end());
int dkraj=*max_element(h.begin(),h.end())
           - *min_element(h.begin(),h.end());
int pisi=-1;
    while(lpoc<=dkraj)
      {
    int mid=(dkraj-lpoc)/2+lpoc;
        if(rez(mid))
        {
    pisi=mid; dkraj=mid-1;
        } else lpoc=mid + 1;
      }
pom=0;
//if (pom==0) cout<<max_element(h.begin(),h.end());
//else cout<<min_element(h.begin(),h.end());
if(pisi<0){cout <<-1<<"\n";return 0;}
rez(pisi);
vector<pair<int,int>>niz;
  for(int pomi:red){
        if(ulaznist[pomi]==0)
            {
        niz.emplace_back(pomi/m+1,pomi%m+1);
    if((int)niz.size()==k) break;
        }
    }
while((int)niz.size()<k)niz.push_back(niz[0]);
cout<<pisi<<"\n";
    for(auto &p:niz)
        cout <<p.first<<" "<<p.second<<"\n";
    return 0;
}
