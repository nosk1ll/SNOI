#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 490000 + 10;

const int inf = 1e16;

int n, m, in[N], niz[N], k, vatafak[N];
vector<vector<int>> a, dp;
vector<int> g[N];

int kod(int i, int j) {
  return ((i - 1) * m + j);
}

void init() {
  for(int i = 1; i <= n * m; i++) vatafak[i] = inf;
}

pair<int,int> inverz(int val) {
  return {(val - 1) / m + 1, (val - 1) % m + 1};
}

bool mark[N];

void Dfs(int x) {
  mark[x] = true;
  for(int j : g[x]) {
    if(!mark[j]) Dfs(j);
  }
}

int check(int d) {
  for(int i = 1; i <= n * m; i++) {
    g[i].clear();
    in[i] = 0;
    mark[i] = false;
  }
  vector<pair<int,int>> f;
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      f.push_back({a[i][j], kod(i, j)});
      if(i + 1 <= n && a[i][j] > a[i + 1][j] && a[i + 1][j] + d >= a[i][j]) {
        g[kod(i, j)].push_back(kod(i + 1, j));
        in[kod(i + 1, j)]++;
      }
      if(i - 1 >= 1 && a[i][j] > a[i - 1][j] && a[i - 1][j] + d >= a[i][j]) {
        g[kod(i, j)].push_back(kod(i - 1, j));
        in[kod(i - 1, j)]++;
      }
      if(j - 1 >= 1 && a[i][j] > a[i][j - 1] && a[i][j - 1] + d >= a[i][j]) {
        g[kod(i, j)].push_back(kod(i, j - 1));
        in[kod(i, j - 1)]++;
      }
      if(j + 1 >= 1 && a[i][j] > a[i][j + 1] && a[i][j + 1] + d >= a[i][j]) {
        g[kod(i, j)].push_back(kod(i, j + 1));
        in[kod(i, j + 1)]++;
      }
    }
  }
  sort(f.rbegin(), f.rend());
  int cnt = 0;
  for(auto x : f) {
    if(!mark[x.second]) {
      Dfs(x.second);
      cnt++;
    }
  }
  return cnt;
}

void Solve(int d) {
  for(int i = 1; i <= n * m; i++) {
    g[i].clear();
    in[i] = 0;
    mark[i] = false;
  }
  vector<pair<int,int>> f;
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      f.push_back({a[i][j], kod(i, j)});
      for(int k = i + 1; k <= n; k++) {
        if(a[k][j] > a[i][j]) break;
        if(a[i][j] > a[k][j] && a[k][j] + d >= a[i][j]) {
          g[kod(i, j)].push_back(kod(k, j));
        }
      }
      for(int k = i - 1; k >= 1; k--) {
        if(a[k][j] > a[i][j]) break;
        if(a[i][j] > a[k][j] && a[k][j] + d >= a[i][j]) {
          g[kod(i, j)].push_back(kod(k, j));
        }
      }
      for(int k = j + 1; k <= m; k++) {
        if(a[i][k] > a[i][j]) break;
        if(a[i][j] > a[i][k] && a[i][k] + d >= a[i][j]) {
          g[kod(i, j)].push_back(kod(i, k));
        }
      }
      for(int k = j - 1; k >= 1; k--) {
        if(a[i][k] > a[i][j]) break;
        if(a[i][j] > a[i][k] && a[i][k] + d >= a[i][j]) {
          g[kod(i, j)].push_back(kod(i, k));
        }
      }
    }
  }
  sort(f.rbegin(), f.rend());
  int cnt = 0;
  pair<int,int> last;
  for(auto x : f) {
    if(!mark[x.second]) {
      pair<int,int> cell = inverz(x.second);
      cout << cell.first << " " << cell.second << endl;
      last = cell;
      Dfs(x.second);
      cnt++;
    }
  }
  for(int i = 0; i < k - cnt; i++) cout << last.first << " " << last.second << endl;
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> n >> m >> k;
  /*if(k == n * m) {
    cout << 0 << "\n";
    for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) cout << i << " " << j << endl;
    return 0;
  }*/
  a.resize(n + 1);
  init();
  for(int i = 1; i <= n; i++) a[i].resize(m + 1);
  int x, y;
  for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) cin >> a[i][j];
  int l = 0, r = inf, ans = -1;
  while(l <= r) {
    int mid = l + r >> 1;
    if(check(mid) <= k) {
      ans = mid;
      r = mid - 1;
    } else {
      l = mid + 1;
    }
  }
  cout << ans << endl;
  if(ans == -1) return 0;
  Solve(ans);
}
//(i - 1)*m + j = x
// (i - 1) = (x - j) / m
