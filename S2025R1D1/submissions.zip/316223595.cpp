#include <bits/stdc++.h>

using namespace std;

const int max_n = 1e5 + 5;
const int max_d = 20;

int p[max_n][max_d] = {0};
int on_lvl[max_n][max_d];
int depth[max_n] = {0};
vector<int> adjs[max_n], zetoni[max_n];
int n, m, q;
int c_time = 1;


void dfs(int node, int prv){
    p[node][0] = prv;
    depth[node] = depth[prv] + 1;
    on_lvl[node][depth[node]] = c_time;
    zetoni[node].push_back(node);
    for (int child : adjs[node]) if (child != prv) dfs(child, node);
}


void pomeri(int node, int prv, bool start){
    if (!start){
        for (int elm : zetoni[node]){
            zetoni[prv].push_back(elm);
            on_lvl[elm][depth[prv]] = c_time;
        }
        zetoni[node].clear();
    }
    for (int child : adjs[node]) if (child != prv && zetoni[child].size() > 0){
        pomeri(child, node, false);
    }
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int u, v;
    cin >> n >> m >> q;
    for (int i = 1; i < n; i++){
        cin >> u >> v;
        adjs[u].push_back(v);
        adjs[v].push_back(u);
    }
    depth[1] = 1;
    dfs(1, 0);
    for (int d = 1; d < max_d; d++){
        for (int i = 1; i <= n; i++){
            p[i][d] = p[p[i][d - 1]][d - 1];
        }
    }
    int c;
    for (int i = 0; i < m; i++){
        cin >> c;
        c_time++;
        pomeri(c, p[c][0], true);
    }
    for (int i = 1; i <= n; i++){
        cout << i << ": ";
        for (int j = 0; j < 5; j++) cout << on_lvl[i][j] << " ";
        cout << endl;
    }
    int uc, vc;
    while (q--){
        cin >> u >> v;
        uc = u;
        vc = v;
        if (depth[u] < depth[v]) swap(u, v);
        int jump = max_d - 1;
        while (depth[u] != depth[v]){
            if (depth[p[u][jump]] >= depth[v]) u = p[u][jump];
            jump--;
        }
        if (u != v){
            jump = max_d - 1;
            while (p[u][0] != p[v][0]){
                if (p[u][jump] != p[v][jump]){
                    u = p[u][jump];
                    v = p[v][jump];
                }
                jump--;
            }
            u = p[u][0];
        }
        int lca = u;
        int first_leave = 0;
        int last_come = 0;
        if (on_lvl[uc][depth[lca]] != 0) last_come = on_lvl[uc][depth[lca]];
        if (on_lvl[vc][depth[lca]] != 0) last_come = max(last_come, on_lvl[vc][depth[lca]]);

        if (on_lvl[uc][depth[lca] - 1] != 0) first_leave = on_lvl[uc][depth[lca] - 1];
        if (on_lvl[vc][depth[lca] - 1] != 0) first_leave = min(first_leave, on_lvl[vc][depth[lca] - 1]);
        // ako su oba dosla na nivo
        if (on_lvl[uc][depth[lca]] != 0 && on_lvl[vc][depth[lca]] != 0 && (first_leave == 0 || first_leave > last_come)){
            cout << last_come - 1 << endl;
        }
        else if (on_lvl[uc][1] != 0 && on_lvl[vc][1] != 0){
            cout << max(on_lvl[uc][1], on_lvl[vc][1]) - 1 << endl;
        }
        else cout << -1 << endl;

    }
    return 0;
}
/*

*/
