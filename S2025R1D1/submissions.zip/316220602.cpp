#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 1e5 + 3;
const int M = 1e3 + 3;
const int logn = 19;
vector<int> adj[N];
int up[N][logn];
int dep[N], c[N];
int tin[N], tout[N], timer = 0;
int upp[M][M];

void dfs(int u, int p) {
    tin[u] = ++timer;
    dep[u] = dep[p]+1;
    up[u][0] = p;
    for (int j = 1; j < logn; j++)
        up[u][j] = up[up[u][j-1]][j-1];
    for (auto x : adj[u]) if (x != p) {
        dfs(x, u);
    }
    tout[u] = timer;
}

bool IsAncestor(int u, int v) {
    return (tin[u] <= tin[v] && tout[u] >= tout[v]);
}

int get_lca(int u, int v) {
    if (IsAncestor(u, v)) return u;
    if (IsAncestor(v, u)) return v;

    for (int j = logn-1; j >= 0; j--) {
        if (up[u][j] != 0 && !IsAncestor(up[u][j], v))
            u = up[u][j];
    }
    return up[u][0];
}

void solve() {
    int n, m, q; cin >> n >> m >> q;
    for (int i = 0; i < n-1; i++) {
        int u, v; cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    for (int i = 1; i <= m; i++) cin >> c[i];
    dfs(1, 0);


    if (*max_element(c + 1, c + m + 1) == 1) {
        while (q--) {
            int u, v; cin >> u >> v;
            if (dep[u] == dep[v]) {
                int lca = get_lca(u, v);
                cout << dep[u]-dep[lca] << "\n";
            } else {
                cout << max(dep[u], dep[v])-1 << "\n";
            }
        }
        return;
    }

    while (q--) {
        int u, v; cin >> u >> v;
        int ans = -1;
        for (int i = 1; i <= m; i++) {
            if (tin[c[i]] <= tin[u] && tout[c[i]] >= tout[u] && c[i] != u) {
                u = up[u][0];
            }
            if (tin[c[i]] <= tin[v] && tout[c[i]] >= tout[v] && c[i] != v) {
                v = up[v][0];
            }
            if (u == v) {
                ans = i; break;
            }
        }

        cout << ans << "\n";
    }
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}

/*
6 2 1
2 4
2 5
1 3
1 2
6 3
3 3
3 1
*/
