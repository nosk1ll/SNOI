#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=490050,inf=1e9;
int n,m,K;
vector<vector<int>>a;
vector<vector<int>>Lv,Rv,Gv,Dv;
vector<vector<int>>LV,RV,GV,DV;
pair<int,int>ind[N];
vector<pair<int,int>>temp;
vector<vector<bool>>was;
struct Node{int maks,i;};
Node Merge(Node a,Node b){if(a.maks>=b.maks)return a;return b;}
struct SegTree{
	int root,nc;
	vector<int>lc,rc;
	vector<Node>node;
	void Init(int n){lc.resize(2*n+10),rc.resize(2*n+10),node.resize(2*n+10);}
	void Update(int &c,int ss,int se,int qind,int qval){
		if(!c)c=++nc,node[c]={0,ss};
		if(ss==se){node[c]={qval,ss};return;}
		int mid=ss+se>>1;
		if(qind<=mid)Update(lc[c],ss,mid,qind,qval);
		else Update(rc[c],mid+1,se,qind,qval);
		node[c]=Merge(node[lc[c]],node[rc[c]]);
	}
	Node Get(int &c,int ss,int se,int qs,int qe){
		if(!c)c=++nc,node[c]={0,ss};
		if(qs>qe||se<qs||qe<ss)return {0,0};
		if(qs<=ss&&se<=qe)return node[c];
		int mid=ss+se>>1;return Merge(Get(lc[c],ss,mid,qs,qe),Get(rc[c],mid+1,se,qs,qe));
	}
}ST1[N],ST2[N];
bool Probaj(int D){
	queue<pair<int,int>>kju;
	temp.clear();
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) was[i][j]=false;
	int k=K;
	bool moze=true;
	for(int I=m*n;I>=1;I--){
		int x=ind[I].fi,y=ind[I].se;
		if(was[x][y]) continue;
		k--;temp.pb({x,y});
		if(k<0){moze=false;break;}
		kju.push({x,y});
		while(!kju.empty()){
			x=kju.front().fi,y=kju.front().se;kju.pop();
			/*for(int j=y+1;j<=m;j++){
				if(a[x][j]>a[x][y]) break;
				if(was[x][j]||abs(a[x][y]-a[x][j])>D) continue;
				kju.push({x,j});
				was[x][j]=true;
			}
			for(int j=y-1;j>=1;j--){
				if(a[x][j]>a[x][y]) break;
				if(was[x][j]||abs(a[x][y]-a[x][j])>D) continue;
				kju.push({x,j});
				was[x][j]=true;
			}
			for(int i=x+1;i<=n;i++){
				if(a[i][y]>a[x][y]) break;
				if(was[i][y]||abs(a[x][y]-a[i][y])>D) continue;
				kju.push({i,y});
				was[i][y]=true;
			}
			for(int i=x-1;i>=1;i--){
				if(a[i][y]>a[x][y]) break;
				if(was[i][y]||abs(a[x][y]-a[i][y])>D) continue;
				kju.push({i,y});
				was[i][y]=true;
			}*/
			/*int l,r,z;

			l=y+1,r=Rv[x][y]-1;
			z=ST1[x].Get(ST1[x].root,1,m,l,r).i;
			if(z>0&&!was[x][z]&&abs(a[x][y]-a[x][z])<=D){kju.push({x,z});was[x][z]=true;}

			l=Lv[x][y]+1,r=y-1;
			z=ST1[x].Get(ST1[x].root,1,m,l,r).i;
			if(z>0&&!was[x][z]&&abs(a[x][y]-a[x][z])<=D){kju.push({x,z});was[x][z]=true;}

			l=x+1,r=Dv[x][y]-1;
			z=ST2[y].Get(ST2[y].root,1,n,l,r).i;
			if(z>0&&!was[z][y]&&abs(a[x][y]-a[z][y])<=D){kju.push({z,y});was[z][y]=true;}

			l=Gv[x][y]+1,r=x-1;
			z=ST2[y].Get(ST2[y].root,1,n,l,r).i;
			if(z>0&&!was[z][y]&&abs(a[x][y]-a[z][y])<=D){kju.push({z,y});was[z][y]=true;}*/
			int z;

			z=RV[x][y];
			if(z>0&&!was[x][z]&&abs(a[x][y]-a[x][z])<=D){kju.push({x,z});was[x][z]=true;}

			z=LV[x][y];
			if(z>0&&!was[x][z]&&abs(a[x][y]-a[x][z])<=D){kju.push({x,z});was[x][z]=true;}

			z=DV[x][y];
			if(z>0&&!was[z][y]&&abs(a[x][y]-a[z][y])<=D){kju.push({z,y});was[z][y]=true;}

			z=GV[x][y];
			if(z>0&&!was[z][y]&&abs(a[x][y]-a[z][y])<=D){kju.push({z,y});was[z][y]=true;}
		}
	}
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) was[i][j]=false;
	return moze;
}
int main(){
	scanf("%i%i%i",&n,&m,&K);
	for(int i=0;i<=n;i++){
		vector<int>nesto(m+1,0);
		a.pb(nesto);
		Lv.pb(nesto);
		Rv.pb(nesto);
		Gv.pb(nesto);
		Dv.pb(nesto);
		LV.pb(nesto);
		RV.pb(nesto);
		GV.pb(nesto);
		DV.pb(nesto);
		vector<bool>nesto1(m+1,0);
		was.pb(nesto1);
	}
	for(int i=1;i<=n;i++) for(int j=1,x;j<=m;j++) scanf("%i",&x),a[i][j]=x,ind[a[i][j]]={i,j};
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			Lv[i][j]=0;
			Rv[i][j]=m+1;
			Gv[i][j]=0;
			Dv[i][j]=n+1;
		}
	}
	for(int i=1;i<=n;i++){
		vector<int>mono;
		for(int j=1;j<=m;j++){
			while(!mono.empty()&&a[i][j]>a[i][mono.back()]){
				Rv[i][mono.back()]=j;
				mono.pop_back();
			}
			if(mono.size())Lv[i][j]=mono.back();
			mono.pb(j);
		}
	}
	for(int j=1;j<=m;j++){
		vector<int>mono;
		for(int i=1;i<=n;i++){
			while(!mono.empty()&&a[i][j]>a[mono.back()][j]){
				Dv[mono.back()][j]=i;
				mono.pop_back();
			}
			if(mono.size())Gv[i][j]=mono.back();
			mono.pb(i);
		}
	}
	/*for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			printf("%i ",Dv[i][j]);
		}
		printf("\n");
	}*/
	for(int i=1;i<=n;i++){
		ST1[i].Init(m+1);
		for(int j=1;j<=m;j++) ST1[i].Update(ST1[i].root,1,m,j,a[i][j]);
	}
	for(int j=1;j<=m;j++){
		ST2[j].Init(n+1);
		for(int i=1;i<=n;i++) ST2[j].Update(ST2[j].root,1,n,i,a[i][j]);
	}
	for(int x=1;x<=n;x++){
		for(int y=1;y<=m;y++){
			int l,r,z;

			l=y+1,r=Rv[x][y]-1;
			z=ST1[x].Get(ST1[x].root,1,m,l,r).i;
			RV[x][y]=z;

			l=Lv[x][y]+1,r=y-1;
			z=ST1[x].Get(ST1[x].root,1,m,l,r).i;
			LV[x][y]=z;

			l=x+1,r=Dv[x][y]-1;
			z=ST2[y].Get(ST2[y].root,1,n,l,r).i;
			DV[x][y]=z;

			l=Gv[x][y]+1,r=x-1;
			z=ST2[y].Get(ST2[y].root,1,n,l,r).i;
			GV[x][y]=z;
		}
	}
	int l=0,r=inf,res=-1;
	vector<pair<int,int>>res1;
	while(l<=r){
		int mid=l+r>>1;
		if(Probaj(mid)){
			res=mid;
			res1=temp;
			r=mid-1;
		}
		else l=mid+1;
	}
	printf("%i\n",res);
	if(res!=-1){
		if(res1.size()<K){
			for(auto [u,v]:res1) was[u][v]=true;
			for(int i=1;i<=n;i++) for(int j=1;j<=m;j++){
				if(was[i][j]||res1.size()>=K) continue;
				res1.pb({i,j});
			}
		}
		for(auto [u,v]:res1) printf("%i %i\n",u,v);
	}
    return 0;
}
