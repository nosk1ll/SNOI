#include <bits/stdc++.h>
//#define int long long
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define sc second
//#define endl "\n"
#define pii pair<int,int>

using namespace std;

const int MAXN = 1e5+5;
const int mod7 = 1e9+7;
const long long inf = 1e18;

struct str{int x,a,b;};

class cmp {
    public:
       bool operator()(str a, str b){
           if(a.x == b.x)
           {
               if(a.a == b.a)return a.b > b.b;
               return a.a > b.a;
           }
           return a.x > b.x;
      }
};

vector<vector<int>> mat;
vector<vector<bool>> visited;
set<str, cmp>pq2;
int n,m,k;

void dfs(int i, int j, int mid)
{
    visited[i][j] = 1;
    pq2.erase({mat[i][j], i, j});
    if(i>1 && !visited[i-1][j] && mat[i-1][j] >= mat[i][j] - mid && mat[i][j] > mat[i-1][j])dfs(i-1,j,mid);
    if(j>1 && !visited[i][j-1] && mat[i][j-1] >= mat[i][j] - mid && mat[i][j] > mat[i][j-1])dfs(i,j-1,mid);
    if(i<n && !visited[i+1][j] && mat[i+1][j] >= mat[i][j] - mid && mat[i][j] > mat[i+1][j])dfs(i+1,j,mid);
    if(j<m && !visited[i][j+1] && mat[i][j+1] >= mat[i][j] - mid && mat[i][j] > mat[i][j+1])dfs(i,j+1,mid);
}

signed main()
{
    ios_base::sync_with_stdio(false),cin.tie(0), cout.tie(0);
    int tt=1;
    //cin >> tt;
    while(tt--)
    {

        cin >> n >> m >> k;
        set<str, cmp>pq;
        mat = vector<vector<int>>(n+1, vector<int>(m+1));
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m; j++)
            {
                int x;cin >> x;
                mat[i][j] = x;
                pq.insert({x,i,j});
            }
        }
        int l = 0;
        int r = n*m;
        int resenje = n*m+1;
        vector<pii> prethodnoresenje;
        while(l<=r)
        {
            int mid = l+ r >> 1;
            int broj_oznacenih = 0;
            int k2 = k;
            pq2 = pq;
            visited = vector<vector<bool>>(n+1, vector<bool>(m+1, false));
            vector<pii> trresenje;
            while(!pq2.empty() && k2>0)
            {
                str tr = *pq2.begin();
                k2--;
                trresenje.pb({tr.a, tr.b});
                dfs(tr.a, tr.b, mid);
                //for(auto x: pq2)cout << x.x << x.a << x.b << endl;
                /*
                while(!q.empty())
                {
                    pii trenutno = q.front();
                    int i = trenutno.fi;
                    int j = trenutno.sc;
                    q.pop();
                    visited[i][j] = 1;
                    pq2.erase({mat[i][j], i, j});
                    if(i> 1 && !visited[i-1][j] && mat[i-1][j] >= mat[i][j] - mid && mat[i][j] > mat[i-1][j])q.push({i-1,j}),visited[i-1][j] = 1;
                    if(j> 1 && !visited[i][j-1] && mat[i][j-1] >= mat[i][j] - mid && mat[i][j] > mat[i][j-1])q.push({i,j-1}),visited[i][j-1] = 1;
                    if(i<n && !visited[i+1][j] && mat[i+1][j] >= mat[i][j] - mid && mat[i][j] > mat[i+1][j])q.push({i+1,j}),visited[i+1][j] = 1;
                    if(j<m && !visited[i][j+1] && mat[i][j+1] >= mat[i][j] - mid && mat[i][j] > mat[i][j+1])q.push({i,j+1}),visited[i][j+1] = 1;
                }
                */
            }
            bool moze;
            if(pq2.empty())moze = 1;
            else moze = 0;
            if(moze)
            {
                prethodnoresenje = trresenje;
                resenje = mid;
                r = mid - 1;
            }
            else l = mid+1;
        }
        if(resenje == n*m + 1)cout << -1 << endl;
        else
        {
            cout << resenje << endl;
            int a = prethodnoresenje.size();
            if(a < k)for(int i=0; i<k - a; i++)prethodnoresenje.pb(prethodnoresenje.back());
            for(auto x: prethodnoresenje)cout << x.fi << " " << x.sc << endl;
        }
    }
}
