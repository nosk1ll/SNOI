/// 407!3 +/ \!<07!\*
#include <bits/stdc++.h>
#pragma GCC optimize ("O3")
#pragma GCC target ("sse4")

using namespace std;

using ll = long long;
using db = long double; // or double, if TL is tight
using str = string; // yay python!

using pi = pair<int,int>;
using pl = pair<ll,ll>;
using pd = pair<db,db>;

using vi = vector<int>;
using vb = vector<bool>;
using vl = vector<ll>;
using vd = vector<db>;
using vs = vector<str>;
using vpi = vector<pi>;
using vpl = vector<pl>;
using vpd = vector<pd>;
using vvi = vector<vi>;
using vvl = vector<vl>;
using vvpi = vector<vpi>;

template<class T> using pq = priority_queue<T>;
template<class T> using pqg = priority_queue<T, vector<T>, greater<T>>;

// pairs
#define mp make_pair
#define f first
#define s second

// vectors
#define sz(x) int((x).size())
#define bg(x) begin(x)
#define all(x) bg(x), end(x)
#define rall(x) x.rbegin(), x.rend()
#define sor(x) sort(all(x))
#define rsz resize
#define ins insert
#define ft front()
#define bk back()
#define pb push_back
#define eb emplace_back
#define pf push_front
#define er erase
#define ub upper_bound
#define lb lower_bound

// loops
#define FOR(i,a,b) for (ll i = (a); i < (b); ++i)
#define F0R(i,a) FOR(i,0,a)
#define ROF(i,a,b) for (ll i = (b)-1; i >= (a); --i)
#define R0F(i,a) ROF(i,0,a)
#define trav(a,x) for (auto& a: x)

const int MOD = 1e9+7; // 998244353;
const int MX = 2e5+5;
const ll INF = 1e18; // not too close to LLONG_MAX
const db PI = acos((db)-1);
const int dx[4] = {1,0,-1,0}, dy[4] = {0,1,0,-1}; // for every grid problem!
const char nl = '\n';

template<class T> bool ckmin(T& a, const T& b) { return b < a ? a = b, 1 : 0; }
template<class T> bool ckmax(T& a, const T& b) { return a < b ? a = b, 1 : 0; }

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}

template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ", "; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? ", " : ""), __print(i); cerr << "}";}
void _print() {cerr << "\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;

template<typename T>
using indexed_set =  tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define ook order_of_key
#define fbo find_by_order

void _input() {return;}
template <typename T, typename... V>
void _input(T &t, V&... v) {cin >> (t); if (sizeof...(v))  _input(v...);}
void __input(vi &v, const int n){F0R(i, n)cin >> v[i];}
void __input(vvi &v, const int n, const int m){F0R(i, n)F0R(j, m)cin>>v[i][j];}

ll binpow(ll a, ll b) {
    ll res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a;
        a = a * a;
        b >>= 1;
    }
    return res;
}

void solve(){
    int n, m, k;
    cin >> n >> m >> k;
    vvi a(n, vi(m));
    F0R(i, n)F0R(j, m)cin >> a[i][j];
    int l = 0, r = 1e9 + 5, sol = -1;
    vvi fdp(n, vi(m));
    while(l <= r){
        int d = (l + r) / 2;
        vvi dp(n, vi(m));
        F0R(i, n){
            stack<int> s;
            F0R(j, m){
                while(sz(s) && s.top() < a[i][j])s.pop();
                if(sz(s) && s.top() - d <= a[i][j])dp[i][j] = 1;
                s.push(a[i][j]);
            }
        }
        F0R(i, n){
            stack<int> s;
            R0F(j, m){
                while(sz(s) && s.top() < a[i][j])s.pop();
                if(sz(s) && s.top() - d <= a[i][j])dp[i][j] = 1;
                s.push(a[i][j]);
            }
        }
        F0R(j, m){
            stack<int> s;
            F0R(i, n){
                while(sz(s) && s.top() < a[i][j])s.pop();
                if(sz(s) && s.top() - d <= a[i][j])dp[i][j] = 1;
                s.push(a[i][j]);
            }
        }
        F0R(j, m){
            stack<int> s;
            R0F(i, n){
                while(sz(s) && s.top() < a[i][j])s.pop();
                if(sz(s) && s.top() - d <= a[i][j])dp[i][j] = 1;
                s.push(a[i][j]);
            }
        }
        int cnt = 0;
        F0R(i, n)F0R(j, m)cnt += (!dp[i][j]);
        if(cnt > k)l = d + 1;
        else{
            r = d - 1;
            sol = d;
            fdp = dp;
        }
    }
    cout << sol << nl;
    if(sol == -1)return;
    vpi res;
    F0R(i, n)F0R(j, m){
        if(!fdp[i][j])res.pb({i + 1, j + 1});
    }
    if(sz(res) < k){
        F0R(i, n)F0R(j, m){
            if(fdp[i][j])res.pb({i + 1, j + 1});
            if(sz(res) == k)break;
        }
    }
    trav(el, res)cout << el.f << " " << el.s << nl;

}


/*

3 3 8
3 2 1
4 5 6
9 8 7

4 4 1
2 10 1 9
12 4 11 3
6 14 5 13
16 8 15 7
*/

int main()
{
    //ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int t; t = 1;while(t--){
        solve();
    }
    return 0;
}

