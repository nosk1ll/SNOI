#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=1e5+50,lg=5;
int C[N];
vector<int>E[N];
int par[N][lg+1],depth[N];
void DFSsetup(int u,int p){
	depth[u]=depth[p]+1;
	par[u][0]=p;
	for(int j=0;j<lg;j++) par[u][j+1]=par[par[u][j]][j];
	for(auto i:E[u]) if(i!=p) DFSsetup(i,u);
}
int LCA(int u,int v){
	if(depth[u]>depth[v])swap(u,v);
	for(int i=lg;i>=0;i--)if(depth[par[v][i]]>=depth[u]) v=par[v][i];if(u==v)return u;
	for(int i=lg;i>=0;i--)if(par[u][i]!=par[v][i])u=par[u][i],v=par[v][i];return par[u][0];
}
int main(){
    int n,m,q;scanf("%i%i%i",&n,&m,&q);
    for(int i=1;i<n;i++){
		int u,v;scanf("%i%i",&v,&u);
		E[v].pb(u);E[u].pb(v);
    }
    depth[0]=-1;
    DFSsetup(1,0);
    //for(int i=1;i<=n;i++) printf("%i: %i\n",i,depth[i]);
    for(int i=1,x;i<=m;i++) scanf("%i",&C[i]);
    while(q--){
		int u,v;scanf("%i%i",&u,&v);
		/*int c=LCA(u,v),res=-1;
		if(depth[u]==depth[v]) res=depth[u]-depth[c];
		else res=max(depth[u],depth[v]);
		if(res>m) res=-1;
		printf("%i\n",res);*/
		int res=-1;
		if(u==v) res=0;
		else{
			for(int i=1;i<=m;i++){
				//printf("%i %i\n",u,v);
				if(LCA(C[i],u)==C[i]&&C[i]!=u&&u!=1) u=par[u][0];
				if(LCA(C[i],v)==C[i]&&C[i]!=v&&v!=1) v=par[v][0];
				//printf("%i %i\n\n",u,v);
				if(u==v){res=i;break;}
			}
		}
		printf("%i\n",res);
    }
    return 0;
}
