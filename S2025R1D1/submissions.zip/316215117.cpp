#include <bits/stdc++.h>

using namespace std;
#define pb push_back

const int N = 1e6 + 5, LOG = 20;
vector<int> ord, g[N];
bool vis[N];
void dfs(int s) {
    vis[s] = 1;
    for (auto u : g[s]) {
        if (vis[u]) continue;
        dfs(u);
    }
    ord.pb(s);
}
int lg[N];
struct sp {
    vector<int> mx[LOG];
    int n;
    void init(int _n) {
        n = _n;
        for (int i = 0; i < LOG; ++i)   mx[i].resize(n+1);
    }
    void build() {
        for (int i = 1; i < LOG; ++i) {
            for (int j = 1; j + (1 << i) - 1 <= n; ++j)    mx[i][j] = max(mx[i-1][j], mx[i-1][j + (1 << (i-1))]);
        }
    }
    int get(int l, int r) {
        return max(mx[lg[r-l+1]][l], mx[lg[r-l+1]][r-(1 << lg[r-l+1])+1]);
    }
} R, C;
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    for (int i = 2; i < N; ++i) lg[i] = lg[i/2]+1;
    int n, m, K;
    cin >> n >> m >> K;
    int a[n+1][m+1], I[n*m+1];
    auto H = [&](int x, int y) {
        return (m+1) * x + y;
    };
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            cin >> a[i][j];
            I[a[i][j]] = H(i, j);
        }
    }                                                                                                                                                                                                                                                                                                     
    int l = 0, r = n*m;
    pair<int, vector<int>> ans = {-1, {}};
    R.init(n), C.init(m);
    while (l <= r) {
        int d = (l + r)/2;
        for (int i = H(1, 1); i <= H(n, m); ++i)    g[i].clear();
        fill(vis+H(1, 1), vis+H(n, m)+1, 0);
        ord.clear();
        for (int j = 1; j <= m; ++j) {
            queue<array<int, 2>> Q;
            for (int k = 1; k <= n; ++k) R.mx[0][k] = a[k][j];
            R.build();   
            Q.push({1, n});
            while (!Q.empty()) {
                int l = Q.front()[0], r = Q.front()[1]; Q.pop();
                if (l == r) continue;
                int p = I[R.get(l, r)] / (m+1);
                if (l < p) {
                    int p1 = I[R.get(l, p-1)] / (m+1);
                    if (a[p1][j] >= a[p][j] - d)    g[H(p, j)].pb(H(p1, j));
                    Q.push({l, p-1});
                }
                if (p < r) {
                    int p1 = I[R.get(p+1, r)] / (m+1);
                    if (a[p1][j] >= a[p][j] - d)    g[H(p, j)].pb(H(p1, j));
                    Q.push({p+1, r});
                }
            }
        }
        for (int i = 1; i <= n; ++i) {
            queue<array<int, 2>> Q;
            for (int k = 1; k <= m; ++k) C.mx[0][k] = a[i][k];
            C.build();
            Q.push({1, m});
            while (!Q.empty()) {
                int l = Q.front()[0], r = Q.front()[1]; Q.pop();
                if (l == r) continue;
                int p = I[C.get(l, r)] % (m+1);
                if (l < p) {
                    int p1 = I[C.get(l, p-1)] % (m+1);
                    if (a[i][p1] >= a[i][p] - d)    g[H(i, p)].pb(H(i, p1));
                    Q.push({l, p-1});
                }
                if (p < r) {
                    int p1 = I[C.get(p+1, r)] % (m+1);
                    if (a[i][p1] >= a[i][p] - d)    g[H(i, p)].pb(H(i, p1));
                    Q.push({p+1, r});
                }
            }
        }
        for (int i = H(1, 1); i <= H(n, m); ++i) {
            if (i % (m + 1) == 0)   continue;
            if (!vis[i])    dfs(i);
        }
        reverse(ord.begin(), ord.end());
        fill(vis+H(1, 1), vis+H(n, m)+1, 0);
        vector<int> v;
        for (int i = 0; i < ord.size(); ++i) {
            for (auto u : g[ord[i]])    vis[u] = 1;
            if (vis[ord[i]])    continue;
            v.pb(ord[i]);
        }
        if (v.size() <= K)
            r = d-1, ans = {d, v};
        else
            l = d+1;
    }
    if (ans.first == -1) {
        cout << -1 << '\n';
        return 0;
    }
    cout << ans.first << '\n';
    for (auto x : ans.second) {
        cout << x / (m+1) << ' ' << x % (m+1) << '\n';
    }
    for (int i = 1; i <= K - ans.second.size(); ++i)    cout << "1 1\n";
}