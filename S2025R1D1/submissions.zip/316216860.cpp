#include<bits/stdc++.h>
using namespace std;
using ll=long long;

const ll N=1e5+2;
vector<ll>g[N];
ll dep[N],comp[N],decomp[N],par[N],tin[N],tout[N],sz[N],n,m,q,ti;

void dfs1(ll u,ll p){
	comp[u]=++ti;
	decomp[ti]=u;
	for(int v:g[u]){
		if(!(v^p))continue;
		dfs1(v,u);
	}
}

void dfs2(ll u,ll p){
	tin[u]=++ti;
	sz[u]=1;
	for(int v:g[u]){
		if(!(v^p))continue;
		par[v]=u;
		dep[v]=dep[u]+1;
		dfs2(v,u);
		sz[u]+=sz[v];
	}
	tout[u]=++ti;
}

ll iznad(ll u,ll v){
	return(tin[u]<=tin[v]&&tout[u]>=tout[v]);
}

ll _lca(ll u,ll v){
	if(iznad(u,v))return u;
	if(iznad(v,u))return v;
	while(!iznad(u,v))u=par[u];
	return u;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin>>n>>m>>q;

    vector<array<ll,2>>e;
    for(int i=1,u,v;i<n;++i){
    	cin>>u>>v;
    	e.push_back({u,v});
    	g[u].push_back(v);
    	g[v].push_back(u);
    }

    dfs1(1,0);
    ti=0;

    for(int i=1;i<=n;++i)
    	g[i].clear();

    for(auto[u,v]:e){
    	g[comp[u]].push_back(comp[v]);
    	g[comp[v]].push_back(comp[u]);
    }

    dfs2(1,0);

    for(int i=1,_;i<=m;++i)cin>>_;

    while(q--){
    	ll u,v;cin>>u>>v;
    	u=comp[u],v=comp[v];
    	if(dep[v]==dep[u])cout<<dep[v]-dep[_lca(u,v)]<<'\n';
    	else cout<<max(dep[u],dep[v])<<'\n';
    }
}