#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 490000 + 10;

const int inf = 1e16;

int n, m, in[N], niz[N], k, vatafak[N];
vector<vector<int>> a, dp;
vector<int> g[N];

int kod(int i, int j) {
  return ((i - 1) * m + j);
}

int check(int d) {
  dp.resize(n + 1);
  for(int i = 1; i <= n; i++) dp[i].resize(m + 1);
  for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) dp[i][j] = inf;
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
     // int pos1 =
    }
  }
}

int Dfs(int x) {
  int cost = 0, cnt = 0;
  queue<int> q;
  q.push(x);
  for(int i = 1; i <= n * m; i++) vatafak[i] = inf;
  vatafak[x] = 0;
  while(!q.empty()) {
    int u = q.front();
    q.pop();
    cnt++;
    for(int j : g[u]) {
      in[j]--;
      if(!in[j]) {
        vatafak[j] = min(vatafak[j], niz[u] - niz[j]);
        q.push(j);
      }
    }
  }
  for(int i = 1; i <= n * m; i++) cost = max(cost, vatafak[i]);
  return cost;
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> n >> m >> k;
  a.resize(n + 1);
  for(int i = 1; i <= n; i++) a[i].resize(m + 1);
  int x, y;
  for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) cin >> a[i][j];
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      niz[kod(i, j)] = a[i][j];
      if(a[i][j] == m * n) {
        x = i;
        y = j;
      }
      /*if(i + 1 <= n && a[i][j] > a[i + 1][j]) {
        g[kod(i, j)].push_back(kod(i + 1, j)), in[kod(i + 1, j)]++;
      }
      if(i - 1 >= 1 && a[i][j] > a[i - 1][j]) {
        g[kod(i, j)].push_back(kod(i - 1, j)), in[kod(i - 1, j)]++;
      }
      if(j + 1 <= m && a[i][j] > a[i][j + 1]) {
        g[kod(i, j)].push_back(kod(i, j + 1)), in[kod(i, j + 1)]++;
      }
      if(j - 1 >= 1 && a[i][j] > a[i][j - 1]) {
        g[kod(i, j)].push_back(kod(i, j - 1)), in[kod(i, j - 1)]++;
      }*/
      for(int k = j + 1; k <= m; k++) {
        if(a[i][k] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(i, k));
        in[kod(i, k)]++;
      }
      for(int k = j - 1; k >= 1; k--) {
        if(a[i][k] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(i, k));
        in[kod(i, k)]++;
      }
      for(int k = i + 1; k <= n; k++) {
        if(a[k][j] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(k, j));
        in[kod(k, j)]++;
      }
      for(int k = i - 1; k >= 1; k--) {
        if(a[k][j] > a[i][j]) break;
        g[kod(i, j)].push_back(kod(k, j));
        in[kod(k, j)]++;
      }
    }
  }
  int xx = Dfs(kod(x, y));
  int ans = (xx == inf ? -1 : xx);
  cout << ans << "\n";
  if(ans != -1) cout << x << " " << y << "\n";
}
