#include<bits/stdc++.h>
using namespace std;
using ll=int;

const ll N=1e5+2;
vector<ll>g[N];
ll dep[N],comp[N],decomp[N],par[N],tin[N],tout[N],sz[N],n,m,q,ti;

void dfs1(ll u,ll p){
	comp[u]=++ti;
	decomp[ti]=u;
	for(int v:g[u]){
		if(!(v^p))continue;
		dfs1(v,u);
	}
}

void dfs2(ll u,ll p){
	tin[u]=++ti;
	sz[u]=1;
	for(int v:g[u]){
		if(!(v^p))continue;
		par[v]=u;
		dep[v]=dep[u]+1;
		dfs2(v,u);
		sz[u]+=sz[v];
	}
	tout[u]=++ti;
}

const ll N2=(23)*N+5;
ll lc[N2],rc[N2],root[N2],nd;
struct{ll s=0,lz=0;}st[N2];

void bd(ll lik,ll l=1,ll r=n){
	if(l==r)return;
	lc[lik]=++nd;
	rc[lik]=++nd;
	ll md=(l+r)/2;
	bd(lc[lik],l,md);
	bd(rc[lik],md+1,r);
}

void push(ll i,ll l,ll r){
	if(!st[i].lz)return;
	st[i].s+=st[i].lz;
	if(l!=r){
		st[lc[i]].lz+=st[i].lz;
		st[rc[i]].lz+=st[i].lz;
	}
	st[i].lz=0;
}

void upd(ll pr,ll tr,ll l,ll r,ll tl=1,ll R=n){
	if(tl>=l&&R<=r){
		lc[tr]=lc[pr];
		rc[tr]=rc[pr];
		push(pr,tl,R);
		st[tr].s=st[pr].s;
		st[tr].lz=st[pr].lz+1;
		push(tr,tl,R);
		return;
	}
	ll md=(tl+R)/2;
	if(md>=l){
		rc[tr]=rc[pr];
		lc[tr]=++nd;
		push(tr,tl,R);
		upd(lc[pr],lc[tr],l,r,tl,md);
	}
	if(md+1<=r){
		lc[tr]=lc[pr];
		rc[tr]=++nd;
		push(tr,tl,R);
		upd(rc[pr],rc[tr],l,r,md+1,R);
	}
	st[tr].s=st[lc[tr]].s+st[rc[tr]].s;
}

ll get(ll tr,ll id,ll l=1,ll r=n){
	if(l==r)return st[tr].s;
	ll md=(l+r)/2;
	push(tr,l,r);
	if(id<=md)return get(lc[tr],id,l,md);
	else return get(rc[tr],id,md+1,r);
}

ll iznad(ll u,ll v){
	return(tin[u]<=tin[v]&&tout[u]>=tout[v]);
}

ll _lca(ll u,ll v){
	if(iznad(u,v))return u;
	if(iznad(v,u))return v;
	while(!iznad(u,v))u=par[u];
	return u;
}

set<ll>jebeno[N];

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin>>n>>m>>q;

    vector<array<ll,2>>e;
    for(int i=1,u,v;i<n;++i){
    	cin>>u>>v;
    	e.push_back({u,v});
    	g[u].push_back(v);
    	g[v].push_back(u);
    }

    dfs1(1,0);
    ti=0;

    for(int i=1;i<=n;++i)
    	g[i].clear();

    for(auto[u,v]:e){
    	g[comp[u]].push_back(comp[v]);
    	g[comp[v]].push_back(comp[u]);
    }

    dfs2(1,0);

    root[0]=++nd;
    bd(root[0]);


	for(int i=1;i<=n;++i){
		for(int j:g[i]){
			if(j!=par[i])jebeno[i].insert(j);
		}
	}

	for(int i=1;i<=m;++i){
		ll lik;cin>>lik;
		lik=comp[lik];
		root[i]=++nd;
		if(jebeno[lik].empty())continue;
		ll cnt=0;
		for(auto u:jebeno[lik]){
			if(!cnt++)upd(root[i-1],root[i],u,u+sz[u]-1);
			else{
				ll old=root[i];
				root[i]=++nd;
				upd(old,root[i],u,u+sz[u]-1);
			}
		}
		vector<ll>in,out;
		for(auto u:jebeno[lik]){
			out.push_back(u);
			for(int j:g[u])
				if(j!=par[u])in.push_back(j);
		}
		for(int o:out)jebeno[lik].erase(o);
		for(int ii:in)jebeno[lik].insert(ii);
	}

	while(q--){
		ll u,v;
		cin>>u>>v;
		u=comp[u];
		v=comp[v];
		ll lca=_lca(u,v);
		if(dep[u]<dep[v])swap(u,v);
		ll raz=(dep[u]-dep[lca])-(dep[v]-dep[lca]);
		ll l=1,r=m,ans=-1;
		while(l<=r){
			ll md=(l+r)/2;
			ll getU=get(root[md],u);
			ll getV=get(root[md],v);
			if(getU-getV==raz&&getU>=dep[u]-dep[lca]){
				ans=md;
				r=md-1;
			}else
				l=md+1;
		}
		cout<<ans<<'\n';
	}
}