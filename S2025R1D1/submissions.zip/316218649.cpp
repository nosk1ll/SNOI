#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define ll long long
#define int ll
#define ldb long double
typedef pair<ll, ll> pl;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend() 

void solve() {
	int k; cin >> k;
	if (k<=150) {
		cout << k << nl;
		for (int i=2; i<=k; i++) 
			cout << 1 << ' ' << i << nl;
		for (int i=2; i<=k; i++) 
			cout << i << ' ' << k << nl;
		for (int i=2; i<=k; i++) 
			for (int j=1; j<k; j++)
				cout << i << ' ' << j << nl;
	}
}

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

	int T; cin >> T;
	while (T--) 
		solve();
	return 0;
}