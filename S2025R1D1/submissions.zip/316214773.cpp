#include <bits/stdc++.h>

void solve() {
  int n, m, k;
  std::cin >> n >> m >> k;
  std::vector<std::vector<int>> a(n + 1, std::vector<int>(m + 1));
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      std::cin >> a[i][j];
    }
  }
  int N = n * n + m + 5;
  std::vector<std::pair<int,int>> rt(N);
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      rt[i * n + j] = {i, j};
    }
  }
  std::vector<int> adj[N];
  std::vector<int> was(N);
  std::function<void(int)> dfs = [&] (int v) {
    was[v] = 1;
    for(auto u : adj[v]) {
      if(!was[u]) {
        dfs(u);
      }
    }
  };
  std::vector<int> ans(3);
  ans[0] = - 1;
  std::function<int(int, int, int)> valid = [] (int x, int y, int d) {
    if(y >= x - d && y <= x + d) {
      return 1;
    }
    return 0;
  };
  std::function<int(int)> check = [&] (int mid) {
    for(int i = 1; i <= n; i++) {
      for(int j = 1; j <= m; j++) {
        int curr = 0;
        for(int k = j + 1; k <= m; k++) {
          if(a[i][j] > a[i][k] && a[i][k] > curr && valid(a[i][j], a[i][k], mid)) {
            adj[i * n + j].push_back(i * n + k);
          }
          curr = std::max(curr, a[i][k]);
        }
        curr = 0;
        for(int k = j - 1; k >= 1; k--) {
          if(a[i][j] > a[i][k] && a[i][k] > curr && valid(a[i][j], a[i][k], mid)) {
            adj[i * n + j].push_back(i * n + k);
          }
          curr = std::max(curr, a[i][k]);
        }
        curr = 0;
        for(int k = i - 1; k >= 1; k--) {
          if(a[i][j] > a[k][j] && a[k][j] > curr && valid(a[i][j], a[k][j], mid)) {
            adj[i * n + j].push_back(k * n + j);
          }
          curr = std::max(curr, a[k][j]);
        }
        curr = 0;
        for(int k = i + 1; k <= n; k++) {
          if(a[i][j] > a[k][j] && a[k][j] > curr && valid(a[i][j], a[k][j], mid)) {
            adj[i * n + j].push_back(k * n + j);
          }
          curr = std::max(curr, a[k][j]);
        }
      }
    }
    int found = 0;
    for(int i = 1; i < N; i++) {
      dfs(i);
      int brk = 0;
      if(accumulate(was.begin() + 1, was.end(), 0) == n * m) {
        found = 1;
        brk = 1;
        ans[1] = rt[i].first;
        ans[2] = rt[i].second;
      }
      for(int j = 1; j < N; j++) {
        was[j] = 0;
      }
      if(brk) {
        break;
      }
    }
    if(found) {
      ans[0] = mid;
      return 1;
    }
    return 0;
  };
  int l = 0, r = n * m + 5;
  while(l <= r) {
    for(int i = 1; i < N; i++) {
      adj[i].clear();
    }
    int mid = (l + r) / 2;
    if(check(mid)) {
      r = mid - 1;
    }
    else {
      l = mid + 1;
    }
  }
  std::cout << ans[0] << "\n";
  if(ans[0] == - 1) {
    return;
  }
  for(int i = 1; i <= k; i++) {
    std::cout << ans[1] << " " << ans[2] << "\n";
  }
}

int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

