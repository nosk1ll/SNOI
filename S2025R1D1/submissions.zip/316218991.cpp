#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#pragma GCC target ("avx2")
#pragma GCC optimization ("O3")
#pragma GCC optimization ("unroll-loops")
#define llinf 1000000000 // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = int;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 500005;
const ll lg = 20;
ll n,m,k;
vector<vector<ll> > a;
vector<vector<ll> > b;
vector<ll> g[maxn];
ll val[maxn];
ll f(ll x,ll y) {
    if(val[x]>val[y]) return x;
    return y;
}
ll in[maxn];
ll tsz = 0;
stack<pll> st;
bool check(ll d) {
    for(ll i = 1;i<=tsz;i++) in[i] = 0;
    while(si(st)) st.pop();
    for(ll i = 1;i<=n;i++) {
        st.push({llinf,0});
        for(ll j = 1;j<=m;j++) {
            ll mx = 0;
            while(si(st)&&a[i][j]>st.top().fi){
                mx = f(st.top().sc,mx);
                st.pop();
            }
            mx = f(mx,st.top().sc);
            if(mx!=0&&val[mx]>=a[i][j]-d) {
                in[mx]++;
            }
            mx = f(mx,b[i][j]);
            st.top().sc = f(st.top().sc,mx);
            st.push({a[i][j],0});
        }
    }
    while(si(st)) st.pop();
    for(ll i = 1;i<=n;i++) {
        st.push({llinf,0});
        for(ll j = m;j>=1;j--) {
            ll mx = 0;
            while(si(st)&&a[i][j]>st.top().fi){
                mx = f(st.top().sc,mx);
                st.pop();
            }
            mx = f(mx,st.top().sc);
            if(mx!=0&&val[mx]>=a[i][j]-d) {
                in[mx]++;
            }
            mx = f(mx,b[i][j]);
            st.top().sc = f(st.top().sc,mx);
            st.push({a[i][j],0});
        }
    }
    while(si(st)) st.pop();
    for(ll j = 1;j<=m;j++) {
        st.push({llinf,0});
        for(ll i = 1;i<=n;i++) {
            ll mx = 0;
            while(si(st)&&a[i][j]>st.top().fi){
                mx = f(st.top().sc,mx);
                st.pop();
            }
            mx = f(mx,st.top().sc);
            if(mx!=0&&val[mx]>=a[i][j]-d) {
                in[mx]++;
            }
            mx = f(mx,b[i][j]);
            st.top().sc = f(st.top().sc,mx);
            st.push({a[i][j],0});
        }
    }
    while(si(st)) st.pop();
    for(ll j = 1;j<=m;j++) {
        st.push({llinf,0});
        for(ll i = n;i>=1;i--) {
            ll mx = 0;
            while(si(st)&&a[i][j]>st.top().fi){
                mx = f(st.top().sc,mx);
                st.pop();
            }
            mx = f(mx,st.top().sc);
            if(mx!=0&&val[mx]>=a[i][j]-d) {
                in[mx]++;
            }
            mx = f(mx,b[i][j]);
            st.top().sc = f(st.top().sc,mx);
            st.push({a[i][j],0});
        }
    }
    ll ans = 0;
    for(ll i = 1;i<=tsz;i++) ans+=(in[i]==0);
    return ans<=k;
}
pll rev[maxn];
ll in2[maxn];
int main(){
    ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
    cin >> n >> m >> k;
    a.resize(n+1);
    b.resize(n+1);
    for(ll i = 1;i<=n;i++) {
        a[i].resize(m+1);
        b[i].resize(m+1);
        for(ll j = 1;j<=m;j++) {
            cin >> a[i][j];
            b[i][j] = ++tsz;
            val[tsz] = a[i][j];
            rev[tsz] = {i,j};
        }
    }
    ll tl = 0,tr = n*m,mid,rez = -1;
    while(tl<=tr) {
        mid = (tl+tr)/2;
        if(check(mid)) {
            rez = mid,tr = mid-1;
            for(ll i = 1;i<=tsz;i++) in2[i] = in[i];
        }
        else tl = mid+1;
    }
    cout<<rez<<endl;
    if(rez!=-1) {
        vector<pll> ans;
        for(ll i = 1;i<=tsz;i++) {
            if(in2[i]==0) {
                ans.pb({rev[i].fi,rev[i].sc});
            }
        }
        while(si(ans)<k) ans.pb({1,1});
        for(pll p : ans) cout<<p.fi<< " "<<p.sc<<endl;
    }
    return (0-0);
}