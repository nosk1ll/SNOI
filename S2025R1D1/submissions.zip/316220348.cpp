#include<bits/stdc++.h>
#define ll long long
#define MAXN 150
using namespace std;
ll a[MAXN][MAXN]={};
void solve(int k)
{
    map<pair<int,int>,bool>m;
    cout<<31<<endl;
    a[1][1]=1;
    m[make_pair(1,1)]=true;
    int n=31;
    for(int i=1;i<n-2;i++)
    {
        cout<<i<<" "<<i+1<<endl;
        cout<<i+1<<" "<<i<<endl;
        cout<<i+1<<" "<<i+1<<endl;
        m[make_pair(i,i+1)]=true;
        m[make_pair(i+1,i)]=true;
        m[make_pair(i+1,i+1)]=true;
        a[i][i+1]=a[i-1][i+1]+a[i][i];
        a[i+1][i]=a[i][i]+a[i+1][i-1];
        a[i+1][i+1]=a[i][i+1]+a[i+1][i];
    }
    int x=k/2;
    for(int b=n-3;b>=0;b--)
    {
        if(x&(1<<b))
        {
            for(int i=b+3;i<n;i++)
            {
                cout<<i<<" "<<b+1<<endl;
                m[make_pair(i,b+1)]=true;
                a[i][b+1]=a[i-1][b+1]+a[i][b];
            }
        }
    }
    for(int i=1;i<=n-2;i++)
    {
        cout<<n<<" "<<i<<endl;
        m[make_pair(n,i)]=true;
        a[n][i]=a[n][i-1]+a[n-1][i];
    }
    int y=(k+1)/2;
    for(int b=n-3;b>=0;b--)
    {
        if(y&(1<<b))
        {
            for(int i=b+3;i<n;i++)
            {
                cout<<b+1<<" "<<i<<endl;
                m[make_pair(b+1,i)]=true;
                a[b+1][i]=a[b+1][i-1]+a[b][i];
            }
        }
    }
    for(int i=1;i<=n-2;i++)
    {
        cout<<i<<" "<<n<<endl;
        m[make_pair(i,n)]=true;
        a[i][n]=a[i-1][n]+a[i][n-1];
    }
    if(y&(1<<(n-2)))
    {
        cout<<n-2<<" "<<n-1<<endl;
        cout<<n-1<<" "<<n-2<<endl;
        cout<<n-1<<" "<<n-1<<endl;
        m[make_pair(n-2,n-1)]=true;
        m[make_pair(n-1,n-2)]=true;
        m[make_pair(n-1,n-1)]=true;
        a[n-2][n-1]=a[n-2][n-2]+a[n-3][n-1];
        a[n-1][n-2]=a[n-2][n-2]+a[n-1][n-3];
        a[n-1][n-1]=a[n-2][n-1]+a[n-1][n-2];
    }
    cout<<n<<" "<<n-1<<endl;
    cout<<n-1<<" "<<n<<endl;
    m[make_pair(n,n-1)]=true;
    m[make_pair(n-1,n)]=true;
    a[n][n-1]=a[n-1][n-1]+a[n][n-2];
    a[n-1][n]=a[n-2][n]+a[n-1][n-1];
    cout<<n<<" "<<n<<endl;
    m[make_pair(n,n)]=true;
    a[n][n]=a[n-1][n]+a[n][n-1];
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(m[make_pair(i,j)]==false)
            {
                cout<<i<<" "<<j<<endl;
            }
        }
    }
    /*for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<endl;
    }*/
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int k,t;
    cin>>t;
    while(t--)
    {
        cin>>k;
        solve(k);
    }
    return 0;
}