#include<bits/stdc++.h>
#define ll long long
#define MAXN 100007
using namespace std;
int a[MAXN];
vector<vector<int>>mag(MAXN);
int c[MAXN];
int getnode(int u, int k)
{
    int t=u;
    vector<pair<int,int>>d;
    while(t>0)
    {
        int i=0;
        while(i<min((int)mag[t].size(),(int)(18-log2(t))) && mag[t][i]<=k) 
        {
            d.emplace_back(mag[t][i],t);
            i++;
        }
        t/=2;
    }
    sort(d.begin(),d.end());
    for(auto i:d) if(u>i.second) u=max(i.second,u>>1);
    return u;

}
void solve(int u, int v, int m)
{
    int res=-1;
    int l=0,r=m;
    while(l<=r)
    {
        int mid=(l+r)/2;
        if(getnode(u,mid)==getnode(v,mid))
        {
            res=mid;
            r=mid-1;
        }
        else l=mid+1;
    }
    cout<<res<<endl;
    return;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n,m,q;
    cin>>n>>m>>q;
    int u,v;
    for(int i=0;i<n-1;i++) cin>>u>>v;
    for(int i=0;i<m;i++)
    {
        cin>>u;
        mag[u].push_back(i+1);
    }
    while(q--)
    {
        cin>>u>>v;
        solve(u,v,m);
    }
}