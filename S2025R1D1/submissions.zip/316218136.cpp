#include <bits/stdc++.h>
#define ll long long
#define MAXN 40
using namespace std;
ll a[MAXN][MAXN];
bool v[MAXN][MAXN];
void Update(ll i,ll j)
{
    v[i][j]=true;
    cout << i << " " << j << "\n";
    a[i][j]=a[i-1][j]+a[i][j-1];
}
ll n;
void Show()
{
    for (ll i=1;i<=n;i++)
    {
        for (ll j=1;j<=n;j++)
            cout << a[i][j] << " ";
        cout << "\n";
    }
}
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll t,k;
    cin >> t;
    while (t--)
    {
        cin >> k;
        cout << "32\n";
        n=32;
        for (ll i=1;i<=n;i++)
        {
            for (ll j=1;j<=n;j++)
            {
                v[i][j]=false;
                a[i][j]=0;
            }
        }
        v[1][1]=true;
        a[1][1]=1;
        Update(1,2);
        Update(2,1);
        for (ll i=2;i<31;i++)
        {
            Update(i,i);
            Update(i+1,i);
            Update(i,i+1);
        }
        for (ll i=29;i>=0;i--)
        {
            if (((1ll<<i)&k)!=0)
            {
                for (ll j=i+3;j<n;j++)
                    Update(j,i+1);
            }
        }
        for (ll i=1;i<=n;i++)
            Update(n,i);
        for (ll i=1;i<=n;i++)
        {
            for (ll j=1;j<=n;j++)
            {
                if (!v[i][j])
                    Update(i,j);
            }
        }
    }
    return 0;
}
