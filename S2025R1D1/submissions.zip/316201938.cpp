#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define ll long long
#define int ll
#define ldb long double
typedef pair<ll, ll> pl;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()

int n, m, k;
vector<vi> a;
vpi pos;

//k=1, sporo
bool check(int mid) { 
	int tr=n*m-1;
	while (tr>0) {
		int i=pos[tr].f, j=pos[tr].s;
		int mx=0;
		bool ok=false;
		for (int ni=i-1; ni>=1; ni--) {
			mx=max(mx, a[ni][j]);
			if ((a[i][j]>=a[ni][j]-mid)&&(a[i][j]<a[ni][j])) {
				if (mx>max(a[i][j], a[ni][j]))
					break; 
				else {
					ok=true;
					break;
				}
			}
		}
		mx=0;
		if (ok) {
            tr--;
			continue;
		}
		for (int ni=i+1; ni<=n; ni++) {
			mx=max(mx, a[ni][j]);
			if ((a[i][j]>=a[ni][j]-mid)&&(a[i][j]<a[ni][j])) {
				if (mx>max(a[i][j], a[ni][j]))
					break; 
				else {
					ok=true;
					break;
				}
			}
		}
		if (ok) {
            tr--;
			continue;
		}
		mx=0;
		for (int nj=j-1; nj>=1; nj--) {
			mx=max(mx, a[i][nj]);
			if ((a[i][j]>=a[i][nj]-mid)&&(a[i][j]<a[i][nj])) {
				if (mx>max(a[i][j], a[i][nj]))
					break; 
				else {
					ok=true;
					break;
				}
			}
		}
		if (ok) {
            tr--;
			continue;
		}
		mx=0;
		for (int nj=j+1; nj<=m; nj++) {
			mx=max(mx, a[i][nj]);
			if ((a[i][j]>=a[i][nj]-mid)&&(a[i][j]<a[i][nj])) {
				if (mx>max(a[i][j], a[i][nj]))
					break; 
				else {
					ok=true;
					break;
				}
			}
		}
		if (ok) {
            tr--;
			continue;
		}
		else
			return false;
		tr--;
	}
	return true;
}

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

	cin >> n >> m >> k;
	a.resize(n+1);
	pos.resize(m*n+1);
	for (int i=1; i<=n; i++) {
		a[i].resize(m+1);
		for (int j=1; j<=m; j++) {
			cin >> a[i][j];
			pos[a[i][j]]=mp(i, j);
		}
	}
	int lo=0, hi=n*m+10, res=-1;
	while (lo<=hi) {
		int mid=(lo+hi)/2;
		if (check(mid)) {
			hi=mid-1;
			res=mid; 
		}
		else
			lo=mid+1;
	}
	cout << res << nl;
	if (res!=-1) 
		cout << pos[n*m].f << ' ' << pos[n*m].s << nl; 
	return 0;
}
