#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MAXN = 35;


int k;
vector<int> b;
int dp[MAXN][MAXN];
vector<array<int,2>> q;

void solve(){
    cin >> k;
    b.clear();
    int K = k;
    while(k){
        b.push_back(k&1);
        k >>= 1;
    }
    k = K;
    reverse(b.begin(), b.end());
    if(b.size()==1){
        cout << "1\n";
        return;
    }
    if(k==2){
        cout << "2\n1 2\n2 1\n2 2\n";
        return;
    }
    int n = b.size();
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= n; ++j) dp[i][j] = 0;
    }
    dp[1][1] = 1;
    for(int i = 2; i <= n; ++i){
        q.push_back({1,i});
        q.push_back({i,1});
        dp[1][i] = dp[i][1] = 1;
    }
    if(b[1]==0){
        for(int i = n; i > 3; --i){
            if(b[i-1]){
                for(int j = 2; j <= i-2; ++j){
                    q.push_back({i,j});
                    dp[i][j] = 1;
                }
            }
        }
        if(b[2]==0){
            q.push_back({2,3});
            q.push_back({2,2});
            q.push_back({3,2});
            q.push_back({3,3});
        }
        else{
            q.insert(q.begin()+2,{2,3});
            q.insert(q.begin()+2,{2,2});
            q.push_back({3,2});
            q.push_back({3,3});
        }
        for(int i = 1; i <= 3; ++i){
            for(int j = 1; j <= 3; ++j) dp[i][j] = 1;
        }
        for(int i = 4; i <= n; ++i){
            q.push_back({i-1,i});
            q.push_back({i,i-1});
            q.push_back({i,i});
            dp[i][i] = dp[i-1][i] = dp[i][i-1] = 1;
        }
        for(int i = 1; i <= n; ++i){
            for(int j = 1; j <= n; ++j){
                if(!dp[i][j]) q.push_back({i,j});
            }
        }
    }
    else if(k==3){
        n = 3;
        q.push_back({1,3});
        q.push_back({2,2});
        q.push_back({2,3});
        q.push_back({3,3});
        q.push_back({2,2});
        q.push_back({3,1});
    }
    else if(k < 12){
        n = 4;
        q.push_back({4,1});
        q.push_back({1,4});
        if(k==7) q.push_back({4,2});
        q.push_back({2,2});
        q.push_back({2,3});
        q.push_back({3,2});
        q.push_back({3,3});
        q.push_back({4,3});
        if(k==6) q.push_back({4,2});
        q.push_back({2,4});
        q.push_back({3,4});
        q.push_back({4,4});
    }
    else{
        for(int i = n; i > 4; --i){
            if(b[i-1]){
                for(int j = 2; j <= i-2; ++j){
                    q.push_back({i,j});
                    dp[i][j] = 1;
                }
            }
        }
        if(k==15){
            q.push_back({2,4});
            q.insert(q.begin()+2,{2,3});
            q.insert(q.begin()+2,{2,2});
            q.push_back({3,2});
            q.push_back({3,3});
            q.push_back({4,2});
            q.push_back({4,3});
            q.push_back({3,4});
            q.push_back({4,4});
        }
        else{
            if(k==13) q.push_back({2,4});
            q.push_back({2,3});
            if(k==14) q.push_back({2,4});
            q.push_back({2,2});
            q.push_back({3,2});
            q.push_back({3,3});
            q.push_back({4,2});
            q.push_back({4,3});
            q.push_back({3,4});
            q.push_back({4,4});
            if(k==12) q.push_back({2,4});
        }
        for(int i = 1; i <= 4; ++i){
            for(int j = 1; j <= 4; ++j) dp[i][j] = 1;
        }
        
        for(int i = 5; i <= n; ++i){
            q.push_back({i-1,i});
            q.push_back({i,i-1});
            q.push_back({i,i});
            dp[i][i] = dp[i-1][i] = dp[i][i-1] = 1;
        }
        for(int i = 1; i <= n; ++i){
            for(int j = 1; j <= n; ++j){
                if(!dp[i][j]) q.push_back({i,j});
            }
        }
    }
    cout << n << '\n';
    //for(int k : b) cout << k << ' '; cout << '\n';
    int a[n+1][n+1];
    for(int i = 0; i <= n; ++i) fill(a[i],a[i]+n+1,0);
    a[1][1] = 1;
    for(auto p : q){
        cout << p[0] << ' ' << p[1] << '\n';
        a[p[0]][p[1]] = a[p[0]-1][p[1]] + a[p[0]][p[1]-1];
    }
    /*for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= n; ++j){
            cout << setw(5) << a[i][j];
        }
        cout << '\n';
    }*/
    q.clear();
}

int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int32_t qqq=1;
    cin >> qqq;
    while(qqq--)solve();
    return 0;
}