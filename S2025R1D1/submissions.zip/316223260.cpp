#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
#define int long long
//typedef long long int lint;

vector<vector<bool>> mark;

void ispisipoc(int x){
	cout << x << " " << (x + 1) << endl;
	cout << x << " " << (x + 2) << endl;
	cout << x << " " << (x + 3) << endl;
	cout << (x + 1) << " " << x << endl;
	cout << (x + 2) << " " << x << endl;
	cout << (x + 1) << " " << (x + 1) << endl;
	cout << (x + 1) << " " << (x + 2) << endl;
	cout << (x + 1) << " " << (x + 3) << endl;
	cout << (x + 2) << " " << (x + 1) << endl;
	cout << (x + 2) << " " << (x + 2) << endl;
	cout << (x + 2) << " " << (x + 3) << endl;

	mark[x][x + 1] = true;
	mark[x][x + 2] = true;
	mark[x][x + 3] = true;
	mark[x + 1][x] = true;
	mark[x + 2][x] = true;
	mark[x + 1][x + 1] = true;
	mark[x + 1][x + 2] = true;
	mark[x + 1][x + 3] = true;
	mark[x + 2][x + 1] = true;
	mark[x + 2][x + 2] = true;
	mark[x + 2][x + 3] = true;
}	

void co(int x, int y){
	cout << x << " " << y << endl;
	mark[x][y] = true;
}

void kon1(int x){
	co(x+0, x+4);
	co(x+0, x+5);
	co(x+0, x+6);
	co(x+0, x+7);
	co(x+0, x+8);
}

void kon2(int x){
	co(x, x+4);
	co(x, x+5);
	co(x+1, x+5);
	co(x+0, x+6);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);	
}

void kon3(int x){
	co(x, x+4);
	co(x, x+5);
	co(x, x+6);
	co(x, x+7);
	co(x+1, x+5);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);
}

void kon4(int x){
	co(x+1, x+4);
	co(x+1, x+5);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);
}

void kon5(int x){
	co(x, x+4);
	co(x+1, x+4);
	co(x+1, x+5);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);
}

void kon6(int x){
	co(x, x+4);
	co(x, x+5);
	co(x+1, x+4);
	co(x+1, x+5);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);
}

void kon7(int x){
	co(x, x+4);
	co(x, x+5);
	co(x, x+6);
	co(x+1, x+4);
	co(x+1, x+5);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);	
}

void kon8(int x){
	co(x, x+4);
	co(x, x+5);
	co(x, x+6);
	co(x, x+7);
	co(x+1, x+4);
	co(x+1, x+5);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);
}

void kon9(int x){
	co(x, x+4);
	co(x, x+5);
	co(x, x+6);
	co(x, x+7);
	co(x, x+8);
	co(x+1, x+4);
	co(x+1, x+5);
	co(x+1, x+6);
	co(x+1, x+7);
	co(x+1, x+8);	
}

void kon(int x, int c){
	if(c == 1){
		kon1(x);
	}
	if(c == 2){
		kon2(x);
	}
	if(c == 3){
		kon3(x);
	}
	if(c == 4){
		kon4(x);
	}
	if(c == 5){
		kon5(x);
	}
	if(c == 6){
		kon6(x);
	}
	if(c == 7){
		kon7(x);
	}
	if(c == 8){
		kon8(x);
	}
	if(c == 9){
		kon9(x);
	}
}

void markacija(vector<vector<bool>>& mark, int n){
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			if(!mark[i][j]){
				cout << i << " " << j << endl;
			}
		}
	}
}

void dov(int x){
	co(x+1, x+9);
	co(x+1, x+10);
	co(x+1, x+11);
	co(x+1, x+12);
	co(x+1, x+13);
	co(x+2, x+13);
	co(x+3, x+13);
}

void posl(int x, int c){
	co(x+1, x);
	for(int b = 1; b < c; b++){
		co(x, (x + b));
	}
	for(int b = 1; b <= (8); b++){
		co(x+1, (x+b));
	}
}

void solve(){
	mark.clear();
	mark.resize(40);
	for(int i = 0; i < 40; i++){
		mark[i].resize(40);
	}
	for(int i = 0; i < 40; i++){
		for(int j = 0; j < 40; j++){
			mark[i][j] = false;
		}
	}
	int k;
	cin >> k;
	if(k == 1e9){
		cout << 28 << endl;
		ispisipoc(1);
		co(4, 4);
		ispisipoc(4);
		co(7, 7);
		ispisipoc(7);
		co(10, 10);
		ispisipoc(10);
		co(13, 13);
		ispisipoc(13);
		co(16, 16);
		ispisipoc(16);
		co(19, 19);
		ispisipoc(19);
		co(22, 22);
		ispisipoc(22);
		co(25, 25);
		ispisipoc(25);
		co(28, 28);
		markacija(mark, 28);
		return;
	}
	int sk = k;
	vector<int> c;
	while(sk > 0){
		c.push_back(sk % 10);
		sk /= 10;
	}
	int nn = 10 + (1 + 3*(c.size() - 1));
	cout << nn << endl;
	for(int cif = 0; cif < c.size(); cif++){
		int vr = c[cif];
		int x = 1 + 3 * cif;
		if(cif != (c.size() - 1)){
			ispisipoc(x);
			kon(x, vr);
			dov(x);
			co(x+3, x+3);
		}
		else{
			posl(x, vr);
			co(x+1, x+9);
			for(int y = x + 2; y <= nn; y++){
				co(x+y, x+10);
			}
			markacija(mark, nn);
		}
	}
}   
 


signed main(){
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int t = 1;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}   
