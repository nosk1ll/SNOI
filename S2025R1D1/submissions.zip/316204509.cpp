#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 200005;
const ll lg = 20;
ll n,m,q;
ll par[maxn];
vector<ll> g[maxn];
ll in[maxn],out[maxn],ti = 0;
ll sub[maxn];
void dfs(ll u) {
    in[u] = ++ti;
    sub[u] = 1;
    for(ll s : g[u]) {
        dfs(s);
        sub[u]+=sub[s];
    }
    out[u] = ti;
}

ll E[maxn];
pll Q[maxn];
ll l[maxn],r[maxn],mid[maxn],rez[maxn];
vector<ll> v[maxn];
vector<ll> ask[maxn];
ll dsu[maxn*2],tsz;
ll sz[2*maxn];
ll a[maxn];
ll val[maxn];
ll root(ll x) {
    while(x!=dsu[x]) {
        dsu[x] = dsu[dsu[x]];
        x = dsu[x];
    }
    return x;
}
ll st[lg][maxn];

void upd(ll x,ll y,ll ti) {
    x = root(x),y = root(y);
    if(x==y) return;
    ++tsz;
    dsu[x] = dsu[y] = dsu[tsz] = tsz;
    val[tsz] = ti;
    v[tsz].pb(x);
    v[tsz].pb(y);
    st[0][x] = st[0][y] = tsz;
    sz[tsz] = sz[x]+sz[y];
}
void dfsupd(ll u,ll ti) {
    for(ll s : g[u]) {
        if(a[u]==0) {
            if(a[s]!=0) {
                a[u] = a[s];
            }
        }else {
            if(a[s]!=0) upd(a[s],a[u],ti);
            a[u] = root(a[u]);
        }
        a[s] = 0;
        dfsupd(s,ti);
    }
}
bool vis[maxn];
void dfs2(ll u) {
    vis[u] = 1;
    in[u] = ++ti;
    for(ll s : v[u]) {
        dfs2(s);
    }
    out[u] = ti;
}
bool intree(ll x,ll y){return in[x]<=in[y]&&out[x]>=out[y];}
ll lca(ll x,ll y) {
    if(intree(x,y)) return x;
    if(intree(y,x)) return y;
    for(ll j = lg-1;j>=0;j--) {
        if(!intree(st[j][x],y)) x = st[j][x];
    }
    return st[0][x];
}
ll cnt[maxn];
int main(){
    ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
    cin >> n >> m >> q;
    for(ll i = 1;i<=n-1;i++) {
        ll x,y; cin >> x >> y;
        if(x>y) swap(x,y);
        par[y] = x;
        g[x].pb(y);
    }
    tsz = n;
    for(ll i = 1;i<=n;i++) a[i] = dsu[i] = i,sz[i] = 1;
    for(ll i = 1;i<=m;i++) cin >> E[i];
    for(ll i = 1;i<=q;i++) cin >> Q[i].fi >> Q[i].sc;
    tsz = n;
    dfs(1);
    for(ll i = 1;i<=m;i++) {
        ll x = E[i];
        if(cnt[x]>=lg) continue;
        cnt[x]++;
        dfsupd(x,i);
    }
    for(ll i = 1;i<=n;i++) in[i] = out[i] = 0;
    ti = 0;
    for(ll i = 1;i<=tsz;i++) if(st[0][i]==0) st[0][i] = i;
    for(ll j = 1;j<lg;j++) for(ll i = 1;i<=tsz;i++) st[j][i] = st[j-1][st[j-1][i]];
    for(ll i = tsz;i>=1;i--) if(!vis[i]) dfs2(i);
    for(ll i = 1;i<=q;i++) {
        ll x = Q[i].fi,y = Q[i].sc;
        if(st[lg-1][x]!=st[lg-1][y]) cout<<-1<<endl;
        else {
            ll z = lca(x,y);
            cout<<val[z]<<endl;
        }
    }

    return (0-0);
}