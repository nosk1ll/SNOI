#include <bits/stdc++.h>
#define Debug(x) cout << #x << " = " << x << ";\n"
using namespace std;
int N, M, K;
int IN[1000096];
struct EDGE
{
  int u, v, w;
  const bool operator < (const EDGE &e) {return w < e.w;}
};
vector <EDGE> E;
inline int Hash(const int &i, const int &j) {return (i - 1) * M + j;}
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> K;
  if(K == (N * M))
  {
    cout << "0\n";
    for(int i = 1; i <= N; i++)
    {
      for(int j = 1; j <= M; j++) cout << i << ' ' << j << '\n';
    }
    return 0;
  }
  int A[N + 1][M + 1];
  for(int i = 1; i <= N; i++)
  {
    for(int j = 1; j <= M; j++) cin >> A[i][j];
  }
  for(int i = 1; i <= N; i++)
  {
    for(int j = 1; j <= M; j++)
    {
      for(int k = i - 1; (k >= 1) && (A[k][j] < A[i][j]); k--) E.push_back({Hash(i, j), Hash(k, j), A[i][j] - A[k][j]});
      for(int k = i + 1; (k <= N) && (A[k][j] < A[i][j]); k++) E.push_back({Hash(i, j), Hash(k, j), A[i][j] - A[k][j]});
      for(int k = j - 1; (k >= 1) && (A[i][k] < A[i][j]); k--) E.push_back({Hash(i, j), Hash(i, k), A[i][j] - A[i][k]});
      for(int k = j + 1; (k <= M) && (A[i][k] < A[i][j]); k++) E.push_back({Hash(i, j), Hash(i, k), A[i][j] - A[i][k]});
    }
  }
  sort(E.begin(), E.end());
  E.push_back({0, 0, INT_MAX});
  int temp = N * M;
  for(int i = 0; i < (E.size() - 1); i++)
  {
    while(E[i].w == E[i + 1].w)
    {
      temp -= !IN[E[i].v];
      IN[E[i].v]++;
      i++;
    }
    temp -= !IN[E[i].v];
    IN[E[i].v]++;
    if(temp <= K)
    {
      cout << E[i].w << '\n';
      for(int i = 1; i <= N; i++)
      {
        for(int j = 1; j <= M; j++) if(!IN[Hash(i, j)]) cout << i << ' ' << j << '\n';
      }
      while(temp < K) {cout << "1 1\n"; temp++;}
      return 0;
    }
  }
  cout << "-1\n";

  return 0;
}
