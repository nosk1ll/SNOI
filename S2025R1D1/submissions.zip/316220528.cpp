#include <bits/stdc++.h>

using namespace std;
#define pb push_back

void solve() {
    int k;
    cin >> k;
    vector<int> a = {k};
    if (k == 1) {
        cout << 1 << '\n';
        return;
    }
    while (a.back() != 1)   a.pb(a.back()/2);
    int C = 1, n = a.size()+1;
    int tm[n+1][n+1];
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j)    tm[i][j] = 0;
    }
    for (int i = 2; i <= n; ++i)    tm[1][i] = ++C;
    reverse(a.begin(), a.end());
    for (int i = n-2; i >= 0; --i) {
        if (a[i] & 1) {
            for (int j = 2; j <= i; ++j)    tm[j][i+2] = ++C;
        }
    }
    tm[2][2] = ++C;
    tm[2][3] = ++C;
    if (a[1] == 3)  tm[3][2] = ++C;
    tm[3][3] = ++C;
    for (int i = 3; i < n; ++i) {
        tm[i][i+1] = ++C;
        tm[i+1][i] = ++C;
        tm[i+1][i+1] = ++C;
    }
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (!tm[i][j])  tm[i][j] = ++C;
        }
    }
    vector<array<int, 3>> ans;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1 + (i == 1); j <= n; ++j)    ans.pb({tm[i][j], i, j});
    }
    sort(ans.begin(), ans.end());
    cout << n << '\n';
    for (auto [t, x, y] : ans) cout << x << ' ' << y << '\n';
    
}
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int T;
    cin >> T;
    while (T--) {
        solve();
    }
}