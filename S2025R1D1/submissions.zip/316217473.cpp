#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#pragma GCC target ("avx2")
#pragma GCC optimization ("O3")
#pragma GCC optimization ("unroll-loops")
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = int;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 500005;
const ll lg = 20;
ll n,m,k;
vector<vector<ll> > a;
vector<vector<ll> > b;
vector<ll> g[maxn];
ll val[maxn];
ll in[maxn];
ll tsz = 0;
ll lg2[maxn];
vector< vector<vector<ll> > > st[2];
ll f(ll x,ll y) {
    if(val[x]>val[y]) return x;
    return y;
}
ll get(bool e,ll i,ll l,ll r) {
    ll x = lg2[r-l+1];
    if(l>r) return 0;
    return f(st[e][x][i][l],st[e][x][i][r-(1<<x)+1]);
}
bool check(ll d) {
    for(ll i = 1;i<=tsz;i++) in[i] = 0;
    for(ll i = 1;i<=n;i++) {
        stack<pll> st;
        st.push({llinf,0});
        for(ll j = 1;j<=m;j++) {
            while(si(st)&&a[i][j]>st.top().fi) st.pop();
            ll l = st.top().sc+1;
            ll p = get(0,i,l,j-1);
            if(p!=0&&val[p]>=a[i][j]-d) {
                in[p]++;
            }
            st.push({a[i][j],j});
        }
    }
    for(ll i = 1;i<=n;i++) {
        stack<pll> st;
        st.push({llinf,m+1});
        for(ll j = m;j>=1;j--) {
            while(si(st)&&a[i][j]>st.top().fi) st.pop();
            ll r = st.top().sc-1;
            ll p = get(0,i,j+1,r);
            if(p!=0&&val[p]>=a[i][j]-d) {
                in[p]++;
            }
            st.push({a[i][j],j});
        }
    }
    for(ll j = 1;j<=m;j++) {
        stack<pll> st;
        st.push({llinf,0});
        for(ll i = 1;i<=n;i++) {
            while(si(st)&&a[i][j]>st.top().fi) st.pop();
            ll l = st.top().sc+1;
            ll p = get(1,j,l,i-1);
            if(p!=0&&val[p]>=a[i][j]-d) {
                in[p]++;
            }
            st.push({a[i][j],i});
        }
    }
    for(ll j = 1;j<=m;j++) {
        stack<pll> st;
        st.push({llinf,n+1});
        for(ll i = n;i>=1;i--) {
            while(si(st)&&a[i][j]>st.top().fi) st.pop();
            ll r = st.top().sc-1;
            ll p = get(1,j,i+1,r);
            if(p!=0&&val[p]>=a[i][j]-d) {
                in[p]++;
            }
            st.push({a[i][j],i});
        }
    }
    ll ans = 0;
    for(ll i = 1;i<=tsz;i++) ans+=(in[i]==0);
    return ans<=k;
}
pll rev[maxn];
ll in2[maxn];
int main(){
    ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
    cin >> n >> m >> k;
    a.resize(n+1);
    b.resize(n+1);
    for(ll i = 1;i<=n;i++) {
        a[i].resize(m+1);
        b[i].resize(m+1);
        for(ll j = 1;j<=m;j++) {
            cin >> a[i][j];
            b[i][j] = ++tsz;
            val[tsz] = a[i][j];
            rev[tsz] = {i,j};
        }
    }
    for(ll i = 1,j = 0;i<=max(n,m);i*=2,j++) lg2[i] = j;
    for(ll i = 2;i <= max(n,m);i++) if(!lg2[i]) lg2[i] = lg2[i-1];
    st[0].resize(lg2[m]+1);
    for(ll k = 0;k<=lg2[m];k++) {
        st[0][k].resize(n+1);
        for(ll c = 0;c<=n;c++) st[0][k][c].resize(m+1);
    }
    st[1].resize(lg2[n]+1);
    for(ll k = 0;k<=lg2[n];k++) {
        st[1][k].resize(m+1);
        for(ll c = 0;c<=m;c++) st[1][k][c].resize(n+1);
    }
    for(ll i = 1;i<=n;i++) {
        for(ll j = 1;j<=m;j++) st[0][0][i][j] = st[1][0][j][i] = b[i][j];
    }
    for(ll k = 1;k<lg;k++) {
        if(k<=lg2[m]) {
            for(ll i = 1;i<=n;i++) {
                for(ll j = 1;j<=m;j++) {
                    if(j+(1<<k)-1<=m) st[0][k][i][j] = f(st[0][k-1][i][j],st[0][k-1][i][j+(1<<(k-1))]);
                }
            }
        }
        if(k<=lg2[n]) {
            for(ll j = 1;j<=m;j++) {
                for(ll i = 1;i<=n;i++) {
                    if(i+(1<<k)-1<=n) st[1][k][j][i] = f(st[1][k-1][j][i],st[1][k-1][j][i+(1<<(k-1))]);
                }
            }
        }
    }
    ll tl = 0,tr = n*m,mid,rez = -1;
    while(tl<=tr) {
        mid = (tl+tr)/2;
        if(check(mid)) {
            rez = mid,tr = mid-1;
            for(ll i = 1;i<=tsz;i++) in2[i] = in[i];
        }
        else tl = mid+1;
    }
    cout<<rez<<endl;
    if(rez!=-1) {
        vector<pll> ans;
        for(ll i = 1;i<=tsz;i++) {
            if(in2[i]==0) {
                ans.pb({rev[i].fi,rev[i].sc});
            }
        }
        while(si(ans)<k) ans.pb({1,1});
        for(pll p : ans) cout<<p.fi<< " "<<p.sc<<endl;
    }
    return (0-0);
}