#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 500005;
ll n,m,k;
vector<vector<ll> > a;
vector<vector<ll> > b;
vector<ll> g[maxn];
ll in[maxn];
ll tsz = 0;
vector<array<ll,3> > e;
set<ll> sx[maxn];
set<ll> sy[maxn];
bool cmp(array<ll,3> a,array<ll,3> b){return a>b;}
vector<pll> ans;
bool check(ll d) {
    ans.clear();
    for(ll i = 1;i<=n;i++) sx[i].clear();
    for(ll i = 1;i<=m;i++) sy[i].clear();
    for(auto v : e) {
        ll x = v[0],i = v[1],j = v[2];
        auto it = sx[i].lower_bound(x);
        bool ok = 0;
        if(it!=sx[i].end()&&(*it)-x<=d) ok = 1;
        if(it!=sx[i].begin()&&(*prev(it))-x<=d) ok = 1;
        it = sy[j].lower_bound(x);
        if(it!=sy[j].end()&&(*it)-x<=d) ok = 1;
        if(it!=sy[j].begin()&&(*prev(it))-x<=d) ok = 1;
        if(!ok) ans.pb({i,j});
        sx[i].insert(x);
        sy[j].insert(x);
    }
    return si(ans)<=k;
}
pll rev[maxn];
int main(){
    ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
    cin >> n >> m >> k;
    if(n>100|m>100) return 0;
    a.resize(n+1);
    b.resize(n+1);
    for(ll i = 1;i<=n;i++) {
        a[i].resize(m+1);
        b[i].resize(m+1);
        for(ll j = 1;j<=m;j++) {
            cin >> a[i][j];
            b[i][j] = ++tsz;
            rev[tsz] = {i,j};
            e.pb({a[i][j],i,j});
        }
    }
    sort(all(e),cmp);
    ll tl = 0,tr = 1000000000,mid,rez = -1;
    while(tl<=tr) {
        mid = (tl+tr)/2;
        if(check(mid)) rez = mid,tr = mid-1;
        else tl = mid+1;
    }
    cout<<rez<<endl;
    if(rez!=-1) {
        check(rez);
        while(si(ans)<k) ans.pb(ans.back());
        for(pll p : ans) cout<<p.fi<< " "<<p.sc<<endl;
    }
    return (0-0);
}