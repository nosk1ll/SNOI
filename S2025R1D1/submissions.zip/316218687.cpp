#include <bits/stdc++.h>
//#define int long long
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define sc second
#define endl "\n"
#define pii pair<int,int>

using namespace std;

const int MAXN = 1e5+5;
const int mod7 = 1e9+7;
const long long inf = 1e18;

struct str{int x,a,b;};


vector<vector<int>> mat;
vector<vector<bool>> visited;
int n,m,k;

bool cmp(str a, str b)
{
    return a.x < b.x;
}

void dfs(int i, int j, int mid)
{
    visited[i][j] = 1;
    if(i>1 && !visited[i-1][j] && mat[i-1][j] >= mat[i][j] - mid && mat[i][j] > mat[i-1][j])dfs(i-1,j,mid);
    if(j>1 && !visited[i][j-1] && mat[i][j-1] >= mat[i][j] - mid && mat[i][j] > mat[i][j-1])dfs(i,j-1,mid);
    if(i<n && !visited[i+1][j] && mat[i+1][j] >= mat[i][j] - mid && mat[i][j] > mat[i+1][j])dfs(i+1,j,mid);
    if(j<m && !visited[i][j+1] && mat[i][j+1] >= mat[i][j] - mid && mat[i][j] > mat[i][j+1])dfs(i,j+1,mid);
}

signed main()
{
    ios_base::sync_with_stdio(false),cin.tie(0), cout.tie(0);
    int tt=1;
    //cin >> tt;
    while(tt--)
    {

        cin >> n >> m >> k;
        vector<str> niz;
        mat = vector<vector<int>>(n+1, vector<int>(m+1));
        int mx = 0;
        int mxi, mxj;
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m; j++)
            {
                int x;cin >> x;
                mat[i][j] = x;
                if(x > mx)
                {
                    mxi = i;
                    mxj = j;
                    mx = x;
                }
            }
        }


        //for(auto x: niz)cout << x.x << " " << x.a << " " << x.b<< endl;
        int l = 0;
        int r = n*m;
        int resenje = n*m+1;
        while(l<=r)
        {
            int mid = l+ r >> 1;
            visited = vector<vector<bool>>(n+1, vector<bool>(m+1,false));
            dfs(mxi,mxj, mid);
            bool moze = true;
            for(int i=1; i<=n; i++)for(int j=1; j<=m; j++)if(!visited[i][j])moze = false;
            if(moze)
            {
                resenje = mid;
                r = mid - 1;
            }
            else l = mid+1;
        }
        if(resenje == n*m + 1)cout << -1 << endl;
        else
        {
            cout << resenje << endl;
            cout << mxi << " " << mxj << endl;
        }
    }
}
