#include <bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);cerr.tie(0);

int main(){
ubrzaj;

int iN,iM,iQ;
cin>>iN>>iM>>iQ;
for(int i=0;i<iN-1;i++){
int iU,iV;cin>>iU>>iV;}
vector<int> viC(iM+1);
vector<vector<int>> vviEvents(iN+1);
for(int iEvt=1;iEvt<=iM;iEvt++){
cin>>viC[iEvt];
vviEvents[viC[iEvt]].push_back(iEvt);}
vector<pair<int,int>> vpQueries(iQ);
vector<bool> vbNeed(iN+1,false);
for(int iQidx=0;iQidx<iQ;iQidx++){
cin>>vpQueries[iQidx].first>>vpQueries[iQidx].second;
vbNeed[vpQueries[iQidx].first]=vbNeed[vpQueries[iQidx].second]=true;}
vector<int> viXs;
for(int iX=1;iX<=iN;iX++)
if(vbNeed[iX])viXs.push_back(iX);
const int iINF=iM+1;
vector<vector<int>> vviTimes(iN+1);
for(int iX:viXs){
int iDepth=31-__builtin_clz(iX);
vector<int> viAnc;
for(int u=iX>>1;u>=1;u>>=1)viAnc.push_back(u);
int iD=viAnc.size();
vector<int> viIdx(iD,0);
priority_queue<pair<int,int>,vector<pair<int,int>>,greater<>>pq;
for(int iA=0;iA<iD;iA++)if(!vviEvents[viAnc[iA]].empty())pq.push({vviEvents[viAnc[iA]][0],iA});
auto &viTx=vviTimes[iX];
viTx.clear();viTx.push_back(0);
int iLast=0;
//naci cvor
for(int iStep=1;iStep<=iD;iStep++){
int iT=-1,iWho=-1;
while(!pq.empty()){
auto pr=pq.top();pq.pop();
if(pr.first<=iLast){
int iI=pr.second;
if(++viIdx[iI]<(int)vviEvents[viAnc[iI]].size())pq.push({vviEvents[viAnc[iI]][viIdx[iI]],iI});
continue;}
iT=pr.first;iWho=pr.second;break;}
if(iWho<0)break;
viTx.push_back(iT);iLast=iT;
if(++viIdx[iWho]<(int)vviEvents[viAnc[iWho]].size())pq.push({vviEvents[viAnc[iWho]][viIdx[iWho]],iWho});}
}
auto getPosition=[&](int iX,int iT){
auto &viTx=vviTimes[iX];
int iK=int(upper_bound(viTx.begin(),viTx.end(),iT)-viTx.begin())-1;
return iX>>iK;};
for(auto &pr:vpQueries){
int iA=pr.first,iB=pr.second;
if(getPosition(iA,iM)!=getPosition(iB,iM)){cout<<-1<<"\n";continue;}
int iLo=1,iHi=iM,iAns=iM;

//Bin Pretraga
while(iLo<=iHi){
int iMid=(iLo+iHi)>>1;
if(getPosition(iA,iMid)==getPosition(iB,iMid)){iAns=iMid;iHi=iMid-1;}
else iLo=iMid+1;}
cout<<iAns<<"\n";}
return 0;
}
