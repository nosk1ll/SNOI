#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 500005;
ll n,m,k;
vector<vector<ll> > a;
vector<vector<ll> > b;
vector<ll> g[maxn];
ll in[maxn];
ll tsz = 0;
bool check(ll d) {
    for(ll i = 1;i<=tsz;i++) in[i] = 0;
    for(ll i = 1;i<=n;i++) {
        for(ll j = 1;j<=m;j++) {
            bool ok = 1;
            for(ll c = j+1;c<=m;c++) {
                if(a[i][c]>a[i][j]) ok = 0;
                if(ok&&a[i][c]>=a[i][j]-d) {
                    in[b[i][c]]++;
                }
            }
            ok = 1;
            for(ll c = j-1;c>=1;c--) {
                if(a[i][c]>a[i][j]) ok = 0;
                if(ok&&a[i][c]>=a[i][j]-d) {
                    in[b[i][c]]++;
                }
            }
            ok = 1;
            for(ll c = i+1;c<=n;c++) {
                if(a[c][j]>a[i][j]) ok = 0;
                if(ok&&a[c][j]>=a[i][j]-d) {
                    in[b[c][j]]++;
                }
            }
            ok = 1;
            for(ll c = i-1;c>=1;c--) {
                if(a[c][j]>a[i][j]) ok = 0;
                if(ok&&a[c][j]>=a[i][j]-d) {
                    in[b[c][j]]++;
                }
            }
        }
    }
    ll ans = 0;
    for(ll i = 1;i<=tsz;i++) ans+=(in[i]==0);
    return ans<=k;
}
pll rev[maxn];
int main(){
    ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
    cin >> n >> m >> k;
    if(n>100|m>100) return 0;
    a.resize(n+1);
    b.resize(n+1);
    for(ll i = 1;i<=n;i++) {
        a[i].resize(m+1);
        b[i].resize(m+1);
        for(ll j = 1;j<=m;j++) {
            cin >> a[i][j];
            b[i][j] = ++tsz;
            rev[tsz] = {i,j};
        }
    }
    ll tl = 0,tr = 1000000000,mid,rez = -1;
    while(tl<=tr) {
        mid = (tl+tr)/2;
        if(check(mid)) rez = mid,tr = mid-1;
        else tl = mid+1;
    }
    cout<<rez<<endl;
    if(rez!=-1) {
        check(rez);
        vector<pll> ans;
        for(ll i = 1;i<=tsz;i++) {
            if(in[i]==0) {
                ans.pb({rev[i].fi,rev[i].sc});
            }
        }
        while(si(ans)<k) ans.pb(ans.back());
        for(pll p : ans) cout<<p.fi<< " "<<p.sc<<endl;
    }
    return (0-0);
}