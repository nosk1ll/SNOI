#include <bits/stdc++.h>
using namespace std;
const int MAXN = 5e5+5;
const int inf = 2e9;


int n, m, k;
vector<vector<int>> a;
array<int,2> p[MAXN];
set<int> rw[MAXN], cl[MAXN];
vector<array<int,2>> ansv, v;

bool check(int d){
    int ttt = 0;
    v.clear();
    for(int i = n*m; i >= 1; --i){
        int x = p[i][0], y = p[i][1];
        auto it1 = rw[x].lower_bound(y);
        auto it2 = cl[y].lower_bound(x);
        int v1 = (it1==rw[x].end() ? inf : abs(*it1-y));
        int v2 = (it1==rw[x].begin() ? inf : abs(*prev(it1)-y));
        int v3 = (it2==cl[y].end() ? inf : abs(*it2-x));
        int v4 = (it2==cl[y].begin() ? inf : abs(*prev(it2)-x));
        if(min(v1, v2) > d && min(v3, v4) > d){
            ++ttt;
            v.push_back({x,y});
        }
        rw[x].insert(y);
        cl[y].insert(x);
    }
    for(int i = 0; i < n; ++i) rw[i].clear();
    for(int i = 0; i < m; ++i) cl[i].clear();
    return (ttt <= k);
}

void solve(){
    cin >> n >> m >> k;
    a.resize(n,vector<int>(m));
    for(int i = 0; i < n; ++i){
        for(int j = 0; j < m; ++j){
            cin >> a[i][j];
            p[a[i][j]] = {i,j};
        }
    }
    int l = 0, r = 5e5, ans = -1;
    check(1);
    while(l <= r){
        int mid = (l+r)/2;
        //cout << l << ' ' << r << ' ' << mid << endl;
        if(check(mid)){
            ans = mid;
            ansv = v;
            r = mid-1;
        }
        else l = mid+1;
    }
    cout << ans << '\n';
    for(auto p : ansv){
        cout << p[0]+1 << ' ' << p[1]+1 << '\n';
    }
}

int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int32_t qqq=1;
    //cin >> qqq;
    while(qqq--)solve();
    return 0;
}