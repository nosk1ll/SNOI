#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 100 + 10;

const int inf = 1e16;

int n, m, q, in[N], out[N], timer = 0, c[N], par[N];
vector<int> g[N];

void init(int n) {
  for(int i = 1; i <= n; i++) par[i] = i;
}

int get(int x) {
  return (x == par[x] ? x : par[x] = get(par[x]));
}

void unite(int u, int v) {
  u = get(u); v = get(v);
  if(u == v) return;
  par[u] = v;
}

bool same(int u, int v) {
  return (get(u) == get(v));
}

void Dfs(int x, int p) {
  in[x] = ++timer;
  for(int j : g[x]) {
    if(j != p) {
      Dfs(j, x);
    }
  }
  out[x] = timer;
}

bool In(int u, int v) {
  if(u == v) return false;
  return (in[u] <= in[v] && out[u] >= out[v]);
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> n >> m >> q;
  for(int i = 1; i < n; i++) {
    int u, v;
    cin >> u >> v;
    g[u].push_back(v);
    g[v].push_back(u);
  }
  Dfs(1, 0);
  for(int i = 1; i <= m; i++) cin >> c[i];
  vector<array<int, 3>> kveri;
  vector<int> ans(q + 1, inf);
  for(int i = 1; i <= q; i++) {
    int a, b;
    cin >> a >> b;
    kveri.push_back({a, b, i});
  }
  /*if(n <= 1000) {
    vector<int> p(n + 1);
    for(int i = 1; i <= n; i++) p[i] = i;
    init(n);
    for(int i = 1; i <= m; i++) {
      vector<pair<int,int>> vec;
      for(int j = 1; j <= n; j++) {
        if(p[j] != c[i] && In(c[i], p[j])) p[j] /= 2;
        vec.push_back({p[j], j});
      }
      sort(vec.begin(), vec.end());
      for(int i = 1; i < vec.size(); i++) {
        if(vec[i].first == vec[i - 1].first) unite(vec[i - 1].second, vec[i].second);
      }
      for(auto xx : kveri) {
        if(same(xx[0], xx[1])) ans[xx[2]] = min(ans[xx[2]], i);
      }
    }
    for(int i = 1; i <= q; i++) cout << (ans[i] == inf ? -1 : ans[i]) << "\n";
    return 0;
  }*/
  multiset<int> st[N];
  for(int i = 1; i <= m; i++) st[c[i]].insert(i);
  for(auto x : kveri) {
    int a = x[0], b = x[1];
    int res = 0;
    multiset<int> all;
    int l = a, r = b;
    while(l > 1) {
      all.insert(l);
      l /= 2;
    }
    while(r > 1) {
      all.insert(r);
      r /= 2;
    }
    all.insert(1);
    int j = 0;
    while(!all.empty() && a != b) {
      int idx = inf, koji = -1;
      for(auto i : all) {
        if(!In(i, a) && !In(i, b)) continue;
        auto lb = st[i].lower_bound(j);
        if(lb == st[i].end()) continue;
        if(*lb < idx) koji = i;
        idx = min(idx, *lb);
      }
      if(idx == inf) break;
      j = idx + 1;
      if(In(koji, a) && a > 1) a /= 2;
      if(In(koji, b) && b > 1) b /= 2;
    }
    cout << (a == b ? j - 1 : -1) << "\n";
  }
}
