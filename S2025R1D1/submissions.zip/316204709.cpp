#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
typedef long long int lint;

struct str{
	int i;
	int j;
	int vr;
};

bool sortiraj(const str& A, const str& B){
	if(A.vr < B.vr){
		return false;
	}
	else if(A.vr > B.vr){
		return true;
	}
	else{
		if(A.i > B.i){
			return true;
		}
		else if(A.i < B.i){
			return false;
		}
		else{
			return (A.j > B.j);
		}
	}
}

vector<vector<int>> sparsetabla(vector<int>& a){
	int n = a.size();
	int logn = floor(log2(n));
	vector<vector<int>> sparse(n, vector<int>(logn + 1));
	for(int i = 0; i <= logn; i++){
		for(int x = 0; x < (n - (1<<i) + 1); x++){
			if(i == 0){
				sparse[x][i] = a[x];
			}
			else{
				//trenutno je na min() to jest rmq
				sparse[x][i] = max(sparse[x][i - 1], sparse[x + (1<<(i - 1))][i - 1]);
			}
		}
	}
	return sparse;
}

int rmq(vector<vector<int>>& sparse, int l, int r){
	int raz = r - l + 1;
	int logn = floor(log2(raz));
	return max(sparse[l][logn], sparse[r - (1<<logn) + 1][logn]);
}

int pvL(vector<vector<int>>& spt, int n, int i, int aij){
	if(rmq(spt, 0, (i - 1)) <= aij){
		return -1;
	}
	int l = 0;
	int r = i - 1;
	int mid = l + (r - l) / 2;
	int rez = l;
	while(l <= r){
		mid = l + (r - l) / 2;
		if(rmq(spt, mid, (i - 1)) <= aij){
			r = mid - 1;
		}
		else{
			l = mid + 1;
			rez = mid;
		}
	}
	return rez;
}

int pvR(vector<vector<int>>& spt, int n, int i, int aij){
	if(rmq(spt, (i + 1), (n - 1)) <= aij){
		return -1;
	}
	int l = i + 1;
	int r = n - 1;
	int mid = l + (r - l) / 2;
	int rez = r;
	while(l <= r){
		mid = l + (r - l) / 2;
		if(rmq(spt, (i + 1), mid) <= aij){
			l = mid + 1;
		}
		else{
			r = mid - 1;
			rez = mid;
		}
	}
	return rez;	
}

//pvU je simetricno pvD
//pvD je simetricno pvR

void solve(){
	int n, m, k;
	cin >> n >> m >> k;
	int sk = k;
	vector<vector<int>> a(n, vector<int>(m));
	vector<int> maxii(n, numeric_limits<int>::min());
	vector<int> maxij(m, numeric_limits<int>::min());
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			cin >> a[i][j];
			maxii[i] = max(maxii[i], a[i][j]);
			maxij[j] = max(maxij[j], a[i][j]);
		}
	}
	vector<pair<int, int>> rez;
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			if((maxii[i] == a[i][j]) && (maxij[j] == a[i][j])){
				rez.push_back({i, j});
				k--;
			}
		}
	}
	if(k < 0){
		cout << -1 << endl;
		return;
	}
	vector<vector<int>> bi(n);
	vector<vector<int>> bj(m);
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			bi[i].push_back(a[i][j]);
			bj[j].push_back(a[i][j]);
		}
	}
	for(int i = 0; i < n; i++){
		sort(bi[i].begin(), bi[i].end());
	}
	for(int j = 0; j < m; j++){
		sort(bj[j].begin(), bj[j].end());
	}
	
	vector<str> ost;

	vector<vector<vector<int>>> spti(n);
	vector<vector<vector<int>>> sptj(m);

	for(int i = 0; i < n; i++){
		spti[i] = sparsetabla(a[i]);
	}

	vector<vector<int>> b(m, vector<int>(n));
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			b[j][i] = a[i][j];
		}
	}

	for(int j = 0; j < m; j++){
		sptj[j] = sparsetabla(b[j]);
	}



	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			if((maxii[i] != a[i][j]) || (maxij[j] != a[i][j])){
				int mini = numeric_limits<int>::max();
				/*
				if((maxii[i] != a[i][j])){
					mini = min(mini, bi[i][distance(bi[i].begin(), upper_bound(bi[i].begin(), bi[i].end(), a[i][j]))]);
				}
				if((maxij[j] != a[i][j])){
					mini = min(mini, bj[j][distance(bj[j].begin(), upper_bound(bj[j].begin(), bj[j].end(), a[i][j]))]);
				}
				*/
				if(j != 0){
					int x = pvL(spti[i], m, j, a[i][j]);
					if(x != -1){
						mini = min(mini, a[i][x]);
					}
				}
				if(j != (m - 1)){
					int x = pvR(spti[i], m, j, a[i][j]);
					if(x != -1){
						mini = min(mini, a[i][x]);
					}
				}
				if(i != 0){
					int x = pvL(sptj[j], n, i, a[i][j]);
					if(x != -1){
						mini = min(mini, a[x][j]);
					}
				}
				if(i != (n - 1)){					
					int x = pvR(sptj[j], n, i, a[i][j]);
					if(x != -1){
						mini = min(mini, a[x][j]);
					}
				}
				str tr;
				tr.i = i;
				tr.j = j;
				tr.vr = mini - a[i][j];
				ost.push_back(tr);
			}
		}
	}

	sort(ost.begin(), ost.end(), sortiraj);
	if(sk == (n * m)){
		cout << 0 << endl;
		for(int i = 0; i < n; i++){
			for(int j = 0; j < m; j++){
				cout << (i + 1) << " " << (j + 1) << endl;
			}
		}
		return;
	}
	for(int ii = 0; ii < k; ii++){
		rez.push_back({ost[ii].i, ost[ii].j});
	}
	cout << ost[k].vr << endl;
	for(int i = 0; i < rez.size(); i++){
		cout << (rez[i].first + 1) << " " << (rez[i].second + 1) << endl;
	}
}   
 


signed main(){
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}   
