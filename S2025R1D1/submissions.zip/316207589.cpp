#include<bits/stdc++.h>
#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
int n,m,k,d=0;
vector<vector<int>>a,vis;
int ppv1(int i,int l,int r){
	int m1=0,j1=0;
	for(int j=l;j<=r;j++){
		if(m1<a[i][j]){
			m1=a[i][j];
			j1=j;
		}
	}
	if(j1-l>0){
		int re=ppv1(i,l,j1-1);
		vis[i][re]=min(vis[i][re],m1-a[i][re]);
	}if(r-j1>0){
		int re=ppv1(i,j1+1,r);
		vis[i][re]=min(vis[i][re],m1-a[i][re]);
	}
	return j1;
}
int ppv2(int j,int l,int r){
	int m1=0,i1=0;
	for(int i=l;i<=r;i++){
		if(m1<a[i][j]){
			m1=a[i][j];
			i1=i;
		}
	}
	if(i1-l>0){
		int re=ppv2(j,l,i1-1);
		vis[re][j]=min(vis[re][j],m1-a[re][j]);
	}if(r-i1>0){
		int re=ppv2(j,i1+1,r);
		vis[re][j]=min(vis[re][j],m1-a[re][j]);
	}
	return i1;
}
void solve() {
	cin>>n>>m>>k;
	a.resize(n+1,vector<int>(m+1));
	vis.resize(n+1,vector<int>(m+1));
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cin>>a[i][j];
			vis[i][j]=1e9;
		}
	}
	for(int i=0;i<n;i++){
		ppv1(i,0,m-1);
	}for(int j=0;j<m;j++){
		ppv2(j,0,n-1);
	}
	vector<array<int,3>>a2;
	vector<pii>a3;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			if(vis[i][j]==1e9){
				k--;
				a3.emplace_back(i,j);
			}else{
				a2.push_back({vis[i][j],i,j});
			}
			if(k<0){
				break;
			}
		}
	}
	if(k<0){
		cout<<-1<<'\n';
		return;
	}
	sort(a2.begin(),a2.end());
	while(k>0){
		k--;
		a3.emplace_back(a2[a2.size()-1][1],a2[a2.size()-1][2]);
		a2.pop_back();
	}
	if(a2.empty()){
		cout<<0<<'\n';
	}else{
		cout<<a2[a2.size()-1][0]<<'\n';
	}
	for(int i=0;i<a3.size();i++){
		cout<<a3[i].fi+1<<' '<<a3[i].se+1<<'\n';
	}
}
int32_t main() {
	ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int32_t T=1;//cin>>T;
	while(T--) {
		solve();
	}
	return 0;
}