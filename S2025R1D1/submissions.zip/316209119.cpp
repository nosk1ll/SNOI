#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=1e5+50,lg=5,inf=1e9;
int C[N];
vector<int>E[N];
int par[N][lg+1],depth[N],in[N],out[N],tajm;
void DFSsetup(int u,int p){
	in[u]=++tajm;
	depth[u]=depth[p]+1;
	par[u][0]=p;
	for(int j=0;j<lg;j++) par[u][j+1]=par[par[u][j]][j];
	for(auto i:E[u]) if(i!=p) DFSsetup(i,u);
	out[u]=tajm;
}
int LCA(int u,int v){
	if(depth[u]>depth[v])swap(u,v);
	for(int i=lg;i>=0;i--)if(depth[par[v][i]]>=depth[u]) v=par[v][i];if(u==v)return u;
	for(int i=lg;i>=0;i--)if(par[u][i]!=par[v][i])u=par[u][i],v=par[v][i];return par[u][0];
}
vector<int>ind[N];
vector<int>EV(int u){
	int x=u;
	vector<int>preci;
	while(par[x][0]){x=par[x][0];preci.pb(x);}
	reverse(preci.begin(),preci.end());
	//for(auto p:preci) printf("%i ",p);printf("\n");
	int idx[preci.size()+10],I=0;
	for(int i=0;i<preci.size()+5;i++) idx[i]=0;
	vector<int>res;
	while(u!=1){
		int mn=inf;
		for(auto p:preci){
			//while(idx[p]<ind[p].size()&&ind[p][idx[p]]<=I){printf("/ %i %i\n",idx[p],ind[p][idx[p]]);idx[p]++;}
			while(idx[p]<ind[p].size()&&ind[p][idx[p]]<=I)idx[p]++;
			if(idx[p]<ind[p].size())mn=min(mn,ind[p][idx[p]]);
			//printf("%i:: \n",p);
			//for(auto i:ind[p]) printf("%i ",i);printf("\n");
			//printf("%i\n",idx[p]);
		}
		//printf("%i\n",mn);
		if(mn==inf) break;
		u=par[u][0];
		preci.pop_back();
		I=mn;
		res.pb(I);
	}
	//for(auto i:res) printf("%i ",i);printf("\n");
	return res;
}
int main(){
    int n,m,q;scanf("%i%i%i",&n,&m,&q);
    for(int i=1;i<n;i++){
		int u,v;scanf("%i%i",&v,&u);
		E[v].pb(u);E[u].pb(v);
    }
    depth[0]=-1;
    DFSsetup(1,0);
    //for(int i=1;i<=n;i++) printf("%i: %i\n",i,depth[i]);
    for(int i=1;i<=m;i++) scanf("%i",&C[i]),ind[C[i]].pb(i);
    /*for(int i=1;i<=n;i++){
		printf("%i:\n",i);
		EV(i);
    }*/
    while(q--){
		int u,v;scanf("%i%i",&u,&v);
		/*int c=LCA(u,v),res=-1;
		if(depth[u]==depth[v]) res=depth[u]-depth[c];
		else res=max(depth[u],depth[v]);
		if(res>m) res=-1;
		printf("%i\n",res);*/
		/*int res=-1;
		if(u==v) res=0;
		else{
			for(int i=1;i<=m;i++){
				if(in[C[i]]<=in[u]&&in[u]<=out[C[i]]&&C[i]!=u&&u!=1) u=par[u][0];
				if(in[C[i]]<=in[v]&&in[v]<=out[C[i]]&&C[i]!=v&&v!=1) v=par[v][0];
				if(u==v){res=i;break;}
			}
		}
		printf("%i\n",res);*/
		int res=-1;
		vector<pair<int,int>>ev;
		vector<int>Ev=EV(u);
		for(auto i:Ev) ev.pb({i,0});
		Ev=EV(v);
		for(auto i:Ev) ev.pb({i,1});
		sort(ev.begin(),ev.end());
		for(auto [i,x]:ev){
			if(x==0&&u!=1) u=par[u][0];
			else if(x==1&&v!=1) v=par[v][0];
			if(u==v){res=i;break;}
		}
		printf("%i\n",res);
    }
    return 0;
}
