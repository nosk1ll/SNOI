#include <bits/stdc++.h>

using namespace std;


void solve(){
    int k, kc;
    cin >> k;
    if (k == 1){
        cout << 1 << endl;
        return;
    }
    kc = k;
    vector<int> res;
    while (kc > 3){
        res.push_back(kc);
        if (kc & 1) kc--;
        else kc /= 2;
    }
    // for (int i = 0; i < res.size(); i++) cout << res[i] << endl;
    int n = res.size() * 2 + 2;
    if (kc == 3) n++;
    cout << n << endl;
    /*
    cout << "leva kolona jedinica" << endl;
    for (int i = 2; i <= n; i++) cout << i << " " << 1 << endl;
    cout << "stavljanje jedinica za neparne" << endl;
    for (int i = 0; i < extra.size(); i++){
        int y = n - i;
        if (extra[i]){
            for (int j = 2; j < y - 1; j++) cout << y << " " << j << endl;
        }
    }
    */
    // cout << "resavanje dvojke i trojke" << endl;
    if (kc == 2){
        cout << 1 << " " << 2 << endl;
        cout << 2 << " " << 1 << endl;
        cout << 2 << " " << 2 << endl;
    }
    else{
        cout << 2 << " " << 1 << endl;
        cout << 3 << " " << 1 << endl;
        cout << 2 << " " << 2 << endl;
        cout << 3 << " " << 2 << endl;
        cout << 3 << " " << 3 << endl;
    }
    // cout << "stavljanje glavnih elemenata" << endl;
    for (int i = res.size() - 1; i >= 0; i--){
        int y = n - (i * 2);
        if (res[i] % 2 != 0){
            // dovedi jedinice
            cout << y - 1 << " " << 1 << endl;
            for (int j = 1; j < y; j++) cout << y << " " << j << endl;
            cout << y - 2 << " " << y - 1 << endl;
            cout << y - 1 << " " << y - 1 << endl;
            cout << y - 1 << " " << y << endl;
            cout << y << " " << y << endl;
        }
        else{
            cout << y - 2 << " " << y - 1 << endl;
            cout << y - 1 << " " << y - 2 << endl;
            cout << y - 1 << " " << y - 1 << endl;
            cout << y - 1 << " " << y << endl;
            cout << y << " " << y << endl;
            // stavljanje nakon postave svega onog gde bi inace isle jedinice
            cout << y - 1 << " " << 1 << endl;
            for (int j = 1; j < y; j++) cout << y << " " << j << endl;
        }
        // popunjavanje medju prostora
        for (int j = 2; j < y - 2; j++) cout << y << " " << j << endl;
    }
    if (kc == 2){
        for (int i = 1; i < n; i++){
            for (int j = i + 2; j <= n; j++) cout << i << " " << j << endl;
        }
    }
    else{
        for (int j = 2; j <= n; j++) cout << 1 << " " << j << endl;
        for (int j = 3; j <= n; j++) cout << 2 << " " << j << endl;
        for (int i = 3; i < n; i++){
            for (int j = i + 2; j <= n; j++) cout << i << " " << j << endl;
        }
    }
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) solve();
    return 0;
}
/*

*/
