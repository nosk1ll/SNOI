#include <bits/stdc++.h>
#define ll long long
using namespace std;
vector<vector<ll> > a;
vector<pair<ll,pair<ll,ll> > > val;
ll n,m,k;
vector<vector<bool> > R,C,V;
void Solve_Up(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;x<i;x++)
    {
        if (a[i-x][j]>a[i][j] || C[i-x][j])
            break;
        while (s.top()<a[i-x][j])
            s.pop();
        if (s.top()-d>a[i-x][j])
            break;
        s.push(a[i-x][j]);
        V[i-x][j]=true;
        C[i-x][j]=true;
    }
}
void Solve_Down(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;i+x<=n;x++)
    {
        if (a[i+x][j]>a[i][j] || C[i+x][j])
            break;
        while (s.top()<a[i+x][j])
            s.pop();
        if (s.top()-d>a[i+x][j])
            break;
        s.push(a[i+x][j]);
        V[i+x][j]=true;
        C[i+x][j]=true;
    }
}
void Solve_Left(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;x<j;x++)
    {
        if (a[i][j-x]>a[i][j] || R[i][j-x])
            break;
        while (s.top()<a[i][j-x])
            s.pop();
        if (s.top()-d>a[i][j-x])
            break;
        s.push(a[i][j-x]);
        V[i][j-x]=true;
        R[i][j-x]=true;
    }
}
void Solve_Right(ll i,ll j,ll d)
{
    stack<ll> s;
    s.push(a[i][j]);
    for (ll x=1;j+x<=m;x++)
    {
        if (a[i][j+x]>a[i][j] || R[i][j+x])
            break;
        while (s.top()<a[i][j+x])
            s.pop();
        if (s.top()-d>a[i][j+x])
            break;
        s.push(a[i][j+x]);
        V[i][j+x]=true;
        R[i][j+x]=true;
    }
}
vector<pair<ll,ll> > w;
bool Check(ll d)
{
    for (ll i=1;i<=n;i++)
    {
        for (ll j=1;j<=m;j++)
        {
            R[i][j]=false;
            C[i][j]=false;
            V[i][j]=false;
        }
    }
    ll cnt=0;
    vector<pair<ll,ll> > cur;
    for (auto v : val)
    {
        ll i=v.second.first,j=v.second.second;
        if (!V[i][j])
        {
            cnt++;
            cur.push_back({i,j});
            V[i][j]=true;
        }
        if (!C[i][j])
        {
            C[i][j]=true;
            Solve_Up(i,j,d);
            Solve_Down(i,j,d);
        }
        if (!R[i][j])
        {
            R[i][j]=true;
            Solve_Left(i,j,d);
            Solve_Right(i,j,d);
        }
    }
    if (cnt<=k)
    {
        w=cur;
        while (w.size()<k)
            w.push_back(cur[0]);
        return true;
    }
    return false;
}
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cin >> n >> m >> k;
    a.resize(n+2);
    R.resize(n+2);
    C.resize(n+2);
    V.resize(n+2);
    for (ll i=1;i<=n;i++)
    {
        a[i].resize(m+2);
        R[i].resize(m+2);
        C[i].resize(m+2);
        V[i].resize(m+2);
        for (ll j=1;j<=m;j++)
        {
            cin >> a[i][j];
            val.push_back({a[i][j],{i,j}});
        }
    }
    sort(val.begin(),val.end(),greater<pair<ll,pair<ll,ll> > > ());
    ll l=0,r=1e9,mid,ans=-1;
    while (l<=r)
    {
        mid=(l+r)/2;
        if (Check(mid))
        {
            ans=mid;
            r=mid-1;
        }
        else
            l=mid+1;
    }
    cout << ans << "\n";
    for (auto i : w)
        cout << i.first << " " << i.second << "\n";
    return 0;
}
