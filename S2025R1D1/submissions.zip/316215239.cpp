#include <bits/stdc++.h>
#define ll long long
#define MAXN 100010
using namespace std;
vector<ll> G[MAXN];
ll c[MAXN];
ll Depth(ll u)
{
    ll ans=0;
    while (u!=1)
    {
        u/=2;
        ans++;
    }
    return ans;
}
ll pos[1010][1010];
bool ischild[1010][1010];
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll n,m,q,u,v;
    cin >> n >> m >> q;
    bool sub3=false;
    for (ll i=1;i<n;i++)
    {
        cin >> u >> v;
        G[u].push_back(v);
        G[v].push_back(u);
    }
    sub3=(n==m);
    for (ll i=1;i<=m;i++)
    {
        cin >> c[i];
        sub3=(sub3 && c[i]==1);
    }
    if (sub3)
    {
        while (q--)
        {
            cin >> u >> v;
            ll du=Depth(u),dv=Depth(v);
            if (du!=dv)
            {
                if (m<max(du,dv))
                    cout << "-1\n";
                else
                    cout << max(du,dv) << "\n";
                continue;
            }
            ll cnt=0;
            while (u!=v)
            {
                u/=2;
                v/=2;
                cnt++;
            }
            cout << (cnt<=m?cnt : -1) << "\n";
        }
        return 0;
    }
    if (n<=1000 && m<=1000)
    {
        for (ll i=1;i<=n;i++)
        {
            pos[0][i]=i;
            ll cur=i;
            ischild[cur][cur]=true;
            while (cur!=1)
            {
                cur/=2;
                ischild[cur][i]=true;
            }
        }
        for (ll i=1;i<=m;i++)
        {
            for (ll j=1;j<=n;j++)
            {
                pos[i][j]=pos[i-1][j];
                if (ischild[c[i]][pos[i][j]] && pos[i][j]!=c[i] && pos[i][j]!=1)
                    pos[i][j]/=2;
            }
        }
        while (q--)
        {
            cin >> u >> v;
            ll l=1,r=m,mid,ans=-1;
            while (l<=r)
            {
                mid=(l+r)/2;
                if (pos[mid][u]==pos[mid][v])
                {
                    ans=mid;
                    r=mid-1;
                }
                else
                    l=mid+1;
            }
            cout << ans << "\n";
        }
    }
    return 0;
}
