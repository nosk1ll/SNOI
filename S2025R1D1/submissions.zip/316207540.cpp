#include <bits/stdc++.h>
#define Debug(x) cout << #x << " = " << x << ";\n"
using namespace std;
int N, M, Q, glob;
int D[100096];
int A[100096];
struct QUERY
{
  int u, v;
}QR[100096];
int O[100096];
vector <int> ST[400096];
pair <int, int> I[2][400096];
vector <int> V[2][400096];
inline void Setup()
{
  for(int i = 1; i <= N; i++) {D[i] = i; ST[i] = {i};}
  return;
}
inline void DFS(int i)
{
  if(ST[i << 1].size())
  {
    for(int x : ST[i << 1]) {D[x] >>= 1; ST[i].push_back(x);}
    ST[i << 1] = vector <int>();
    DFS(i << 1);
  }
  if(ST[(i << 1) + 1].size())
  {
    for(int x : ST[(i << 1) + 1]) {D[x] >>= 1; ST[i].push_back(x);}
    ST[(i << 1) + 1] = vector <int>();
    DFS((i << 1) + 1);
  }
  return;
}
inline void ParallelBS()
{
  for(int i = 1; i <= Q; i++) V[1][0].push_back(i);
  I[1][0] = {1, M};
  while(true)
  {
    for(int i = 0; i <= M; i++) ///do M ili dalje??
    {
      swap(V[0][i], V[1][i]);
      swap(I[0][i], I[1][i]);
      V[1][i] = vector <int>();
    }
    Setup();
    for(int i = 0; i <= M; i++)
    {
      int L = I[0][i].first, R = I[0][i].second, S = (L + R) >> 1; ///I ne moram da cistim?
      I[1][i << 1] = {L, S};
      I[1][(i << 1) + 1] = {S + 1, R};
//      Debug(i);
//      Debug(L);
//      Debug(R);
//      Debug(S);
      for(int j = L; j <= S; j++) DFS(A[j]);
      for(int x : V[0][i])
      {
        ///kako -1???
        if(D[QR[x].u] == D[QR[x].v]) {V[1][i << 1].push_back(x); O[x] = S;}
        else if(L != R) V[1][(i << 1) + 1].push_back(x);
      }
      for(int j = S + 1; j <= R; j++) DFS(A[j]);
    }
    if(I[0][0].first == I[0][0].second) break;
  }
  return;
}
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> Q;
  int u, v;
  for(int i = 1; i < N; i++) cin >> u >> v;
  for(int i = 1; i <= M; i++) cin >> A[i];
  for(int i = 1; i <= Q; i++) cin >> QR[i].u >> QR[i].v;
//  ParallelBS();
  for(int i = 1; i <= Q; i++) cout << O[i] - !(O[i]) << '\n';

  return 0;
}
