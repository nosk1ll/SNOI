#include <bits/stdc++.h>
#define endl '\n'
#define int long long

using namespace std;

const long long longlongmax=9223372036854775807;
const int modul=998244353;
const long long mod = 1e9 + 7;


mt19937 mt(chrono::steady_clock::now().time_since_epoch().count());

int redosled[33][33],matr[33][33];
int cnt;
void radi(int i,int j){
    redosled[i][j]=++cnt;
    matr[i][j]=matr[i-1][j]+matr[i][j-1];
    return;
}
void ispis(){
    for(int i=1; i<=32; i++){
        for(int j=1; j<=32; j++)
            cout << matr[i][j] << " ";
        cout << endl;
    }
}


signed main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    //freopen("seating.in","r",stdin);
    //freopen("seating.out","w",stdout);


    int t;cin >> t;
    while(t--){
        int k;
        cin >> k;
        if(k==1){cout << 1 << endl; continue;}

        for(int i=0; i<32; i++) for(int j=0; j<32; j++) redosled[i][j]=matr[i][j]=0;
        redosled[1][1]=-1;matr[1][1]=1;
        cnt=0;
        for(int i=2; i<=30; i++){
            radi(i-1,i);
            radi(i,i-1);
            radi(i,i);
        }
        for(int i=29; i>0; i--){
            for(int j=i+1; j<=30; j++)
                radi(i,j);
        }
        for(int i=29; i>=0; i--){
            if((k&(1<<i))>0)
                radi(i+1,31);

        }
        for(int i=1; i<=32; i++)
            radi(i,32);
        //ispis();
        pair<int,int> rez[32*32];
        for(int i=1; i<=32; i++){
            for(int j=1; j<=32; j++){
                if(i==1&&j==1)
                    continue;
                if(!redosled[i][j])
                    rez[++cnt]={i,j};
                else
                    rez[redosled[i][j]]={i,j};
            }
        }
        cout << 32 << endl;
        for(int i=1; i<32*32; i++)
            cout << rez[i].first << " " << rez[i].second << endl;

    }




    return 0;
}
/*


*/
