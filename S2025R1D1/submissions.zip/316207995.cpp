#include <bits/stdc++.h>
#define ll int
#define MAXN 500010
using namespace std;
vector<vector<ll> > a;
vector<pair<ll,pair<ll,ll> > > val;
ll n,m,k;
vector<ll> G[MAXN];
ll indeg[MAXN];
vector<pair<ll,ll> > w;
bool Check(ll d)
{
    for (ll i=1;i<=n;i++)
    {
        for (ll j=1;j<=m;j++)
        {
            G[(i-1)*m+j].clear();
            indeg[(i-1)*m+j]=0;
        }
    }
    for (ll i=1;i<=n;i++)
    {
        stack<pair<ll,ll> > s;
        s.push({i,1});
        for (ll j=2;j<=m;j++)
        {
            while (!s.empty() && a[s.top().first][s.top().second]<a[i][j])
                s.pop();
            if (!s.empty() && a[s.top().first][s.top().second]-d<=a[i][j])
            {
                G[(s.top().first-1)*m+s.top().second].push_back((i-1)*m+j);
                indeg[(i-1)*m+j]++;
            }
            s.push({i,j});
        }
        while (!s.empty())
            s.pop();
        s.push({i,m});
        for (ll j=m-1;j>0;j--)
        {
            while (!s.empty() && a[s.top().first][s.top().second]<a[i][j])
                s.pop();
            if (!s.empty() && a[s.top().first][s.top().second]-d<=a[i][j])
            {
                G[(s.top().first-1)*m+s.top().second].push_back((i-1)*m+j);
                indeg[(i-1)*m+j]++;
            }
            s.push({i,j});
        }
    }
    for (ll j=1;j<=m;j++)
    {
        stack<pair<ll,ll> > s;
        s.push({1,j});
        for (ll i=2;i<=n;i++)
        {
            while (!s.empty() && a[s.top().first][s.top().second]<a[i][j])
                s.pop();
            if (!s.empty() && a[s.top().first][s.top().second]-d<=a[i][j])
            {
                G[(s.top().first-1)*m+s.top().second].push_back((i-1)*m+j);
                indeg[(i-1)*m+j]++;
            }
            s.push({i,j});
        }
        while (!s.empty())
            s.pop();
        s.push({n,j});
        for (ll i=n-1;i>0;i--)
        {
            while (!s.empty() && a[s.top().first][s.top().second]<a[i][j])
                s.pop();
            if (!s.empty() && a[s.top().first][s.top().second]-d<=a[i][j])
            {
                G[(s.top().first-1)*m+s.top().second].push_back((i-1)*m+j);
                indeg[(i-1)*m+j]++;
            }
            s.push({i,j});
        }
    }
    vector<pair<ll,ll> > cur;
    for (ll i=1;i<=n;i++)
    {
        for (ll j=1;j<=m;j++)
        {
            if (!indeg[(i-1)*m+j])
                cur.push_back({i,j});
        }
    }
    if (cur.size()>k)
        return false;
    w=cur;
    while (w.size()!=k)
        w.push_back(cur[0]);
    return true;
}
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cin >> n >> m >> k;
    a.resize(n+2);
    for (ll i=1;i<=n;i++)
    {
        a[i].resize(m+2);
        for (ll j=1;j<=m;j++)
        {
            cin >> a[i][j];
            val.push_back({a[i][j],{i,j}});
        }
    }
    sort(val.begin(),val.end(),greater<pair<ll,pair<ll,ll> > > ());
    ll l=0,r=1e9,mid,ans=-1;
    while (l<=r)
    {
        mid=(l+r)/2;
        if (Check(mid))
        {
            ans=mid;
            r=mid-1;
        }
        else
            l=mid+1;
    }
    cout << ans << "\n";
    for (auto i : w)
        cout << i.first << " " << i.second << "\n";
    return 0;
}
