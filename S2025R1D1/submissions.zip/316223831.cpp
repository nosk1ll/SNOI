#include<bits/stdc++.h>
using namespace std;
using ll=int;

const ll N=1e5+2;
vector<ll>g[N];
ll dep[N],par[N],tin[N],tout[N],sz[N],ps[N],ev[N],n,m,q,ti;
array<ll,2>qu[N];

void dfs2(ll u,ll p){
	tin[u]=++ti;
	sz[u]=1;
	for(int v:g[u]){
		if(!(v^p))continue;
		par[v]=u;
		dep[v]=dep[u]+1;
		dfs2(v,u);
		sz[u]+=sz[v];
	}
	tout[u]=++ti;
}

ll iznad(ll u,ll v){
	return(tin[u]<=tin[v]&&tout[u]>=tout[v]);
}

ll _lca(ll u,ll v){
	if(iznad(u,v))return u;
	if(iznad(v,u))return v;
	while(!iznad(u,v))u=par[u];
	return u;
}

ll l[N],r[N];
vector<ll>md[N];

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin>>n>>m>>q;

    for(int i=1,u,v;i<n;++i){
    	cin>>u>>v;
    	g[u].push_back(v);
    	g[v].push_back(u);
    }

    dfs2(1,0);
    for(int i=0;i<m;++i)cin>>ev[i];
    for(int i=0;i<q;++i)cin>>qu[i][0]>>qu[i][1];

    fill(l,l+N,1);
	fill(r,r+N,m+1);

    while(1){
        for(int i=0;i<m+3;++i)md[i].clear();
  		ll bar=0;
        for(int i=0;i<q;++i){
            if(l[i]<r[i]){
                ll mid=(l[i]+r[i])/2;
                md[mid].push_back(i);
                bar=1;
            }
        }
        if(!bar)break;
        iota(ps,ps+n+1,0);
        for(int t=1;t<=m;++t){
            for(int i=1;i<=n;++i)
            	if(ps[i]!=ev[t-1]&&iznad(ev[t-1],ps[i]))
                    ps[i]=par[ps[i]];
            for(ll idx:md[t]){
                ll a=qu[idx][1];
                ll b=qu[idx][0];
                if(ps[a]==ps[b])r[idx]=t;
                else l[idx]=t+1;
            }
        }
    }

    for(int i=0;i<q;++i)cout<<(l[i]<=m?l[i]:-1)<<'\n';
}