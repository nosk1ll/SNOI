#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define PI acos(-1)
#define LSB(i) ((i) & -(i))
#define ll long long
#define pb push_back
#define mp make_pair
#define mt make_tuple
#define fi first
#define sc second
#define th third
#define fo fourth
#define pii pair<int,int>
#define pll pair<ll,ll>
#define ldb double
#define INF 1e15
#define MOD 1000000007
#define endl "\n"

#define all(data)       data.begin(),data.end()
#define TYPEMAX(type)   std::numeric_limits<type>::max()
#define TYPEMIN(type)   std::numeric_limits<type>::min()
ll n,m,k;
int main()
{
    //ios::sync_with_stdio(false); cin.tie(0);
    cin>>n>>m>>k;
    ll a[n+1][m+1];
    vector<pair<ll,pll>> rr[n+1],cc[m+1];
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            cin>>a[i][j];
            rr[i].pb({a[i][j],{i,j}});
            cc[j].pb({a[i][j],{i,j}});
        }
    }
    for(int i=1;i<=n;i++) sort(all(rr[i]));
    for(int j=1;j<=m;j++) sort(all(cc[j]));
    ll tl=0,tr=n*m,rez=INF,d;
    vector<pll> vv;
    while(tl<tr)
    {
        d=(tl+tr)/2;
        //cout<<"bs: "<<tl<<" "<<tr<<" "<<d<<endl;
        priority_queue<pair<ll,pll>> pq;
        vector<pair<ll,pll>> r[n+1],c[m+1];
        for(int i=1;i<=n;i++) r[i]=rr[i];
        for(int j=1;j<=m;j++) c[j]=cc[j];
        bool vis[n+1][m+1];
        vector<pll> vvd;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++) {pq.push({a[i][j],{i,j}}); vis[i][j]=false;}
        }
        ll kk=0;
        while(!pq.empty())
        {
            pair<ll,pll> bxy=pq.top(); pq.pop();
            ll b=bxy.fi,x=bxy.sc.fi,y=bxy.sc.sc;
            //cout<<b<<" "<<x<<" "<<y<<endl;
            if(!vis[x][y])
            {
                kk++; vis[x][y]=true; vvd.pb({x,y});
                r[x].pop_back(); c[y].pop_back();
            }
            while(!r[x].empty() && a[x][y]-r[x].back().fi<=d) {vis[r[x].back().sc.fi][r[x].back().sc.sc]=true; r[x].pop_back();}
            while(!c[y].empty() && a[x][y]-c[y].back().fi<=d) {vis[c[y].back().sc.fi][c[y].back().sc.sc]=true; c[y].pop_back();}
        }
        if(kk<=k)
        {
            tr=d-1;
            if(d<rez) {rez=d; vv=vvd;}
        }
        else tl=d+1;
    }
    if(rez==INF) {cout<<-1<<endl; return 0;}
    cout<<rez<<endl;
    for(auto xy:vv) cout<<xy.fi<<" "<<xy.sc<<endl;
    for(int i=1;i<=k-vv.size();i++) cout<<vv.back().fi<<" "<<vv.back().sc<<endl;
    return 0;
}
