#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define ll long long
#define int ll
#define ldb long double
typedef pair<ll, ll> pl;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend() 
const int N=1e5+10, M=1e3+10;

int n, m, q, par[N], dep[N]; 
vi g[N];
set<int> anc[N]; 

void dfs(int x, int p) {
	par[x]=p;
	if (p!=-1) 
		dep[x]=dep[p]+1; 
	if (x!=1) {
		for (auto z:anc[p]) 
			anc[x].ins(z);  
		anc[x].ins(p);   
	}
	for (int u:g[x]) 
		if (u!=p)
			dfs(u, x);  
} 

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

	cin >> n >> m >> q;
	for (int i=1; i<n; i++) {
		int u, v; cin >> u >> v;
		g[u].pb(v);
		g[v].pb(u);
	}	
	vi c(m+1); 
	vector<set<int>> pos(n+1); 
	for (int i=1; i<=m; i++) {
		cin >> c[i];   
		pos[c[i]].ins(i);  
	}
	dfs(1, -1);    
	while (q--) {
		int a, b; cin >> a >> b;
		int ida=(int)(1e9), idb=(int)(1e9);
		int res=-1, gde=-1;   
		while (true) { 
			ida=(int)(1e9), idb=(int)(1e9);
			for (auto x:anc[a]) {
				auto ptr=pos[x].upper_bound(gde);
				if (ptr==pos[x].end()) 
					continue; 
				ida=min(ida, *ptr);
			}
			for (auto x:anc[b]) { 
				auto ptr=pos[x].upper_bound(gde);
				if (ptr==pos[x].end()) 
					continue;
				idb=min(idb, *ptr);
			}
			if (ida==idb&&ida==(int)(1e9)) 	
				break; 
			if (ida<idb) {
				a=par[a];
				gde=ida;
				if (a==b) {
					res=ida; 
					break;
				}
			}
			else if (idb<ida) {
				b=par[b];
				gde=idb;
				if (a==b) {
					res=idb; 
					break; 
				}
			}
			else { 
				a=par[a], b=par[b];
				gde=ida; 
				if (a==b) {
					res=ida;
					break; 
				}
			}
		}
		cout << res << nl;
	}
	return 0;
}