#include<bits/stdc++.h>
using namespace std;
using ll=long long;

const ll N=5e5;
ll a[N],L[N],R[N],U[N],D[N],n,m,k;

ll chk(ll x){
    ll ret=0;
    for(int i=0;i<n*m&&ret<=k;++i){
        ll cur=U[i],ok=0;
        if(cur!=-1&&a[i]+x>=a[cur])ok=1;
        cur=R[i];
        if(cur!=-1&&a[i]+x>=a[cur])ok=1;
        cur=D[i];
        if(cur!=-1&&a[i]+x>=a[cur])ok=1;
        cur=L[i];
        if(cur!=-1&&a[i]+x>=a[cur])ok=1;
        ret+=!ok;
    }
    return ret;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin>>n>>m>>k;
    for(int i=0;i<n*m;++i)cin>>a[i];

    for(int i=0;i<n;++i){
        stack<ll>st;
        for(int j=0;j<m;++j){
            ll f=(i*m+j);
            while(st.size()&&a[st.top()]<=a[f])st.pop();
            if(st.size())L[f]=st.top();
            else L[f]=-1;
            st.push(f);
        }
    }
    for(int i=0;i<n;++i){
        stack<ll>st;
        for(int j=m-1;j>=0;--j){
            ll f=(i*m+j);
            while(st.size()&&a[st.top()]<=a[f])st.pop();
            if(st.size())R[f]=st.top();
            else R[f]=-1;
            st.push(f);
        }
    }
    for(int j=0;j<m;++j){
        stack<ll>st;
        for(int i=0;i<n;++i){
            ll f=(i*m+j);
            while(!st.empty()&&a[st.top()]<=a[f])st.pop();
            if(st.size())U[f]=st.top();
            else U[f]=-1;
            st.push(f);
        }
    }
    for(int j=0;j<m;++j){
        stack<ll>st;
        for(int i=n-1;i>=0;--i){
            ll f=(i*m+j);
            while(!st.empty()&&a[st.top()]<=a[f])st.pop();
            if(st.size())D[f]=st.top();
            else D[f]=-1;
            st.push(f);
        }
    }

    if(chk(n*m)>k){
        cout<<-1;
        return 0;
    }

    ll l=0,r=n*m,ans=-1;
    while(l<=r){
        ll md=(l+r)/2;
        if(chk(md)<=k){
            r=md-1;
            ans=md;
        }else
            l=md+1;
    }

    cout<<ans<<'\n';

    vector<array<ll,2>>o;
    for(int i=0;i<n*m;++i){
        ll cur=U[i],ok=0;
        if(cur!=-1&&a[i]+ans>=a[cur])ok=1;
        cur=R[i];
        if(cur!=-1&&a[i]+ans>=a[cur])ok=1;
        cur=D[i];
        if(cur!=-1&&a[i]+ans>=a[cur])ok=1;
        cur=L[i];
        if(cur!=-1&&a[i]+ans>=a[cur])ok=1;
        if(!ok)
            o.push_back({i/m+1,i%m+1});
    }

    if(!o.size())o.push_back({1,1});
    while(o.size()<k)o.push_back(o.front());

    for(auto[u,v]:o)cout<<u<<' '<<v<<'\n';
}