#include <bits/stdc++.h>

using namespace std;


void solve(){
    int k, kc;
    cin >> k;
    if (k == 1){
        cout << 1 << endl;
        return;
    }
    cout << k << endl;
    for (int i = 1; i <= k; i++) cout << i << " " << 1 << endl;
    for (int i = 1; i <= k; i++) cout << i << " " << 2 << endl;
    for (int j = 3; j <= k; j ++) cout << k << " " << j << endl;
    for (int i = 1; i < k; i++){
        for (int j = 3; j <= k; j++) cout << i << " " << j << endl;
    }
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) solve();
    return 0;
}
/*

*/
