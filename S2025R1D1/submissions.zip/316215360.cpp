#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 1e5 + 3;

void solve() {
    int k; cin >> k;
    int n = k;
    cout << n << "\n";
    vector<pair<int, int>> res;
    for (int j = 2; j <= n; j++)
        res.push_back({1, j});
    for (int j = 1; j <= n && n >= 2; j++)
        res.push_back({2, j});
    for (int i = 3; i <= n; i++)
        res.push_back({i, n});

    for (int i = 3; i <= n; i++) {
        for (int j = 1; j < n; j++)
            res.push_back({i, j});
    }

    for (auto [i, j] : res)
        cout << i << " " << j << "\n";
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}
