#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
typedef long long int lint;

struct str{
	int i;
	int j;
	int vr;
};

bool sortiraj(const str& A, const str& B){
	if(A.vr < B.vr){
		return false;
	}
	else if(A.vr > B.vr){
		return true;
	}
	else{
		if(A.i > B.i){
			return true;
		}
		else if(A.i < B.i){
			return false;
		}
		else{
			return (A.j > B.j);
		}
	}
}

void solve(){
	int n, m, k;
	cin >> n >> m >> k;
	vector<vector<int>> a(n, vector<int>(m));
	vector<int> maxii(n, numeric_limits<int>::min());
	vector<int> maxij(m, numeric_limits<int>::min());
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			cin >> a[i][j];
			maxii[i] = max(maxii[i], a[i][j]);
			maxij[j] = max(maxij[j], a[i][j]);
		}
	}
	vector<pair<int, int>> rez;
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			if((maxii[i] == a[i][j]) && (maxij[j] == a[i][j])){
				rez.push_back({i, j});
				k--;
			}
		}
	}
	if(k < 0){
		cout << -1 << endl;
		return;
	}
	vector<vector<int>> bi(n);
	vector<vector<int>> bj(m);
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			bi[i].push_back(a[i][j]);
			bj[j].push_back(a[i][j]);
		}
	}
	for(int i = 0; i < n; i++){
		sort(bi[i].begin(), bi[i].end());
	}
	for(int j = 0; j < m; j++){
		sort(bj[j].begin(), bj[j].end());
	}
	
	vector<str> ost;

	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			if((maxii[i] != a[i][j]) || (maxij[j] != a[i][j])){
				int mini = numeric_limits<int>::max();
				if((maxii[i] != a[i][j])){
					mini = min(mini, bi[i][distance(bi[i].begin(), upper_bound(bi[i].begin(), bi[i].end(), a[i][j]))]);
				}
				if((maxij[j] != a[i][j])){
					mini = min(mini, bj[j][distance(bj[j].begin(), upper_bound(bj[j].begin(), bj[j].end(), a[i][j]))]);
				}
				str tr;
				tr.i = i;
				tr.j = j;
				tr.vr = mini - a[i][j];
				ost.push_back(tr);
			}
		}
	}

	sort(ost.begin(), ost.end(), sortiraj);
	if(k == (n * m)){
		cout << 0 << endl;
		for(int i = 0; i < n; i++){
			for(int j = 0; j < m; j++){
				cout << i << " " << j << endl;
			}
		}
		return;
	}
	for(int ii = 0; ii < k; ii++){
		rez.push_back({ost[ii].i, ost[ii].j});
	}

	cout << ost[k].vr << endl;
	for(int i = 0; i < rez.size(); i++){
		cout << (rez[i].first + 1) << " " << (rez[i].second + 1) << endl;
	}
}   
 


signed main(){
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}   
