#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1e5+5;


int n, m, q;
vector<int> g[MAXN];
int p[MAXN];
stack<int> leaf;
int tt = 1;
vector<array<int,3>> b[MAXN];
int last[MAXN];
vector<int> c[MAXN];
bitset<MAXN> v;
void dfs(int x){
    for(int k : g[x]){
        for(int t : c[k]){
            c[x].push_back(t);
            b[t].push_back(array<int,3>{k,last[t],tt-1});
            last[t] = tt;
        }
        c[k].clear();
        dfs(k);
    }
    if(c[x].size()==0 && !v[x]) leaf.push(x);
}

void solve(){
    cin >> n >> m >> q;
    for(int i = 1; i < n; ++i){
        int x, y;
        cin >> x >> y;
        if(x>y) swap(x,y);
        g[x].push_back(y);
        p[y] = x;
    }
    for(int i = 1; i <= n; ++i){
        c[i] = {i};
    }
    for(int i = 0; i < m; ++i){
        int x;
        cin >> x;
        dfs(x);
        while(leaf.size()){
            int x = leaf.top();
            leaf.pop();
            g[p[x]].erase(g[p[x]].begin() + (g[p[x]][0]!=x));
            v[x] = 1;
        }
        ++tt;
    }
    for(int i = 1; i <= n; ++i){
        for(int k : c[i]){
            b[k].push_back(array<int,3>{i,last[k],tt-1});
        }
    }
    for(int i = 1; i <= n; ++i){
        reverse(b[i].begin(), b[i].end());
    }
    while(q--){
        int x, y;
        cin >> x >> y;
        int ans = 2e9;
        for(int i = 0; i < min(b[x].size(),b[y].size()); ++i){
            if(b[x][i][0] != b[y][i][0]) break;
            if(!(b[x][i][2]<b[y][i][1] || b[y][i][2]<b[x][i][1])) ans = min(ans, max(b[x][i][1], b[y][i][1]));
        }
        cout << (ans==2e9?-1:ans) << '\n';
    }
}

int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int32_t qqq=1;
    //cin >> qqq;
    while(qqq--)solve();
    return 0;
}