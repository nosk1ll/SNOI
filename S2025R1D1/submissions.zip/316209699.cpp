#include <bits/stdc++.h>

void solve() {
  int n;
  std::cin >> n;
  std::cout << n << "\n";
  for(int i = 1; i <= n; i++) {
    for(int j = n; j >= 1; j--) {
      if(i == 1 && j == 1) {
        continue;
      }
      std::cout << i << " " << j << "\n";
    }
  }
}

int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

