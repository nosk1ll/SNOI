#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;
const ll maxn = 35;
bool a[maxn][maxn];
ll dp[maxn][maxn];
ll n = 25;
bool dbg = 0;
ll f[maxn*2];
pll p[2*maxn];
vector<pll> ans;
void add(ll x,ll y) {
	if(!a[x][y]) ans.pb({x,y});
	a[x][y] = 1;
}
void tc(){
	f[0] = 1;
	f[1] = 1;
	for(ll i = 2;i<2*maxn;i++) f[i] = f[i-1] + f[i-2];
	ll k;
	cin >> k;
	ans.clear();
	add(1,2);
	add(2,1);
	add(2,2);
	p[0] = {1,1};
	p[1] = {2,1};
	p[2] = {2,2};
	ll c = 2;
	for(ll i = 2;i<n-2;i++) {
		add(i+1,i-1);
		add(i+1,i);
		add(i,i+1);
		add(i+1,i+1);
		p[++c] = {i+1,i};
		p[++c] = {i+1,i+1};
	}
	a[1][1] = 1;
	for(ll i = c;i>=0;i--) {
		if(k>=f[i]) {
			k-=f[i];
			if(p[i].fi==p[i].sc) {
				for(ll j = p[i].sc+1;j<n;j++) add(p[i].fi,j);
			}else {
				for(ll j = p[i].fi+1;j<n;j++) add(j,p[i].sc);
			}
		}
	}
	//for(pll p : ans) cerr<<p.fi<<" "<<p.sc<<endl;
	for(ll i = 1;i<n;i++) add(n,i);
	for(ll i = 1;i<n;i++) add(i,n);
	add(n,n);
	if(dbg) {
		for(ll i = 1;i<=n;i++) for(ll j = 1;j<=n;j++) dp[i][j] = 0;
		dp[1][1] = 1;
		for(pll p : ans) {
			ll x = p.fi,y = p.sc;
			dp[x][y] = dp[x-1][y] + dp[x][y-1];
			cerr<<x<< " "<<y<< " "<<dp[x][y]<<endl;
		}
		dbg(dp[n][n]);
	}
	for(ll i = 1;i<=n;i++) for(ll j = 1;j<=n;j++) add(i,j);
	cout<<n<<endl;
	if(!dbg) for(pll p : ans) cout<<p.fi<<" "<<p.sc<<endl;
	for(ll i = 1;i<=n;i++) for(ll j = 1;j<=n;j++) a[i][j] = 0;
}

int main(){
	ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
	int t; t = 1;
	cin >> t;
	while(t--){
		tc();
	}
	return (0-0);
}