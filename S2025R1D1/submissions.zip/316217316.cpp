#include <bits/stdc++.h>

void solve() {
  int n;
  std::cin >> n;
  std::cout << n << "\n";
  for(int i = 2; i <= n; i++) {
    std::cout << 1 << " " << i << "\n";
  }
  for(int i = 2; i <= n; i++) {
    std::cout << i << " " << n - 1 << "\n";
    std::cout << i << " " << n << "\n";
  }
  for(int i = 2; i <= n; i++) {
    for(int j = 1; j <= n - 2; j++) {
      std::cout << i << " " << j << "\n";
    }
  }
}

int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

