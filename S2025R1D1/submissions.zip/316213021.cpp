#include<bits/stdc++.h>
#define pii pair<int,int>
#define MAXLG 21
#define fi first
#define se second
using namespace std;
int n, m, k, d = 0;
int lg[(int)5e5 + 5];
vector<vector<int>>a, vis;
vector<vector<pii>>sp1[MAXLG], sp2[MAXLG];
pii maxp(pii& a, pii& b) {
	return(a.fi > b.fi ? a : b);
}
void precompute() {
	lg[0] = lg[1] = 0;
	for (int i = 2; i < 5e5 + 5; i++) {
		lg[i] = lg[i / 2] + 1;
	}
}
void build() {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			sp1[0][i][j] = { a[i][j],j };
			sp2[0][j][i] = { a[i][j],i };
		}
	}
	for (int i = 1; i <= lg[m]; i++) {
		for (int j = 0; j < n; j++) {
			for (int kk = 0; kk + (1 << (i - 1)) < m; kk++) {
				sp1[i][j][kk] = maxp(sp1[i - 1][j][kk], sp1[i - 1][j][kk + (1 << (i - 1))]);
			}
		}
	}
	for (int i = 1; i <= lg[n]; i++) {
		for (int j = 0; j < m; j++) {
			for (int kk = 0; kk + (1 << (i - 1)) < n; kk++) {
				sp2[i][j][kk] = maxp(sp2[i - 1][j][kk], sp2[i - 1][j][kk + (1 << (i - 1))]);
			}
		}
	}
}
int maxq1(int i, int l, int r) {
	int kk = lg[r - l + 1];
	return maxp(sp1[kk][i][l], sp1[kk][i][r - (1 << kk) + 1]).se;
}
int maxq2(int j, int l, int r) {
	int kk = lg[r - l + 1];
	return maxp(sp2[kk][j][l], sp2[kk][j][r - (1 << kk) + 1]).se;
}
int ppv1(int i, int l, int r) {
	int j1 = maxq1(i, l, r);
	int m1 = a[i][j1];
	if (j1 - l > 0) {
		int re = ppv1(i, l, j1 - 1);
		vis[i][re] = min(vis[i][re], m1 - a[i][re]);
	}if (r - j1 > 0) {
		int re = ppv1(i, j1 + 1, r);
		vis[i][re] = min(vis[i][re], m1 - a[i][re]);
	}
	return j1;
}
int ppv2(int j, int l, int r) {
	int i1 = maxq2(j, l, r);
	int m1 = a[i1][j];
	if (i1 - l > 0) {
		int re = ppv2(j, l, i1 - 1);
		vis[re][j] = min(vis[re][j], m1 - a[re][j]);
	}if (r - i1 > 0) {
		int re = ppv2(j, i1 + 1, r);
		vis[re][j] = min(vis[re][j], m1 - a[re][j]);
	}
	return i1;
}
void solve() {
	cin >> n >> m >> k;
	a.resize(n, vector<int>(m));
	vis.resize(n, vector<int>(m));
	for (int i = 0; i <= MAXLG; i++) {
		sp1[i].resize(n, vector<pii>(m));
		sp2[i].resize(m, vector<pii>(n));
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			cin >> a[i][j];
			vis[i][j] = 1e9;
		}
	}
	build();
	for (int i = 0; i < n; i++) {
		ppv1(i, 0, m - 1);
	}for (int j = 0; j < m; j++) {
		ppv2(j, 0, n - 1);
	}
	vector<array<int, 3>>a2;
	vector<pii>a3;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			if (vis[i][j] == 1e9) {
				k--;
				a3.emplace_back(i, j);
			}
			else {
				a2.push_back({ vis[i][j],i,j });
			}
			if (k < 0) {
				break;
			}
		}
	}
	if (k < 0) {
		cout << -1 << '\n';
		return;
	}
	sort(a2.begin(), a2.end());
	while (k > 0) {
		k--;
		a3.emplace_back(a2[a2.size() - 1][1], a2[a2.size() - 1][2]);
		a2.pop_back();
	}
	if (a2.empty()) {
		cout << 0 << '\n';
	}
	else {
		cout << a2[a2.size() - 1][0] << '\n';
	}
	for (int i = 0; i < a3.size(); i++) {
		cout << a3[i].fi + 1 << ' ' << a3[i].se + 1 << '\n';
	}
}
int32_t main() {
	ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	precompute();
	int32_t T = 1;//cin>>T;
	while (T--) {
		solve();
	}
	return 0;
}