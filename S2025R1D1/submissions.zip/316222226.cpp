#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define ios ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define endl '\n'
#define pb push_back
using namespace std;
using namespace __gnu_pbds;
typedef tree<pair<int,int>, null_type, less<pair<int,int>>, rb_tree_tag, tree_order_statistics_node_update> os;
typedef unsigned long long ull;
typedef long long ll;
void solve(int m, vector<int>& dog){
    int a, b;
    cin>>a>>b;
    int a1 = a, b1 = b;
    set<int> p1, p2;
    while(a1>1){
        a1/=2;
        p1.insert(a1);
    }
    while(b1>1){
        b1/=2;
        p2.insert(b1);
    }
    bool nasao = false;
    for(int i = 0;i<m;i++){
        if(p1.find(dog[i])!=p1.end() && dog[i]< a){
            a/=2;
        }
        if(p2.find(dog[i])!=p2.end() && dog[i] < b){
            b/=2;
        }
        if(a==b){
            cout<<i+1<<endl;
            nasao=true;
            break;
        }
    }
    if(!nasao)cout<<-1<<endl;
}
int main(){
    int n, m, q;
    cin>>n>>m>>q;
    vector<vector<int>> g(n+1);
    vector<int> dog(m);
    for(int i = 0;i<n-1;i++){
        int u, v;
        cin>>u>>v;
        g[u].pb(v);
        g[v].pb(u);
    }
    bool podzadatak = true;
    for(int i = 0;i<m;i++){
        cin>>dog[i];
        if(dog[i]!=1)podzadatak = false;
    }
    if(!podzadatak){
        while(q--){
            solve(m, dog);
        }
        return 0;
    }
    while(q--){
        int a, b;
        cin>>a>>b;
        int tr = 0;
        while(a!=b){
            a=max(1, a/2);
            b = max(1, b/2);
            tr++;
        }
        if(tr>m)cout<<-1<<endl;
        else cout<<tr<<endl;
    }
 
 
}