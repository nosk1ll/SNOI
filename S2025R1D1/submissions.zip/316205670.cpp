#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 2e5 + 3;
vector<pair<int, int>> res;

const int POM[4][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

void solve() {
    int n, m, k; cin >> n >> m >> k;
    vector<vector<int>> a(n+3, vector<int>(m+3));
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> a[i][j];

    auto moze = [&](int d) {
        vector<vector<bool>> vis(n+3, vector<bool>(m+3));
        vector<pair<int, int>> ans;
        priority_queue<tuple<int, int, int>> pq;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                pq.emplace(a[i][j], i, j);
        int can = k;
        while (!pq.empty()) {
            auto [w, i, j] = pq.top(); pq.pop();
            if (vis[i][j]) {
                for (int dd = 0; dd <= 1; dd++) {
                    int poc = (dd == 0 ? 0 : 2), zav = (dd == 0 ? 2 : 4);
                    for (int dx = poc; dx < zav; dx++) {
                        int curi = i, curj = j;
                        while (true) {
                            int ik = curi + POM[dx][0], jk = curj + POM[dx][1];
                            if (ik < 1 || ik > n || jk < 1 || jk > m) break;
                            if (a[ik][jk] > a[i][j]) break;
                            curi = ik; curj = jk;
                            if (a[i][j]-d <= a[ik][jk])
                                vis[ik][jk] = true;
                        }
                    }
                }
                continue;
            }
            vis[i][j] = true;

            for (int dd = 0; dd <= 1; dd++) {
                int poc = (dd == 0 ? 0 : 2), zav = (dd == 0 ? 2 : 4);
                for (int dx = poc; dx < zav; dx++) {
                    int curi = i, curj = j;
                    while (true) {
                        int ik = curi + POM[dx][0], jk = curj + POM[dx][1];
                        if (ik < 1 || ik > n || jk < 1 || jk > m) break;
                        if (a[ik][jk] > a[i][j]) break;
                        curi = ik; curj = jk;
                        if (a[i][j]-d <= a[ik][jk])
                            vis[ik][jk] = true;
                    }
                }
            }
            //dbg(i, j);
            can--;
            ans.push_back({i, j});
        }

        if (can < 0) return false;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++)
                if (can > 0) ans.push_back({i, j}), can--;

        res = ans;
        return true;
    };
    //dbg(moze(1));
    int low = 0, high = n*m;
    while (low < high) {
        int mid = (low + high) / 2;
        if (moze(mid))
            high = mid;
        else
            low = mid+1;
    }
    if (!moze(low)) {
        cout << -1 << "\n"; return;
    }

    cout << low << "\n";
    for (auto [x, y] : res)
        cout << x << " " << y << "\n";
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}
