 #include<bits/stdc++.h>
#define ll long long
#define MAXN 100002
using namespace std;
vector<vector<int>>mag(MAXN);
vector<vector<pair<int,int>>>d(MAXN);
int c[MAXN];
void precalc(int node)
{
    int t=node;
    while(t>0)
    {
        for(int i=0;i<min((int)mag[t].size(),17);i++) d[node].emplace_back(mag[t][i],t);
        t/=2;
    }
    sort(d[node].begin(),d[node].end());
}
int getnode(int u, int k)
{
    for(auto i:d[u]) if(u>i.second && i.first<=k) u=max(i.second,u>>1);
    return u;

}
void solve(int u, int v, int m)
{
    int res=-1;
    int l=0,r=m;
    while(l<=r)
    {
        int mid=(l+r)/2;
        if(getnode(u,mid)==getnode(v,mid))
        {
            res=mid;
            r=mid-1;
        }
        else l=mid+1;
    }
    cout<<res<<endl;
    return;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n,m,q;
    cin>>n>>m>>q;
    int u,v;
    for(int i=0;i<n-1;i++) cin>>u>>v;
    for(int i=0;i<m;i++)
    {
        cin>>u;
        c[i+1]=u;
        mag[u].push_back(i+1);
    }
    for(int i=1;i<=n;i++) precalc(i);
    while(q--)
    {
        cin>>u>>v;
        solve(u,v,m);
    }
}