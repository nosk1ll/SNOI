#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define ios ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define endl '\n'
#define pb push_back
using namespace std;
using namespace __gnu_pbds;
typedef tree<pair<int,int>, null_type, less<pair<int,int>>, rb_tree_tag, tree_order_statistics_node_update> os;
typedef unsigned long long ull;
typedef long long ll;
void solve(){
    int k;
    cin>>k;
    if(k<=150){
        cout<<k<<endl;
        int cnt = 0;
        for(int i = 2;i<=k;i++){
            cout<<1<<" "<<i<<endl;
        }
        if(k>1){
            for(int i = 1;i<=k;i++){
                cout<<2<<" "<<i<<endl;
            }
        }
        for(int i = 3;i<=k;i++){
            cout<<i<<" "<<k<<endl;
        }
        for(int i = 3;i<=k;i++){
            for(int j = 1;j<k;j++){
                cout<<i<<" "<<j<<endl;
            }
        }
    }
}
int main(){
    int t;
    cin>>t;
    while(t--)solve();
}