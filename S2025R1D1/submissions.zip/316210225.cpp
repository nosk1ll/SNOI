#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 1000 + 10;

const int inf = 1e16;

int ans[N][N], n, m, q, in[N], out[N], timer = 0, c[N], par[N];
vector<int> g[N];

void init(int n) {
  for(int i = 1; i <= n; i++) par[i] = i;
}

int get(int x) {
  return (x == par[x] ? x : par[x] = get(par[x]));
}

void unite(int u, int v) {
  u = get(u); v = get(v);
  if(u == v) return;
  par[u] = v;
}

bool same(int u, int v) {
  return (get(u) == get(v));
}

void Dfs(int x, int p) {
  in[x] = ++timer;
  for(int j : g[x]) {
    if(j != p) {
      Dfs(j, x);
    }
  }
  out[x] = timer;
}

bool In(int u, int v) {
  return (in[u] <= in[v] && out[u] >= out[v]);
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> n >> m >> q;
  for(int i = 1; i < n; i++) {
    int u, v;
    cin >> u >> v;
    g[u].push_back(v);
    g[v].push_back(u);
  }
  Dfs(1, 0);
  for(int i = 1; i <= m; i++) cin >> c[i];
  vector<array<int, 3>> kveri;
  vector<int> ans(q + 1, inf);
  for(int i = 1; i <= q; i++) {
    int a, b;
    cin >> a >> b;
    kveri.push_back({a, b, i});
  }
  if(n <= 1000) {
    vector<int> p(n + 1);
    for(int i = 1; i <= n; i++) p[i] = i;
    init(n);
    for(int i = 1; i <= m; i++) {
      vector<pair<int,int>> vec;
      for(int j = 1; j <= n; j++) {
        if(p[j] != c[i] && In(c[i], p[j])) p[j] /= 2;
        vec.push_back({p[j], j});
      }
      sort(vec.begin(), vec.end());
      for(int i = 1; i < vec.size(); i++) {
        if(vec[i].first == vec[i - 1].first) unite(vec[i - 1].second, vec[i].second);
      }
      for(auto xx : kveri) {
        if(same(xx[0], xx[1])) ans[xx[2]] = min(ans[xx[2]], i);
      }
    }
    for(int i = 1; i <= q; i++) cout << (ans[i] == inf ? -1 : ans[i]) << "\n";
    return 0;
  }
  for(auto x : kveri) {
    int a = x[0], b = x[1];
    int res = 0;
    while(a > 1 && b > 1) {
      if(a == b) break;
      res++;
      a /= 2;
      b /= 2;
    }
    if(a == b) {
      cout << (res <= n ? res : -1) << "\n";
      continue;
    }
    while(a > 1) {
      res++;
      a /= 2;
    }
    while(b > 1) {
      res++;
      b /= 2;
    }
    cout << (res <= n ? res : -1) << "\n";
  }
}
