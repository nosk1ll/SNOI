#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=490050;
int n,m,K;
vector<vector<int>>a;
int Lv[N],Rv[N],Gv[N],Dv[N];
pair<int,int>ind[N];
vector<pair<int,int>>temp;
vector<vector<bool>>was;
bool Probaj(int D){
	queue<pair<int,int>>kju;
	temp.clear();
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) was[i][j]=false;
	int k=K;
	bool moze=true;
	for(int I=m*n;I>=1;I--){
		int x=ind[I].fi,y=ind[I].se;
		if(was[x][y]) continue;
		k--;temp.pb({x,y});
		if(k<0){moze=false;break;}
		kju.push({x,y});
		while(!kju.empty()){
			x=kju.front().fi,y=kju.front().se;kju.pop();
			for(int j=y+1;j<=m;j++){
				if(a[x][j]>a[x][y]) break;
				if(was[x][j]||abs(a[x][y]-a[x][j])>D) continue;
				kju.push({x,j});
				was[x][j]=true;
			}
			for(int j=y-1;j>=1;j--){
				if(a[x][j]>a[x][y]) break;
				if(was[x][j]||abs(a[x][y]-a[x][j])>D) continue;
				kju.push({x,j});
				was[x][j]=true;
			}

			for(int i=x+1;i<=n;i++){
				if(a[i][y]>a[x][y]) break;
				if(was[i][y]||abs(a[x][y]-a[i][y])>D) continue;
				kju.push({i,y});
				was[i][y]=true;
			}
			for(int i=x-1;i>=1;i--){
				if(a[i][y]>a[x][y]) break;
				if(was[i][y]||abs(a[x][y]-a[i][y])>D) continue;
				kju.push({i,y});
				was[i][y]=true;
			}
		}
	}
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) was[i][j]=false;
	return moze;
}
int main(){
	scanf("%i%i%i",&n,&m,&K);
	for(int i=0;i<=n;i++){
		vector<int>nesto(m+1,0);
		a.pb(nesto);
		vector<bool>nesto1(m+1,0);
		was.pb(nesto1);
	}
	for(int i=1;i<=n;i++) for(int j=1,x;j<=m;j++) scanf("%i",&x),a[i][j]=x,ind[a[i][j]]={i,j};
	/*for(int i=1;i<=n;i++){
		vector<int>mono;
		for(int j=1;j<=m;j++){

		}
	}*/
	int l=0,r=1e9,res=-1;
	vector<pair<int,int>>res1;
	while(l<=r){
		int mid=l+r>>1;
		if(Probaj(mid)){
			res=mid;
			res1=temp;
			r=mid-1;
		}
		else l=mid+1;
	}
	printf("%i\n",res);
	if(res!=-1){
		if(res1.size()<K){
			for(auto [u,v]:res1) was[u][v]=true;
			for(int i=1;i<=n;i++) for(int j=1;j<=m;j++){
				if(was[i][j]||res1.size()>=K) continue;
				res1.pb({i,j});
			}
		}
		for(auto [u,v]:res1) printf("%i %i\n",u,v);
	}
    return 0;
}
