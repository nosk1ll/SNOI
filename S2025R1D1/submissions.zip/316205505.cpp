#include <bits/stdc++.h>

const int N = 1e5 + 5;

std::set<int> st[N];

struct Lca{
    std::vector<int>adj[N];
    int in[N];
    int out[N];
    int timer=1;
    int P[N];
    int depth[N];
    int Log(int n){
        int logs[n+1];
        logs[1]=0;
        for(int i=2;i<=n;i++)logs[i]=logs[i/2]+1;
        return logs[n];
    }
    int up[N][30];
    void build(int n){
        up[1][0]=1;
        for(int i=2;i<=n;i++)up[i][0]=P[i];
        for(int i=1;i<=29;i++){
            for(int j=1;j<=n;j++){
                up[j][i]=up[up[j][i-1]][i-1];
            }
        }
    }
    void connect(int u,int v){
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    void dfs(int x,int cale, int dep){
        in[x]=timer++;
        P[x]=cale;
        depth[x] = dep;
        for(auto it:adj[x]){
            if(it!=cale)dfs(it,x, dep + 1);
        }
        out[x]=timer;
    }
    int in_tree(int u,int v){
        return in[u]<=in[v]&&out[u]>=out[v];
    }
    int lca(int u,int v){
        if(u==v)return u;
        if(in_tree(u,v))return u;
        if(in_tree(v,u))return v;
        for(int i=29;i>=0;i--){
            if(!in_tree(up[u][i],v)){
                u=up[u][i];
            }
        }
        return up[u][0];
    }
    int dist(int u, int v) {
      return depth[u] + depth[v] - 2 * depth[lca(u, v)];
    }
}lca;

int acs(int l1, int r1, int l2, int r2) {
  if(l1 > r1)
    return 0;
  if(l2 > r2) {
    return 0;
  }
  int L = std::max(l1, l2);
  int R = std::min(r1, r2);
  if(L <= R) {
    return R - L + 1;
  }
  else {
    return 0;
  }
}

std::vector<std::array<int, 3>> posu, posv;

void solve() {
  int n, m, q;
  std::cin >> n >> m >> q;
  for(int i = 1; i < n; i++) {
    int u, v;
    std::cin >> u >> v;
    lca.connect(u, v);
  }
  lca.dfs(1, 0, 0);
  lca.build(n);
  std::vector<int> c(m + 1);
  for(int i = 1; i <= m; i++) {
    std::cin >> c[i];
    st[c[i]].insert(i);
  }
  for(int i = 1; i <= q; i++) {
    int u, v;
    std::cin >> u >> v;
    int time = 0;
    while(u != 0) {
      int next = m + 2;
      for(int ath = lca.P[u]; ath != 0; ath = lca.P[ath]) {
        if(st[ath].upper_bound(time) != st[ath].end())
          next = std::min(next, *st[ath].upper_bound(time));
      }
      if(next >= m) {
        posu.push_back({u, time, m});
        break;
      }
      posu.push_back({u, time, next - 1});
      time = next;
      u = lca.P[u];
    }
    time = 0;
    while(v != 0) {
      int next = m + 2;
      for(int ath = lca.P[v]; ath != 0; ath = lca.P[ath]) {
        if(st[ath].upper_bound(time) != st[ath].end()) {
          next = std::min(next, *st[ath].upper_bound(time));
        }
      }
      if(next >= m) {
        posv.push_back({v, time, m});
        break;
      }
      posv.push_back({v, time, next - 1});
      time = next;
      v = lca.P[v];
    }
    /**
    for(auto [node1, in1, out1] : posu) {
      std::cout << node1 << " " << in1 << " " << out1 << "\n";
    }
    std::cout << "\n";
    for(auto [node2, in2, out2] : posv) {
      std::cout << node2 << " " << in2 << " " << out2 << "\n";
    }**/
    int ans = m + 1;
    for(auto [node1, in1, out1] : posu) {
      for(auto [node2, in2, out2] : posv) {
        if(node1 == node2) {
          if(acs(in1, out1, in2, out2) > 0) {
            ans = std::min(ans, std::max(in1, in2));
          }
        }
      }
    }
    std::cout << (ans == m + 1 ? - 1 : ans) << "\n";
    posu.clear();
    posv.clear();
  }
}

int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

