#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 1e6 + 10;

const int inf = 1e16;

int Ask(int i, int j) {
  cout << "? " << i << " " << j << endl;
  int x;
  cin >> x;
  return x;
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  int n;
  cin >> n;
  vector<int> a(n + 1);
  for(int i = 1; i <= n; i++) a[i] = Ask(i, 1);
  vector<int> all;
  for(int i = 1; i <= n; i++) all.push_back(a[i]);
  sort(all.begin(), all.end());
  all.erase(unique(all.begin(), all.end()), all.end());
  int j = 0;
  int cnt = 0;
  int val, mx = all.back();
  for(int i = 1; i <= n; i++) if(a[i] == mx) cnt++;
  if(cnt > 1) val = mx;
  else {
    if(Ask(1, 2) > Ask(3, 2)) val = mx;
    else val = all[all.size() - 2];
  }
  for(int i = 1; i <= n; i++) if(val == a[i]) j = i;
  vector<int> x(n + 1);
  for(int i = 1; i <= n; i++) x[i] = Ask(j, i);
  cout << "! ";
  for(int i = 1; i <= n; i++) cout << x[i] << " ";
  cout << endl;
}
