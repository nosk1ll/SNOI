#include <bits/stdc++.h>
#define ll long long
#define MAXN 110
using namespace std;
ll h[MAXN];
int main()
{
    ll n,ans;
    cin >> n;
    vector<pair<ll,ll> > v;
    for (ll i=1;i<=n;i++)
    {
        cout << "? " << i << " " << 1 << "\n";
        cin >> ans;
        v.push_back({ans,i});
    }
    sort(v.begin(),v.end(),greater<pair<ll,ll> >());
    ll ind;
    if (v[0].first==v[1].first || v[1].first==v[2].first)
    {
        ind=v[1].second;
        for (ll i=1;i<=n;i++)
        {
            cout << "? " << ind << " " << i << "\n";
            cin >> ans;
            h[i]=ans;
        }
        cout << "! ";
        for (ll i=1;i<=n;i++)
            cout << h[i] << " ";
        cout << "\n";
        return 0;
    }
    ll ans1,ans2;
    cout << "? " << v[0].second << " " << v[2].second << "\n";
    cin >> ans1;
    cout << "? " << v[1].second << " " << v[2].second << "\n";
    cin >> ans2;
    if (ans1>ans2)
        ind=v[0].second;
    else
        ind=v[1].second;
    for (ll i=1;i<=n;i++)
    {
        cout << "? " << ind << " " << i << "\n";
        cin >> ans;
        h[i]=ans;
    }
    cout << "! ";
    for (ll i=1;i<=n;i++)
        cout << h[i] << " ";
    cout << "\n";
    return 0;
}
