#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define int long long
#define ldb long double
typedef pair<int, int> pl;
typedef vector<int> vi;
typedef vector<int> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
const int N=2e5+10;

int n, m, k;
vi g[N];
vi soba[N];
int ans;

set<int> st;

void dfs(int x, int par) {
    for (int u:g[x])
        if (u!=par)
            dfs(u, x);
    for (auto z:soba[x])
        st.erase(z);
    int i=0;
    for (int x:st) {
        if (i==(sz(st)/2))
            ans=min(ans, x);
        i++;
    }
}

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

    cin >> n >> m >> k;
    for (int i=1; i<=n; i++) {
        int s; cin >> s;
        soba[s].pb(i);
    }
    for (int i=2; i<=m; i++) {
        int p; cin >> p;
        g[i].pb(p);
        g[p].pb(i);
    }
    for (int i=1; i<=n; i++)
        st.ins(i);
    ans=(n+1)/2;
    dfs(1, -1);
    cout << ans << nl;
	return 0;
}
