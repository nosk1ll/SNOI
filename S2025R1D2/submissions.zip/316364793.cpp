#include <bits/stdc++.h>
#define int long long
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define sc second
#define endl "\n"
#define pii pair<int,int>

using namespace std;

const int MAXN = 1e5+5;
const int mod7 = 1e9+7;
const long long inf = 1e18;

int ask(int i, int j)
{
    cout << "? " << i << " " << j << endl;
    cout.flush();
    int x;
    cin >> x;
    return x;
}

void guess(vector<int> niz)
{
    cout << "! ";
    for(int i=1; i<(int)niz.size(); i++)cout << niz[i] << " ";cout << endl;
    cout.flush();
}

signed main()
{
    ios_base::sync_with_stdio(false),cin.tie(0), cout.tie(0);
    int tt=1;
    //cin >> tt;
    while(tt--)
    {
        int n;
        cin >> n;
        vector<int> resenje(n+1, -1);
        if(n <= 99)
        {
            vector<int> niz(n+1);
            for(int i=2; i<=n; i++)niz[i] = ask(i,1);
            int mx1 = 0;
            int mx2 = 0;
            int imx1 = 0;
            int imx2 = 0;
            for(int i=2; i<=n; i++)
            {
                if(niz[i] > mx1)
                {
                    mx2 = mx1;
                    imx2 = imx1;
                    mx1 = niz[i];
                    imx1 = i;
                }
                else if(niz[i] > mx2)
                {
                    mx2 = niz[i];
                    imx2 = i;
                }
            }
            vector<vector<int>> mat(4, vector<int>(4, 0));
            /// imx1 = 2 imx2 = 3
            mat[2][1] = mx1;
            mat[3][1] = mx2;
            mat[2][3] = ask(imx1, imx2);
            mat[3][2] = ask(imx2, imx1);
            mat[1][2] = ask(1, imx1);
            mat[1][3] = ask(1, imx2);
            int istinjak = 0;
            int mxv = 0;
            for(int j=1; j<=3; j++)
            {
                if(mat[j][1] > mxv)
                {
                    mxv = mat[j][1];
                    istinjak = j;
                }
            }
            if(istinjak == 1)
            {
                resenje[imx1] = mat[1][2];
                resenje[imx2] = mat[1][3];
            }
            else if(istinjak == 2)
            {
                resenje[1] = mat[2][1];
                resenje[imx2] = mat[2][3];
                istinjak = imx1;
            }
            else
            {
                resenje[1] = mat[3][1];
                resenje[imx1] = mat[3][2];
                istinjak = imx2;
            }
            for(int i=1; i<=n; i++)
            {
                if(resenje[i]!=-1)continue;
                resenje[i] = ask(istinjak, i);
            }
            guess(resenje);

        }
        else
        {

        }
    }
}
