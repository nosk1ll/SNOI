#include <bits/stdc++.h>
using namespace std;
int N, X, Y, I;
int D[101];
int main()
{
  cin >> N;
  map <int, int> MAP;
  for(int i = 2; i <= N; i++)
  {
    cout << "? " << i << " 1" << endl;
    cin >> X;
    MAP[X] = i;
  }
  if(MAP.size() > 2) exit(333); ///lose sam razumeo tekst onda
  if(MAP.size() == 1)
  {
    cout << "? 1 2" << endl;
    cin >> X;
    cout << "? 3 2" << endl;
    cin >> Y;
    if(X >= Y) {I = 1; D[2] = X;}
    else {I = 3; D[1] = MAP.begin()->first; D[2] = Y;}
  }
  else {D[1] = MAP.rbegin()->first; I = MAP.rbegin()->second;}
  for(int i = 1; i <= N; i++)
  {
    if(D[i]) continue;
    cout << "? " << I << ' ' << i << endl;
    cin >> D[i];
  }
  cout << "!";
  for(int i = 1; i <= N; i++) cout << ' ' << D[i];
  cout << endl;

  return 0;
}
