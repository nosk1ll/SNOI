#include <bits/stdc++.h>
#define ll long long
#define MAXN 200010
#define MAXM 2010
using namespace std;
ll n,m,k,s[MAXN];
vector<ll> G[MAXM];
bool b[MAXM];
void DFS(ll i,ll p)
{
    for (ll next : G[i])
    {
        if (next!=p)
        {
            b[next]=(b[next] || b[i]);
            DFS(next,i);
        }
    }
}
ll ans=LLONG_MAX;
void Solve(ll cur,ll ind)
{
    if (ind==m)
    {
        ll cnt=0;
        for (ll i=0;i<m;i++)
        {
            b[i+1]=(((1<<i)&cur)!=0);
            cnt+=b[i+1];
        }
        if (cnt>k)
            return;
        DFS(1,0);
        vector<ll> cur;
        for (ll i=1;i<=n;i++)
        {
            if (!b[s[i]])
                cur.push_back(i);
        }
        ll sz=cur.size();
        ans=min(ans,cur[(sz+2)/2-1]);
        return;
    }
    Solve(cur,ind+1);
    Solve(cur+(1<<ind),ind+1);
}
ll sz;
struct seg_tree
{
    vector<ll> st;
    void Init()
    {
        sz=1;
        while (sz<n)
            sz <<= 1;
        st.resize(2*sz+2);
    }
    void Build()
    {
        for (ll i=sz;i<sz+n;i++)
            st[i]=1;
        for (ll i=sz-1;i>0;i--)
            st[i]=st[2*i]+st[2*i+1];
    }
    void Update(ll pos,ll val,ll x,ll lx,ll rx)
    {
        if (lx==rx)
        {
            st[x]=val;
            return;
        }
        ll mid=(lx+rx)/2;
        if (pos<=mid)
            Update(pos,val,2*x,lx,mid);
        else
            Update(pos,val,2*x+1,mid+1,rx);
        st[x]=st[2*x]+st[2*x+1];
    }
    ll Calc(ll l,ll r,ll x,ll lx,ll rx)
    {
        if (lx>r || rx<l)
            return 0;
        if (lx>=l && rx<=r)
            return st[x];
        ll mid=(lx+rx)/2;
        return Calc(l,r,2*x,lx,mid)+Calc(l,r,2*x+1,mid+1,rx);
    }
};
seg_tree S;
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll p;
    cin >> n >> m >> k;
    for (ll i=1;i<=n;i++)
        cin >> s[i];
    bool sub2=true;
    for (ll i=2;i<=m;i++)
    {
        cin >> p;
        if (p!=i-1)
            sub2=false;
        G[i].push_back(p);
        G[p].push_back(i);
    }
    if (n<=16 && m<=16)
    {
        Solve(0,0);
        cout << ans;
        return 0;
    }
    if (sub2)
    {
        vector<ll> v[n+2];
        for (ll i=1;i<=n;i++)
            v[s[i]].push_back(i);
        S.Init();
        S.Build();
        ans=(n+2)/2;
        ll num=n;
        for (ll i=m;i>0;i--)
        {
            for (auto j : v[i])
            {
                S.Update(j,0,1,1,sz);
                num--;
            }
            ll l=1,r=n,mid,cur;
            while (l<=r)
            {
                mid=(l+r)/2;
                if (S.Calc(1,mid,1,1,sz)>=(num+2)/2)
                {
                    cur=mid;
                    r=mid-1;
                }
                else
                    l=mid+1;
            }
            ans=min(ans,cur);
        }
        cout << ans;
        return 0;
    }
    return 0;
}
