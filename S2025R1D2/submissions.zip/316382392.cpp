#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 2e5 + 3;
const int M = 2003;
const int inf = 1e9;
int s[N], a[N];
int dp[M][M];
int dp2[N];
vector<int> adj[N];
vector<int> takm[N];
vector<int> nule;
int n, m, k;

void calc(int u, int p) {
    for (int j = 0; j <= k; j++)
        dp[u][j] = a[u];

    for (auto x : adj[u]) if (x != p) {
        calc(x, u);
    }
    for (auto x : adj[u]) if (x != p) {
        for (int jj = k; jj >= 0; jj--) {
            int mx = -inf;
            for (int s1 = jj; s1 >= 0; s1--) {
                mx = max(mx, dp[x][s1] + dp[u][jj-s1]);
            }
            dp[u][jj] = mx;
        }
    }
    for (int j = 1; j <= k; j++)
        dp[u][j] = max(dp[u][j], 0);
}

void calc2(int u, int p) {
    dp2[u] = a[u];

    for (auto x : adj[u]) if (x != p) {
        calc2(x, u);
    }
    for (auto x : adj[u]) if (x != p) {
        dp2[u] += dp2[x];
        //dbg(u, x, dp2[u]);
    }
    dp2[u] = max(0, dp2[u]);
}

void solve() {
    cin >> n >> m >> k;
    for (int i = 1; i <= n; i++) {
        cin >> s[i];
        if (s[i] == 0) nule.push_back(i);
        else {
            takm[s[i]].push_back(i);
        }
    }
    for (int i = 2; i <= m; i++) {
        int pi; cin >> pi;
        adj[pi].push_back(i);
        adj[i].push_back(pi);
    }

    auto moze = [&](int mid) {
        for (int i = 1; i <= m; i++) {
            a[i] = 0;
            for (auto x : takm[i])
                a[i] += (x <= mid ? 1 : -1);
            //dbg(a[i], i);
        }
        if (k != m) {
            calc(1, -1);
            int ss = 0;
            for (auto x : nule) ss += (x <= mid ? 1 : -1);
            int ans = ss + dp[1][k];
            //dbg(ss, dp[1][k], dp[2][k], dp[3][k], dp[4][k], dp[4][0]);
            return (ans > 0);
        } else {
            calc2(1, -1);
            int ss = 0;
            for (auto x : nule) ss += (x <= mid ? 1 : -1);
            int ans = ss + dp2[1];
            //dbg(dp2[1], dp2[2], dp2[3], dp2[4], a[4], dp2[5]);
            return (ans > 0);
        }

    };
    //dbg(moze(3));

    int low = 1, high = n;
    while (low < high) {
        int mid = (low + high) / 2;
        if (moze(mid))
            high = mid;
        else
            low = mid+1;
    }

    cout << low << "\n";
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}
/*
6 5 5
1 3 4 2 5 0
1 2 3 4

7 5 5
4 3 5 0 5 2 1
1 2 2 1

10 14 1
12 6 8 0 9 13 5 0 9 6
1 2 3 2 3 2 5 5 9 10 8 8 12

10 10 4
4 7 10 0 10 10 0 8 9 10
1 2 2 1 2 5 4 8 5

20 20 14
20 17 14 11 0 16 12 9 9 4 18 15 16 2 11 5 14 14 18 0
1 2 3 2 4 2 2 4 7 9 9 10 9 12 13 1 12 11 3
*/
