#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 200005;
const ll maxx = 20000005;
ll n,q;
ll a[maxn];
ll Q[maxn][3];
ll root[4*maxn],ls[maxx],rs[maxx],tsz = 0;
ll t[maxx];
map<ll,ll> val;
map<ll,ll> mp;
void init(ll &v,ll tl,ll tr) {
	if(!v) v = ++tsz;
	if(!root[v]) root[v] = ++tsz;
	if(tl==tr) return;
	ll mid = (tl+tr)/2;
	init(ls[v],tl,mid);
	init(rs[v],mid+1,tr);
}
void upd2(ll &v,ll tl,ll tr,ll i,ll x,bool f) {
	if(!v) v = ++tsz;
	if(tl==tr) {
		if(f==0) t[v] += val[x];
		else t[v] -= val[x];
		return;
	}
	ll mid = (tl+tr)/2;
	if(i<=mid) upd2(ls[v],tl,mid,i,x,f);
	else upd2(rs[v],mid+1,tr,i,x,f);
	t[v] = t[ls[v]] + t[rs[v]];
}
ll get2(ll v,ll tl,ll tr,ll l,ll r) {
	if(v==0) return 0;
	if(l>r||l>tr||tl>r||tl>tr) return 0;
	if(tl>=l&&tr<=r) return t[v];
	ll mid = (tl+tr)/2;
	return get2(ls[v],tl,mid,l,r) + get2(rs[v],mid+1,tr,l,r);
}
ll get(ll v,ll tl,ll tr,ll l,ll r,ll x,ll y) {
	if(l>r||l>tr||tl>r||tl>tr) return 0;
	if(tl>=l&&tr<=r) return get2(root[v],1,n,x,y);
	ll mid = (tl+tr)/2;
	return get(ls[v],tl,mid,l,r,x,y) + get(rs[v],mid+1,tr,l,r,x,y);
}
void upd(ll &v,ll tl,ll tr,ll x,ll i,bool f = 0) {
	if(!v) v = ++tsz;
	upd2(root[v],1,n,i,x,f);
	if(tl==tr) return;
	ll mid = (tl+tr)/2;
	if(x<=mid) upd(ls[v],tl,mid,x,i,f);
	else upd(rs[v],mid+1,tr,x,i,f);
}
set<ll> s;
int main(){
	ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
	cin >> n >> q;
	for(ll i = 1;i<=n;i++) cin >> a[i],s.insert(a[i]);
	for(ll i = 1;i<=q;i++) {
		cin >> Q[i][0] >> Q[i][1] >> Q[i][2];
		if(Q[i][0]==2) s.insert(Q[i][2]);
	}
	ll mx = 0;
	for(ll x : s) mp[x] = val[x] = x;
	mx = 20;
	init(root[0],1,mx);
	for(ll i = 1;i<=n;i++) upd(root[0],1,mx,mp[a[i]],i);
	for(ll f = 1;f<=q;f++) {
		ll tip = Q[f][0],l = Q[f][1],r = Q[f][2];
		if(tip==1) {
			ll x = 0;
			while(1) {
				auto it = s.upper_bound(x+1);
				if(it==s.begin()) break;
				it--;
				ll y = get(root[0],1,mx,1,*it,l,r);
				if(y==x) break;
				x = y;
			}
			cout<<x+1<<endl;
		}else{
			upd(root[0],1,mx,mp[a[l]],l,1);
			a[l] = r;
			upd(root[0],1,mx,mp[a[l]],l);
		}
	}
	return (0-0);
}
/**
5
3
1 1 1 1 1
1 2 4
2 3 4
1 2 5
**/