#include <bits/stdc++.h>



void solve() {
  int n;
  std::cin >> n;
  std::function<int(int, int)> ask = [&] (int x, int y) {
    std::cout << "? " << x << " " << y << std::endl;
    int r;
    std::cin >> r;
    return r;
  };
  int istina = - 1;
  int h = - 1;
  for(int i = 2; i <= n; i++) {
    int pitaj = ask(i, 1);
    assert(pitaj > 0);
    if(pitaj > h) {
      istina = i;
      h = pitaj;
    }
  }
  std::vector<int> ans(n + 1, - 1);
  if(ask(1, 1) <= h) {
    // istina 1
    for(int i = 1; i <= n; i++) {
      //std::cout << ask(1, i) << " ";
      ans[i] = ask(1, i);
    }
  }
  else {
    // istina istina
    for(int i = 1; i <= n; i++) {
      //std::cout << ask(istina, i) << " ";
      ans[i] = ask(istina, i);
    }
  }
  std::cout << "! ";
  for(int i = 1; i <= n; i++) {
    std::cout << ans[i] << " ";
  }
}


int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

