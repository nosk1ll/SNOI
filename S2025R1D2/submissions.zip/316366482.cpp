#include <bits/stdc++.h>

using namespace std;

const int B = 32;

const int N = 1e5 + 5;

int64_t inf = 1e15;

struct segtree {
    int64_t t[4 * N];

    int64_t query(int v, int tl, int tr, int l, int r) {
        if (tl > r || tr < l) return 0;
        if (tl >= l && tr <= r) return t[v];
        int tm = (tl + tr) / 2;
        return query(v * 2, tl, tm, l, r) +
               query(v * 2 + 1, tm + 1, tr, l, r);
    }

    void update(int v, int tl, int tr, int index, int64_t value) {
        if (tl == tr) {
            t[v] = value;
        } else {
            int tm = (tl + tr) / 2;
            if (index <= tm)
                update(v * 2, tl, tm, index, value);
            else
                update(v * 2 + 1, tm + 1, tr, index, value);
            t[v] = t[v * 2] + t[v * 2 + 1];
        }
    }
}sum[B];


struct segtree_for_min {
    int64_t t[4 * N];

    int64_t query(int v, int tl, int tr, int l, int r) {
        if (tl > r || tr < l) return inf;
        if (tl >= l && tr <= r) return t[v];
        int tm = (tl + tr) / 2;
        return min(query(v * 2, tl, tm, l, r),
                   query(v * 2 + 1, tm + 1, tr, l, r));
    }

    void update(int v, int tl, int tr, int index, int value) {
        if (tl == tr) {
            t[v] = value;
        } else {
            int tm = (tl + tr) / 2;
            if (index <= tm) update(v * 2, tl, tm, index, value);
            else update(v * 2 + 1, tm + 1, tr, index, value);
            t[v] = min(t[v * 2], t[v * 2 + 1]);
        }
    }
}seg[B];

void solve() {
  for(int b = 0; b < B; b++) {
    for(int i = 0; i < 4 * N; i++) {
      seg[b].t[i] = inf;
      sum[b].t[i] = 0;
    }
  }
  int n, q;
  std::cin >> n >> q;
  std::vector<int64_t> a(n + 1);
  for(int i = 1; i <= n; i++) {
    std::cin >> a[i];
    int grupa = (int)log2(a[i]);
    seg[grupa].update(1, 1, n, i, a[i]);
    sum[grupa].update(1, 1, n, i, a[i]);
  }
  while(q--) {
    int type;
    std::cin >> type;
    if(type == 1) {
      int l, r;
      std::cin >> l >> r;
      int64_t current_sum = 0;
      int64_t ans = - 1;
      for(int i = 0; i < B; i++) {
        if(current_sum + 1 < (1LL << (i + 1)) && seg[i].query(1, 1, n, l, r) > current_sum + 1) {
          ans = current_sum + 1;
          break;
        }
        current_sum += sum[i].query(1, 1, n, l, r);
      }
      std::cout << (ans == - 1 ? current_sum + 1 : ans) << "\n";
    }
    else {
      int i, x;
      std::cin >> i >> x;
    }
  }
}

int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}
/**
5 12
1 2 3 4 5
1 1 3
1 1 5
2 3 1000
1 1 3
2 3 12
1 1 5
2 1 2
1 1 5
2 4 1
1 1 5
1 2 4
1 3 3

1 2 1000 4 5

1 2 12 4 5
2 2 12 4 5


**/
