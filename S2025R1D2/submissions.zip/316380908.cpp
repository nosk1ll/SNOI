#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=1e5+50,M=6e5;
const ll inf=1e18;
void Unique(vector<ll>&a){sort(a.begin(),a.end());int m=unique(a.begin(),a.end())-a.begin();a.resize(m);}
vector<ll>Merge(vector<ll>a,vector<ll>b){
	vector<ll>c;c.reserve(a.size()+b.size()+10);
	for(int i=0,j=0;i<=a.size();i++){
		while(j<b.size()&&(i==a.size()||a[i]>b[j])){
			if(c.empty()||c.back()!=b[j]) c.pb(b[j]);
			j++;
		}
		if(i!=a.size()&&(c.empty()||c.back()!=a[i])) c.pb(a[i]);
	}
	return c;
}
ll a[N];
int main(){
    int n,q;scanf("%i%i",&n,&q);
    for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
    while(q--){
		int type,l,r;scanf("%i%i%i",&type,&l,&r);
		if(type==1){
			/*vector<ll>b={0};
			for(int i=l;i<=r;i++){
				int m=b.size();
				vector<ll>c;
				for(int j=0;j<m;j++) if(b[j]+a[i]<M) c.pb(b[j]+a[i]);
			}
			//for(auto i:b) printf("%lld ",i);printf("\n");
			b.pb(inf);
			ll res=0;
			for(int i=0;i+1<b.size();i++) if(b[i+1]>b[i]+1){res=b[i]+1;break;}*/
			vector<int>b;
			for(int i=l;i<=r;i++) b.pb(a[i]);
			sort(b.begin(),b.end());
			ll sum=0,res=0;
			for(int i=0;i<b.size();i++){
				if(sum+1<b[i]){res=sum+1;break;}
				sum+=b[i];
			}
			res=sum+1;
			printf("%lld\n",res);
		}
		else{
			a[l]=r;
		}
    }
    return 0;
}
