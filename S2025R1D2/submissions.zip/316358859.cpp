#include <bits/stdc++.h>
using namespace std;
int N;
int D[101];
int main()
{
  cin >> N;
  int index = 2, best, temp, random, x, y;
  cout << "? 2 1" << endl;
  cin >> best;
  for(int i = 3; i <= N; i++)
  {
    cout << "? " << i << " 1" << endl;
    cin >> temp;
    if(temp > best) {index = i; best = temp;}
  }
  for(int i = 2; i <= N; i++) if(i != index) {random = i; break;}
  cout << "? 1 " << random << endl;
  cin >> x;
  cout << "? " << index << ' ' << random << endl;
  cin >> y;
  if(x > y) {index = 1; D[random] = x;}
  else {D[1] = best; D[random] = y;}
  for(int i = 1; i <= N; i++)
  {
    if(D[i]) continue;
    cout << "? " << index << ' ' << i << endl;
    cin >> D[i];
  }
  cout << "!";
  for(int i = 1; i <= N; i++) cout << ' ' << D[i];
  cout << endl;

  return 0;
}
