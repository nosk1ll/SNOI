#include <bits/stdc++.h>
#define ll long long
#define MAXN 200010
#define MAXM 2010
using namespace std;
ll n,m,k,s[MAXN];
vector<ll> G[MAXM];
bool b[MAXM];
void DFS(ll i,ll p)
{
    for (ll next : G[i])
    {
        if (next!=p)
        {
            b[next]=(b[next] || b[i]);
            DFS(next,i);
        }
    }
}
ll ans=LLONG_MAX;
void Solve(ll cur,ll ind)
{
    if (ind==m)
    {
        ll cnt=0;
        for (ll i=0;i<m;i++)
        {
            b[i+1]=(((1<<i)&cur)!=0);
            cnt+=b[i+1];
        }
        if (cnt>k)
            return;
        DFS(1,0);
        vector<ll> cur;
        for (ll i=1;i<=n;i++)
        {
            if (!b[s[i]])
                cur.push_back(i);
        }
        ll sz=cur.size();
        ans=min(ans,cur[(sz+2)/2-1]);
        return;
    }
    Solve(cur,ind+1);
    Solve(cur+(1<<ind),ind+1);
}
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll p;
    cin >> n >> m >> k;
    for (ll i=1;i<=n;i++)
        cin >> s[i];
    for (ll i=2;i<=m;i++)
    {
        cin >> p;
        G[i].push_back(p);
        G[p].push_back(i);
    }
    if (n<=16 && m<=16)
    {
        Solve(0,0);
        cout << ans;
        return 0;
    }
    return 0;
}
