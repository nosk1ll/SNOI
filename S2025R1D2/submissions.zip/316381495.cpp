#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MAXN = 1e5+5;


int n, q;
int a[MAXN];
map<int,int> sg[4*MAXN];
void build(int l=1, int r=n, int k=1){
    if(l==r){
        sg[k][a[l]] = a[l];
        return;
    }
    int mid = (l+r)/2;
    build(l,mid,2*k);
    build(mid+1,r,2*k+1);
    for(auto p : sg[2*k]){
        sg[k][p.first] += p.second;
    }
    for(auto p : sg[2*k+1]){
        sg[k][p.first] += p.second;
    }
}
void sdahuf(int l=1, int r=n, int k=1){
    if(l==r) return;
    int mid = (l+r)/2;
    sdahuf(l,mid,2*k);
    sdahuf(mid+1,r,2*k+1);
    int t = 0;
    for(auto p : sg[k]){
        t += p.second;
        sg[k][p.first] = t;
    }
}
int read(int x, int y, int v, int l=1, int r=n, int k=1){
    if(y<l||x>r) return 0;
    if(x <= l && r <= y){
        auto it = sg[k].upper_bound(v);
        return (it==sg[k].begin() ? 0 : prev(it)->second);
    }
    int mid = (l+r)/2;
    return read(x,y,v,l,mid,2*k) + read(x,y,v,mid+1,r,2*k+1);
}

void solve(){
    cin >> n >> q;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
    }
    build();
    sdahuf();
    while(q--){
        int tt, x, y;
        cin >> tt >> x >> y;
        if(tt=1){
            int s = 1;
            int t = 0;
            while(true){
                t = read(x,y,s);
                if(t < s){
                    cout << s << '\n';
                    break;
                }
                s = t+1;
            }
        }
    }
}

int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int32_t qqq=1;
    //cin >> qqq;
    while(qqq--)solve();
    return 0;
}