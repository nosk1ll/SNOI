#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define ll long long
#define ldb long double
typedef pair<int, int> pl;
typedef vector<int> vi;
typedef vector<int> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
const int N=1e5+10;

int n, q, a[N];

struct SegTree {
	ll sum[4*N+100];
	int mn[4*N+100];
	void build(int tl=1, int tr=n, int v=1) {
		sum[v]=0;
		mn[v]=(int)(1e9);
		if (tl>=tr)
			return;
		int mid=(tl+tr)/2;
		build(tl, mid, 2*v);
		build(mid+1, tr, 2*v+1);
	}
	void upd(int x, int val, int v=1, int l=1, int r=n) {
    	if (l==r) {
        	sum[v]=mn[v]=val;
            return;
    	}
    	int mid=(l+r)/2;
    	if (x<=mid)
        	upd(x, val, 2*v, l, mid);
    	else
        	upd(x, val, 2*v+1, mid+1, r);
    	sum[v]=sum[2*v]+sum[2*v+1];
    	mn[v]=min(mn[2*v], mn[2*v+1]);
	}
	ll summ(int tl, int tr, int v=1, int l=1, int r=n) {
    	if (tl<=l&&r<=tr)
    		return sum[v];
    	if (r<tl||tr<l)
    		return 0;
    	int mid=(l+r)/2;
   	 	return summ(tl, tr, 2*v, l, mid)+summ(tl, tr, 2*v+1, mid+1, r);
	}
	int minn(int tl, int tr, int v=1, int l=1, int r=n) {
		if (tl<=l&&r<=tr)
			return mn[v];
    	if (r<tl||tr<l)
    		return (int)(1e9);
   	 	int mid=(l+r)/2;
    	return min(minn(tl, tr, 2*v, l, mid), minn(tl, tr, 2*v+1, mid + 1, r));
	}
} st[30];

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

    cin >> n >> q;
	 if (max(n, q)<=1000) {
		 for (int i=0; i<n; i++)
			 cin >> a[i];
		 while (q--) {
			 int tp; cin >> tp;
			 if (tp==1) {
				 vi v;
				 int l, r; cin >> l >> r;
				 l--, r--;
				 for (int i=l; i<=r; i++)
					 v.pb(a[i]);
				 ll res=1;
				 sort(all(v));
				 for (int i=0; i<sz(v)&&res>=v[i]; i++)
					 res+=v[i];
				 cout << res << nl;
			 }
			 else if (tp==2) {
				 int i, x; cin >> i >> x;
				 i--;
				 a[i]=x;
			 }
		 }
	 }
	 else {
		vi pws(30, 1);
		for (int bt=0; bt<30; bt++)
			st[bt].build();
		for (int bt=1; bt<30; bt++)
			pws[bt]=pws[bt-1]*2;
		 for (int i=1; i<=n; i++) {
			 cin >> a[i];
			 for (int bt=0; bt<30; bt++) {
				 if (a[i]>=pws[bt]&&a[i]<pws[bt+1]) {
					 st[bt].upd(i, a[i]);
					 break;
				 }
			 }
		 }
		 while (q--) {
			 int tp, l, r; cin >> tp >> l >> r;
			 if (tp==1) {
				 ll res=1;
				 for (int bt=0; bt<30; bt++)
					 if (res>=st[bt].minn(l, r))
						 res+=st[bt].summ(l, r);
				 cout << res << nl;
			 }
			 else {
				 //bitset opt?
			 }
		 }
    }
	return 0;
}
