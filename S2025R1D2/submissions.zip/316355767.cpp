/// 407!3 +/ \!<07!\*
#include <bits/stdc++.h>
#pragma GCC optimize ("O3")
#pragma GCC target ("sse4")

using namespace std;

using ll = long long;
using db = long double; // or double, if TL is tight
using str = string; // yay python!

using pi = pair<int,int>;
using pl = pair<ll,ll>;
using pd = pair<db,db>;

using vi = vector<int>;
using vb = vector<bool>;
using vl = vector<ll>;
using vd = vector<db>;
using vs = vector<str>;
using vpi = vector<pi>;
using vpl = vector<pl>;
using vpd = vector<pd>;
using vvi = vector<vi>;
using vvl = vector<vl>;
using vvpi = vector<vpi>;

template<class T> using pq = priority_queue<T>;
template<class T> using pqg = priority_queue<T, vector<T>, greater<T>>;

// pairs
#define mp make_pair
#define f first
#define s second

// vectors
#define sz(x) int((x).size())
#define bg(x) begin(x)
#define all(x) bg(x), end(x)
#define rall(x) x.rbegin(), x.rend()
#define sor(x) sort(all(x))
#define rsz resize
#define ins insert
#define ft front()
#define bk back()
#define pb push_back
#define eb emplace_back
#define pf push_front
#define er erase
#define ub upper_bound
#define lb lower_bound

// loops
#define FOR(i,a,b) for (ll i = (a); i < (b); ++i)
#define F0R(i,a) FOR(i,0,a)
#define ROF(i,a,b) for (ll i = (b)-1; i >= (a); --i)
#define R0F(i,a) ROF(i,0,a)
#define trav(a,x) for (auto& a: x)

const int MOD = 1e9+7; // 998244353;
const int MX = 2e5+5;
const ll INF = 1e18; // not too close to LLONG_MAX
const db PI = acos((db)-1);
const int dx[4] = {1,0,-1,0}, dy[4] = {0,1,0,-1}; // for every grid problem!
const char nl = '\n';

template<class T> bool ckmin(T& a, const T& b) { return b < a ? a = b, 1 : 0; }
template<class T> bool ckmax(T& a, const T& b) { return a < b ? a = b, 1 : 0; }

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}

template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ", "; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? ", " : ""), __print(i); cerr << "}";}
void _print() {cerr << "\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;

template<typename T>
using indexed_set =  tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define ook order_of_key
#define fbo find_by_order

void _input() {return;}
template <typename T, typename... V>
void _input(T &t, V&... v) {cin >> (t); if (sizeof...(v))  _input(v...);}
void __input(vi &v, const int n){F0R(i, n)cin >> v[i];}
void __input(vvi &v, const int n, const int m){F0R(i, n)F0R(j, m)cin>>v[i][j];}

ll binpow(ll a, ll b) {
    ll res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a;
        a = a * a;
        b >>= 1;
    }
    return res;
}

int ask(int i, int j){
    cout << "? " << i << " " << j << "\n";
    cout.flush();
    int x;
    cin >> x;
    return x;
}

void guess(vi sol){
    cout << "! ";
    FOR(i, 1, sz(sol))cout << sol[i] << " ";
    cout << nl;
    cout.flush();
}

void solve(){
    int n;
    cin >> n;
    int mx = 0, a = -1, b = -1;
    FOR(i, 2, n + 1){
        int x = ask(i, 1);
        if(x > mx){
            b = a;
            a = i;
            mx = x;
        }
        if(x < mx)b = i;
    }
    vi sol(n + 1);
    if(b == -1)b = n;
    int x = ask(1, b), y = ask(a, b);
    if(x == y){
        sol[1] = mx;
        sol[b] = y;
        FOR(i, 2, n + 1){
            if(i == b)continue;
            sol[i] = ask(1, i);
        }
    }
    else if(x > y){
        sol[1] = ask(1, 1);
        sol[b] = x;
        FOR(i, 2, n + 1){
            if(i == b)continue;
            sol[i] = ask(1, i);
        }
    }
    else{
        sol[1] = mx;
        sol[b] = y;
        FOR(i, 2, n + 1){
            if(i == b)continue;
            sol[i] = ask(a, i);
        }
    }
    guess(sol);
}


/*

*/

int main()
{
    ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int t; t = 1;while(t--){
        solve();
    }
    return 0;
}

