#include <bits/stdc++.h>
using namespace std;
int N, M, K, sol = INT_MAX;
int I[200096];
vector <int> D[2006];
vector <int> VG[2006];
int DP[2006];
inline void BRUTEDFS(bool *P, vector <int> &V, int node, int parent = 0)
{
  for(int x : D[node]) V.push_back(x);
  for(int x : VG[node]) if((x != parent) && !P[x]) BRUTEDFS(P, V, x, node);
  return;
}
inline void Brute()
{
  bool P[M + 1];
  vector <int> V;
  for(int i = 1; i < (1 << M); i++)
  {
    if(__builtin_popcount(i) > K) continue;
    for(int j = 0; j < M; j++) P[j + 1] = bool(i & (1 << j));
    V = D[0];
    if(!P[1]) BRUTEDFS(P, V, 1);
    sort(V.begin(), V.end());
    sol = min(V[V.size() >> 1], sol);
  }
  return;
}
inline void DFS(int X, int node, int parent = 0)
{
  for(int x : D[node])
  {
    if(x > X) DP[node]--;
    else DP[node]++;
  }
  for(int x : VG[node])
  {
    if(x == parent) continue;
    DFS(X, x, node);
    if(DP[x] > 0) DP[node] += DP[x];
  }
  return;
}
inline bool OK(int X)
{
  memset(DP, 0, sizeof(DP));
  for(int x : D[0])
  {
    if(x > X) DP[1]--;
    else DP[1]++;
  }
  DFS(X, 1);
  return DP[1] > 0;
}
inline void BS()
{
  int L = 1, R = N, S;
  while(L <= R)
  {
    S = (L + R) >> 1;
    if(!OK(S)) L = S + 1;
    else {R = S - 1; sol = S;}
  }
  return;
}
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> K;
  for(int i = 1; i <= N; i++)
  {
    cin >> I[i];
    D[I[i]].push_back(i);
  }
  for(int i = 2, j; i <= M; i++)
  {
    cin >> j;
    VG[i].push_back(j);
    VG[j].push_back(i);
  }
  if((N <= 20) && (M <= 20)) Brute();
  else BS();
  cout << sol << '\n';

  return 0;
}
