#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=1e5+50,M=6e5,lg=20;
const ll inf=1e18;
void Unique(vector<ll>&a){sort(a.begin(),a.end());int m=unique(a.begin(),a.end())-a.begin();a.resize(m);}
vector<ll>Merge(vector<ll>a,vector<ll>b){
	vector<ll>c;c.reserve(a.size()+b.size()+10);
	for(int i=0,j=0;i<=a.size();i++){
		while(j<b.size()&&(i==a.size()||a[i]>b[j])){
			if(c.empty()||c.back()!=b[j]) c.pb(b[j]);
			j++;
		}
		if(i!=a.size()&&(c.empty()||c.back()!=a[i])) c.pb(a[i]);
	}
	return c;
}
ll a[N];
struct BIT{
	int T[N+50];
	void Update(int i,int x){for(;i<=N;i+=i&-i)T[i]+=x;}
	int Get(int i){int x=0;for(;i>=1;i-=i&-i)x+=T[i];return x;}
	int Get(int l,int r){return Get(r)-Get(l-1);}
}bt[lg+1];
int main(){
    int n,q;scanf("%i%i",&n,&q);
    for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
    bool subtask1=false;if(n<=1000&&q<=1000)subtask1=true;
    //subtask1=false;
    if(subtask1){
		while(q--){
			int type,l,r;scanf("%i%i%i",&type,&l,&r);
			if(type==1){
				vector<int>b;
				for(int i=l;i<=r;i++) b.pb(a[i]);
				sort(b.begin(),b.end());
				ll sum=0,res=0;
				for(int i=0;i<b.size();i++){
					if(sum+1<b[i])break;
					sum+=b[i];
				}
				res=sum+1;
				printf("%lld\n",res);
			}
			else a[l]=r;
		}
		return 0;
    }
    for(int i=1;i<=n;i++) bt[a[i]].Update(i,1);
	while(q--){
		int type,l,r;scanf("%i%i%i",&type,&l,&r);
		if(type==1){
			vector<ll>nums(lg+1,0);
			for(int i=1;i<=lg;i++) nums[i]=bt[i].Get(l,r);
			ll sum=0,res=0;
			for(ll i=1;i<=lg;i++){
				if(sum+1<i)break;
				sum+=nums[i]*i;
			}
			res=sum+1;
			printf("%lld\n",res);
		}
		else{
			bt[a[l]].Update(l,-1);
			a[l]=r;
			bt[a[l]].Update(l,1);
		}
	}
    return 0;
}
