#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 1e6 + 10;

const int inf = 1e16;

mt19937 rng(NULL);

int random(int l, int r) {
  return l + rng() % (r - l + 1);
}

int Ask(int i, int j) {
  cout << "? " << i << " " << j << endl;
  int x;
  cin >> x;
  return x;
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  int n;
  cin >> n;
  vector<int> p(n + 1);
  for(int i = 1; i <= n; i++) p[i] = i;
  random_shuffle(p.begin() + 1, p.end());
  int j;
  for(int i = 2; i < n; i++) {
    int x = Ask(p[i - 1], p[i]);
    int y = Ask(p[i + 1], p[i]);
    if(x != y) {
      if(x > y) j = p[i - 1];
      else j = p[i + 1];
      break;
    }
  }
  vector<int> x(n + 1);
  for(int i = 1; i <= n; i++) x[i] = Ask(j, i);
  cout << "! ";
  for(int i = 1; i <= n; i++) cout << x[i] << " ";
  cout << endl;
}
