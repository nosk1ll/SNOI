#include <bits/stdc++.h>
using namespace std;
const int MAXN = 2e5+5;
int f(int i, int mid){
    return i<=mid ? 1 : -1;
}


int n, m, k;
int s[MAXN];
int p[MAXN];
vector<int> g[MAXN];
int dp[2005][2005];

void dfs(int x){
    int K = k;
    int v[K+1];
    for(int i = 0; i <= K; ++i){
        v[i] = -2e9;
        dp[x][i] = dp[x][0];
    }
    bool da = 0;
    for(int k : g[x]){
        dfs(k);
        if(v[1]==-2e9){
            for(int i = 0; i <= K; ++i){
                v[i] = dp[x][i] = dp[x][i] + dp[k][i];
            }
            continue;
        }
        for(int i = 0; i <= K; ++i) v[i] += dp[k][0];
        for(int s = 0; s <= K; ++s){
            for(int i = 0; i <= s; ++i){
                if(v[s] > dp[x][s-i]+dp[k][i]) break;
                v[s] = dp[x][s-i]+dp[k][i];
            }
        }
        for(int i = 0; i <= K; ++i){
            v[i] = dp[x][i] = v[i];
        }
    }
    for(int i = 1; i <= K; ++i) dp[x][i] = max(dp[x][i],0);
}

void solve(){
    cin >> n >> m >> k;
    for(int i = 1; i <= n; ++i){
        cin >> s[i];
    }
    for(int i = 2; i <= m; ++i){
        cin >> p[i];
        g[p[i]].push_back(i);
    }
    int l = 1, r = n, ans = n;
    while(l<=r){
        int mid = (l+r)/2;
        int br = 0;
        for(int i = 1; i <= m; ++i){
            for(int j = 0; j <= k; ++j){
                dp[i][j] = 0;
            }
        }
        for(int i = 1; i <= n; ++i){
            if(s[i]==0) br += f(i,mid);
            else dp[s[i]][0] += f(i,mid);
        }
        dfs(1);
        int t = 0;
        for(int i = 0; i <= k; ++i){
            t = max(t, dp[1][i]);
        }
        br += t;
        if(br > 0){
            ans = mid;
            r = mid-1;
        }
        else l = mid+1;
    }
    cout << ans << '\n';
}

int32_t main(){
    ios_base::sync_with_stdio(0); cin.tie(0);
    int32_t qqq=1;
    //cin >> qqq;
    while(qqq--)solve();
    return 0;
}