#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 1e5 + 10;

const int inf = 1e16;

const int K = 2010;

int s[N], n, m, k, vred[N], dp[K][K], dp2[N];
vector<int> g[N];

void dfs(int x, int p) {
  dp2[x] = vred[x];
  for(int j : g[x]) {
    if(j != p) {
      dfs(j, x);
      dp2[x] += dp2[j];
    }
  }
  dp2[x] = min(dp2[x], 0ll);
}

void Dfs(int x, int p) {
  vector<int> knap(k + 1, inf);
  bool ok = false;
  int s = 0;
  for(int j : g[x]) {
    if(j != p) {
      Dfs(j, x);
      s += dp[j][0];
    }
  }
  for(int j : g[x]) {
    if(j != p) {
      if(!ok) {
        for(int i = 0; i <= k; i++) knap[i] = dp[j][i];
        ok = true;
        continue;
      }
      //if(x == 5) cout << "sin " << j << " " << knap[0] << " " << knap[1] << endl;;
      vector<int> new_knap = knap;
      for(int x = 0; x <= k; x++) {
        int malo = inf;
        for(int i = 0; i <= x; i++) {
          malo = min(malo, dp[j][i] + knap[x - i]);
        }
        new_knap[x] = malo;
      }
      knap = new_knap;
      //if(x == 5) cout << "sin " << j << " " << knap[0] << " " << knap[1] << endl;;
    }
  }
  dp[x][0] = s + vred[x];
  if(g[x].size() == 0) {
    dp[x][1] = 0;
    return;
  }
  /*if(x == 5) {
    cout << "u dvojci knap[  " << " " << vred[x] << endl;
    for(int j = 0; j <= k; j++) cout << knap[j] << " ";
    cout << endl;
  }*/
  for(int i = 1; i <= k; i++) {
    dp[x][i] = min(0ll, knap[i] + vred[x]);
  }
}

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> n >> m >> k;
  for(int i = 1; i <= n; i++) cin >> s[i];
  for(int i = 2; i <= m; i++) {
    int x;
    cin >> x;
    g[x].push_back(i);
  }
  if(k == m) {
    int l = 0, r = n, ans = -1;
    while(l <= r) {
      int mid = l + r >> 1;
      int ost = 0;
      for(int i = 1; i <= m; i++) vred[i] = 0;
      for(int i = 1; i <= n; i++) {
        if(s[i] == 0) {
          if(i <= mid) ost--;
          else ost++;
        } else {
          if(i <= mid) vred[s[i]]--;
          else vred[s[i]]++;
        }
      }
      dfs(1, 0);
      if(dp2[1] < -ost) {
        ans = mid;
        r = mid - 1;
      } else {
        l = mid + 1;
      }
    }
    cout << ans;
    return 0;
  }
  int l = 0, r = n, ans = -1;
  while(l <= r) {
    int mid = l + r >> 1;
    int ost = 0;
    for(int i = 1; i <= m; i++) vred[i] = 0;
    for(int i = 1; i <= n; i++) {
      if(s[i] == 0) {
        if(i <= mid) ost--;
        else ost++;
      } else {
        if(i <= mid) vred[s[i]]--;
        else vred[s[i]]++;
      }
    }
    for(int i = 1; i <= m; i++) for(int j = 0; j <= k; j++) dp[i][j] = inf;
    /*for(int i = 1; i <= m; i++) cout << vred[i] << " ";
    cout << "Dbg" << endl;*/
    Dfs(1, 0);
    int res = inf;
    for(int i = 0; i <= k; i++) res = min(res, dp[1][i]);
    //cout << mid << " " << res << " " << ost << " " << (res < -ost) << " ovde" << endl;
    if(res < -ost) {
      ans = mid;
      r = mid - 1;
    } else {
     // cout << "neces ahahahah" << endl;
      l = mid + 1;
    }
  }
 /* cout << " dp" << endl;
  for(int i = 1; i <= m; i++) cout << vred[i] << " ";
  cout << endl;
  for(int i = 1; i <= m; i++) {
    for(int j = 0; j <= k; j++) cout << dp[i][j] << " ";
    cout << endl;
  }*/
//  cout << ost << endl;
  cout << ans;
}
