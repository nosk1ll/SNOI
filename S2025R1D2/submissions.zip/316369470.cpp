#include<bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);cerr.tie(0);

int main(){
ubrzaj

int iN;
if(!(cin>>iN))return 0;
vector<int> aiResp(iN+1);
for(int i=2;i<=iN;i++){
cout<<"?"<<i<<' '<<1<<endl;
cin>>aiResp[i];
}

int iTruth=2,iMax=aiResp[2];
for(int i=3;i<=iN;i++){
if(aiResp[i]>iMax){
iMax=aiResp[i];
iTruth=i;
}

}

vector<int> aiH(iN+1);
for(int j=1;j<=iN;j++){
cout<<"?"<<iTruth<<' '<<j<<endl;
cin>>aiH[j];
}
cout<<"!";
for(int i=1;i<=iN;i++)cout<<' '<<aiH[i];
cout<<endl;
return 0;
}
