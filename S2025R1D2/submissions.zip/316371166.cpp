#include <bits/stdc++.h>



void solve() {
  int n;
  std::cin >> n;
  std::function<int(int, int)> ask = [&] (int x, int y) {
    std::cout << "? " << x << " " << y << std::endl;
    int r;
    std::cin >> r;
    return r;
  };
  std::vector<int> ask1(n + 1);
  std::vector<int> ask2(n + 1);
  std::vector<int> ans(n + 1);
  for(int i = 2; i <= n; i++) {
    ask1[i] = ask(i, 1);
  }
  /**
  ili je 1 il index "istina"
  **/
  int some = - 1;
  int mx = - 1;
  for(int i = 2; i <= n; i++) {
    mx = std::max(mx, ask1[i]);
  }
  for(int i = 2; i <= n; i++) {
    if(mx == ask1[i]) {
      some = i;
    }
  }
  int ath = - 1;
  for(int i = 2; i <= n; i++) {
    if(i == some) {
      continue;
    }
    ath = i;
    break;
  }
  int A = ask(1, ath);
  int B = ask(some, ath);
  if(A >= B) {
    for(int i = 1; i <= n; i++) {
      if(i == ath) {
        ans[i] = A;
      }
      else {
        ans[i] = ask(1, i);
      }
    }
  }
  else {
    for(int i = 1; i <= n; i++) {
      if(i == ath) {
        ans[i] = B;
      }
      else {
        ans[i] = ask(some, i);
      }
    }
  }
  std::cout << "! ";
  for(int i = 1; i <= n; i++) {
    std::cout << ans[i] << " ";
  }
}


int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

