#include<bits/stdc++.h>
#define ll long long
#define MAXN 103
using namespace std;
ll a[MAXN], h[MAXN];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cout<<"? "<<i<<" 1\n"; cin>>a[i];
    }
    bool x=false;
    int good;
    for(int i=2;i<=n;i++) if(a[i]==a[1])
    {
        x=true;
        good=1;
        h[1]=a[1];
        for(int i=2;i<=n;i++)
        {
            cout<<"? 1 "<<i<<"\n"; cin>>h[i];
        }
        break;
    }
    if(!x)
    {
        int g=max_element(a+2,a+n+1)-a;
        int hg,h1;
        if(g==2)
        {
            cout<<"? "<<g<<" 3\n"; cin>>hg;
            cout<<"? "<<1<<" 3\n"; cin>>h1;
            if(hg<h1)
            {
                h[1]=a[1];
                h[3]=h1;
                for(int i=2;i<=n;i++) if(i!=3) 
                {
                    cout<<"? 1 "<<i<<"\n"; cin>>h[i];
                }
            }
            else
            {
                h[1]=a[g];
                h[3]=hg;
                for(int i=2;i<=n;i++) if(i!=3) 
                {
                    cout<<"? "<<g<<" "<<i<<"\n"; cin>>h[i];
                }
            }
        }
        else
        {
            cout<<"? "<<g<<" 2\n"; cin>>hg;
            cout<<"? "<<1<<" 2\n"; cin>>h1;
            if(hg<h1)
            {
                h[1]=a[1];
                h[2]=h1;
                for(int i=3;i<=n;i++)
                {
                    cout<<"? 1 "<<i<<"\n"; cin>>h[i];
                }
            }
            else
            {
                h[1]=a[g];
                h[2]=hg;
                for(int i=3;i<=n;i++)
                {
                    cout<<"? "<<g<<" "<<i<<"\n"; cin>>h[i];
                }
            }
        }
    }
    cout<<"!";
    for(int i=1;i<=n;i++) cout<<" "<<h[i];
    cout<<"\n";
    return 0;
}