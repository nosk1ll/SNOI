#include<bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define int long long
#define MAXN (int)2e5+5
#define MAXM 2005
using namespace std;
using namespace __gnu_pbds;
typedef tree<int, null_type, less<int>, rb_tree_tag,
             tree_order_statistics_node_update>
    ordered_set;
int s[MAXN],p[MAXN];
vector<int>g[MAXM];
vector<int>v;
ordered_set s2;
int calc(){
	int x=ceil((double)(s2.size())/2.0);
	return *(s2.find_by_order(x));
}
void solve() {
	s2.insert(0);
	int n,m,k;cin>>n>>m>>k;
	for(int i=0;i<n;i++){
		s2.insert(i+1);
		cin>>s[i];
	}for(int j=2;j<=m;j++){
		cin>>p[j];
		g[j].push_back(p[j]);
		g[p[j]].push_back(j);
	}
	p[1]=0;
	int rez=calc();
	for(int i=m;i>=1;i--){
		if(s[i]){
			s2.erase(s2.find(i));
		}
		rez=min(rez,calc());
	}
	cout<<rez<<'\n';
}
int32_t main() {
	ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int32_t T=1;//cin>>T;
	while(T--) {
		solve();
	}
	return 0;
}