/// 407!3 +/ \!<07!\*
#include <bits/stdc++.h>
#pragma GCC optimize ("O3")
#pragma GCC target ("sse4")

using namespace std;

using ll = long long;
using db = long double; // or double, if TL is tight
using str = string; // yay python!

using pi = pair<int,int>;
using pl = pair<ll,ll>;
using pd = pair<db,db>;

using vi = vector<int>;
using vb = vector<bool>;
using vl = vector<ll>;
using vd = vector<db>;
using vs = vector<str>;
using vpi = vector<pi>;
using vpl = vector<pl>;
using vpd = vector<pd>;
using vvi = vector<vi>;
using vvl = vector<vl>;
using vvpi = vector<vpi>;

template<class T> using pq = priority_queue<T>;
template<class T> using pqg = priority_queue<T, vector<T>, greater<T>>;

// pairs
#define mp make_pair
#define f first
#define s second

// vectors
#define sz(x) int((x).size())
#define bg(x) begin(x)
#define all(x) bg(x), end(x)
#define rall(x) x.rbegin(), x.rend()
#define sor(x) sort(all(x))
#define rsz resize
#define ins insert
#define ft front()
#define bk back()
#define pb push_back
#define eb emplace_back
#define pf push_front
#define er erase
#define ub upper_bound
#define lb lower_bound

// loops
#define FOR(i,a,b) for (ll i = (a); i < (b); ++i)
#define F0R(i,a) FOR(i,0,a)
#define ROF(i,a,b) for (ll i = (b)-1; i >= (a); --i)
#define R0F(i,a) ROF(i,0,a)
#define trav(a,x) for (auto& a: x)

const int MOD = 1e9+7; // 998244353;
const int N = 2e5+5;
const int M = 2e3+5;
const ll INF = 1e18; // not too close to LLONG_MAX
const db PI = acos((db)-1);
const int dx[4] = {1,0,-1,0}, dy[4] = {0,1,0,-1}; // for every grid problem!
const char nl = '\n';

template<class T> bool ckmin(T& a, const T& b) { return b < a ? a = b, 1 : 0; }
template<class T> bool ckmax(T& a, const T& b) { return a < b ? a = b, 1 : 0; }

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}

template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ", "; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? ", " : ""), __print(i); cerr << "}\n";}
void _print() {cerr << "\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;

template<typename T>
using indexed_set =  tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define ook order_of_key
#define fbo find_by_order

void _input() {return;}
template <typename T, typename... V>
void _input(T &t, V&... v) {cin >> (t); if (sizeof...(v))  _input(v...);}
void __input(vi &v, const int n){F0R(i, n)cin >> v[i];}
void __input(vvi &v, const int n, const int m){F0R(i, n)F0R(j, m)cin>>v[i][j];}

ll binpow(ll a, ll b) {
    ll res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a;
        a = a * a;
        b >>= 1;
    }
    return res;
}

int n, m, k;
vi s(N), p(M);
vvi g(M);
vvi dp(M, vi(M, -1e9)), best(M, vi(M, -1e9));
vi dp0(M), val(M);

int dfs(int u, int p){
    dp[u][0] = 0;
    int sz = 1;
    trav(v, g[u]){
        if(v == p)continue;
        int sz_c = dfs(v, u);
        F0R(i, sz_c + 1)best[v][i] = dp[v][i];
        best[v][1] = max(best[v][1], dp0[v]);

        vi ndp(M, -1e9);
        F0R(i, sz + 1){
            if(dp[u][i] == -1e9)continue;
            F0R(j, sz_c + 1){
                if(best[v][j] == -1e9)continue;
                ndp[i + j] = max(ndp[i + j], best[v][j] + dp[u][i]);
            }
        }
        dp[u].swap(ndp);
        sz += sz_c;
    }
    return sz;
}

bool bin(int x){
    int del = n - 2 * x + 1;
    if(del <= 0)return 1;
    F0R(i, M){
        F0R(j, M){
            dp[i][j] = -1e9;
            best[i][j] = -1e9;
        }
        val[i] = dp0[i] = 0;
    }
    FOR(i, 1, n + 1){
        if(s[i] == 0)continue;
        if(i <= x)val[s[i]]--;
        else val[s[i]]++;
    }
    ROF(i, 1, M){
        dp0[i] += val[i];
        dp0[p[i]] += dp0[i];
    }
    int sz = dfs(1, 0);
    int ans = dp0[1];
    F0R(i, k + 1){
        ans = max(ans, dp[1][i]);
    }
    //_print(val, dp0);
    if(ans >= del)return 1;
    else return 0;
}

void solve(){
    cin >> n >> m >> k;
    FOR(i, 1, n + 1)cin >> s[i];
    FOR(i, 2, m + 1){
        cin >> p[i];
        g[p[i]].pb(i);
    }
    int l = 1, r = n, sol = n;
    while(l <= r){
        int mid = (l + r) / 2;
        bool x = bin(mid);
        if(x){
            r = mid - 1;
            sol = mid;
        }
        else l = mid + 1;
    }
    cout << sol << nl;
    /*FOR(i, 1, n + 1){
        bool x = bin(i);
        if(x)cout << 1;
        else cout << 0;
    }*/
}


/*

*/

int main()
{
    ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int t; t = 1;while(t--){
        solve();
    }
    return 0;
}

