#include <bits/stdc++.h>

using namespace std;

int ask(int i, int j) {
    cout << "? " << i << ' ' << j << endl;
    int r;
    cin >> r;
    return r;
}
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    int p = 1, mx = ask(1, n);
    for (int i = 2; i < n; ++i) {
        int x = ask(i, n);
        if (x > mx) mx = x, p = i;
    }
    int j = (p == 1 ? 2 : 1);
    int u = ask(p, j), v = ask(n, j);
    if (u > v) {
        int a[n+1];
        for (int i = 1; i <= n; ++i)    a[i] = (i == j ? u : ask(p, i));
        cout << "! ";
        for (int i = 1; i <= n; ++i)    cout << a[i] << ' ';
        cout << endl;
    }
    else {
        int a[n+1];
        for (int i = 1; i <= n; ++i)    a[i] = (i == j ? v : ask(n, i));
        cout << "! ";
        for (int i = 1; i <= n; ++i)    cout << a[i] << ' ';
        cout << endl;
    }
}