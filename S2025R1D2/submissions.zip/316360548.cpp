#include <bits/stdc++.h>

using namespace std;
using ll = long long;
#define pb push_back

const int N = 2003;
vector<ll> dp[N];
vector<int> g[N];
vector<ll> dq(int l, int r, vector<int> &id) {
    if (l == r) return dp[id[l]];
    int m = (l + r)/2;
    vector<ll> a = dq(l, m, id), b = dq(m+1, r, id);
    vector<ll> c(a.size(), -1e9);
    // for (int i = 0; i < a.size(); ++i) {
    //     for (int j = 0; j < a.size() - i; ++j)  c[i+j] = max(c[i+j], a[i] + b[j]);
    // }
    int i = 0, j = 0;
    while (i+j < a.size()) {
        c[i+j] = max(c[i+j], a[i] + b[j]);
        if (a[i+1] - a[i] > b[j+1] - b[j])
            i++;
        else
            j++;
    }
    return c;
}
void dfs(int s) {
    for (auto u : g[s]) dfs(u);
    if (!g[s].empty()) {
        auto t = dq(0, g[s].size()-1, g[s]);
        for (int i = 1; i < dp[s].size(); ++i)  dp[s][i] = t[i] + dp[s][0];
        dp[s][0] += t[0];
    }
    dp[s][1] = max(dp[s][1], 0LL);
    // for (int i = 1; i < dp[s].size(); ++i)  dp[i] = max(dp[i], dp[i-1]);
}
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, m, k;
    cin >> n >> m >> k;
    int s[n+1];
    for (int i = 1; i <= n; ++i)    cin >> s[i];
    for (int i = 2; i <= m; ++i) {
        int p;
        cin >> p;
        g[p].pb(i);
    }
    int l = 1, r = n, ans = n;
    for (int i = 1; i <= m; ++i)    dp[i].resize(k+1);
    while (l <= r) {
        int mid = (l + r)/2, c = 0;
        for (int i = 1; i <= m; ++i)    fill(dp[i].begin(), dp[i].end(), -1e9);
        for (int i = 1; i <= m; ++i)    dp[i][0] = 0;
        for (int i = 1; i <= n; ++i) {
            if (!s[i])  
                c += (i > mid ? -1 : 1);
            else
                dp[s[i]][0] += (i > mid ? -1 : 1);
        }
        dfs(1);
        if (*max_element(dp[1].begin(), dp[1].end()) + c > 0)
            r = mid-1, ans = mid;
        else
            l = mid+1;
    }
    cout << ans << '\n';
}