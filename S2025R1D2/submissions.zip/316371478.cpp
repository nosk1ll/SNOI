#include <bits/stdc++.h>

using namespace std;

// Macros
#define f first
#define s second
#define ll long long
#define db double
#define vi vector<int>
#define vl vector<ll>
#define vp vector<pair<ll, ll>>
#define vvi vector<vi>
#define mi map<int, int>
#define beg begin
#define nl "\n"
#define yes "YES\n"
#define no "NO\n"

// Loops
#define FOR(i, a, b) for(int i = a; i < b; i++)
#define ROF(i, a, b) for(int i = a - 1; a >= b; i--)

int ask(int i, int j) {
    cout << "? " << i + 1 << " " << j + 1 << nl;
    cout.flush();
    int h;
    cin >> h;
    return h;
}

void solve(){
    int n;
    cin >> n;
    vvi a(n, vi(n));
    int k = -1, i1 = -1;
    FOR(i, 0, n){
        a[i][n - 1] = ask(i, n - 1);
        if(a[i][n - 1] >= k && i != n - 1){
            k = a[i][n - 1];
            i1 = i;
        }
    }
    if(a[i1][n - 1] == a[n - 1][n - 1]){
        FOR(i, 0, n - 1){
            a[i1][i] = ask(i1, i);
        }
        cout << "! ";
        FOR(i, 0, n){
            cout << a[i1][i] << " ";
        }
    }
    else{
        if(i1 != 0){
            a[i1][0] = ask(i1, 0);
            a[n - 1][0] = ask(n - 1, 0);
            if(a[i1][0] >= a[n - 1][0]){
                FOR(i, 1, n - 1){
                    a[i1][i] = ask(i1, i);
                }
                cout << "! ";
                FOR(i, 0, n){
                    cout << a[i1][i] << " ";
                }
            }
            else if(a[n - 1][0] > a[i1][0]){
                FOR(i, 1, n){
                    a[n - 1][i] = ask(n - 1, i);
                }
                cout << "! ";
                FOR(i, 0, n){
                    cout << a[n - 1][i] << " ";
                }
            }
        }
        else if(i1 != 1){
            a[i1][1] = ask(i1, 1);
            a[n - 1][1] = ask(n - 1, 1);
            if(a[i1][1] >= a[n - 1][1]){
                FOR(i, 0, n - 1){
                    if(i == 1) continue;
                    a[i1][i] = ask(i1, i);
                }
                cout << "! ";
                FOR(i, 0, n){
                    cout << a[i1][i] << " ";
                }
            }
            else if(a[n - 1][1] > a[i1][1]){
                FOR(i, 0, n){
                    if(i == 1) continue;
                    a[n - 1][i] = ask(n - 1, i);
                }
                cout << "! ";
                FOR(i, 0, n){
                    cout << a[n - 1][i] << " ";
                }
            }
        }
    }
}

int main(){
    cin.tie(0);cout.tie(0);ios_base::sync_with_stdio(false);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
