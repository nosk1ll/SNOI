#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define PI acos(-1)
#define LSB(i) ((i) & -(i))
#define ll long long
#define pb push_back
#define mp make_pair
#define mt make_tuple
#define fi first
#define sc second
#define th third
#define fo fourth
#define pii pair<int,int>
#define pll pair<ll,ll>
#define ldb double
#define INF 1e15
#define MOD 1000000007
#define endl "\n"

#define all(data)       data.begin(),data.end()
#define TYPEMAX(type)   std::numeric_limits<type>::max()
#define TYPEMIN(type)   std::numeric_limits<type>::min()
#define MAXN 200007
ll a[MAXN];
int main()
{
    ios::sync_with_stdio(false); cin.tie(0);
    ll n,q; cin>>n>>q;
    for(int i=1;i<=n;i++) cin>>a[i];
    if(n<=1000 && q<=1000)
    {
        while(q--)
        {
            ll t,l,r; cin>>t>>l>>r;
            if(t==1)
            {
                vector<ll> v;
                for(int i=l;i<=r;i++) v.pb(a[i]);
                sort(all(v));
                ll rez=1;
                for(int i=0;i<v.size() && rez>=v[i];i++) rez+=v[i];
                cout<<rez<<endl;
            }
            else a[l]=r;
        }
    }
    return 0;
}
