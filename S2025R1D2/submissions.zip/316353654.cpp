#include <bits/stdc++.h>



void solve() {
  int n, q;
  std::cin >> n >> q;
  std::vector<int> a(n + 1);
  for(int i = 1; i <= n; i++) {
    std::cin >> a[i];
  }
  while(q--) {
    int type;
    std::cin >> type;
    if(type == 1) {
      int l, r;
      std::cin >> l >> r;
      std::vector<int> b = a;
      sort(b.begin() + l, b.begin() + r + 1);
      int ans = 1;
      for(int i = l; i <= r; i++) {
        if(b[i] > ans) {
          break;
        }
        ans += b[i];
      }
      std::cout << ans << "\n";
    }
    else {
      int i, x;
      std::cin >> i >> x;
      a[i] = x;
    }
  }
}


int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

