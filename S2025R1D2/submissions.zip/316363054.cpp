#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 1e5 + 10;

const int inf = 1e16;

int s[N], n, m, k;
vector<int> g[N];

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> n >> m >> k;
  for(int i = 1; i <= n; i++) cin >> s[i];
  for(int i = 2; i <= m; i++) {
    int x;
    cin >> x;
    g[x].push_back(i);
  }
  if(k == m) {
    vector<int> all;
    int xx = 1;
    for(int i = 1; i <= n; i++) if(s[i] == 0) xx = i;
    for(int i = 1; i <= xx; i++) all.push_back(i);
    int idx = ((int)all.size() + 1) / 2;
    cout << all[idx - 1];
  }
}
