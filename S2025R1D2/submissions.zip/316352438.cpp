#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 105;
ll n;
ll ask(ll x,ll y) {
	ll ans = 0;
	cout<<"? "<<x<< " "<<y<<endl;
	cin >> ans;
	return ans;
}
ll a[maxn];
int main(){
	cin >> n;
	ll c = 1;
	for(ll i = 1;i<=n;i++) a[i] = ask(i,i);
	for(ll i = 2;i<=n;i++) {
		ll x = ask(c,i);
		if(x>a[c]) c = i;
	}
	for(ll i = 1;i<=n;i++) a[i] = ask(c,i);
	cout<<"! ";
	for(ll i = 1;i<=n;i++) cout<<a[i]<< " ";
	cout<<endl;
	return (0-0);
}
