#include<bits/stdc++.h>
using namespace std;
using ll=long long;

const ll N=1e5+2;
ll a[N],n,q;
vector<ll>st1[4*N],st[4*N];
     
ll get(ll k,vector<ll>&fw){
    ll s=0;++k;
    while(k>0){
        s+=fw[k];
        k-=k&-k;
    }
    return s;
}
 
void add(ll k,ll x,vector<ll>&fw){
    ++k;
    while(k<fw.size()){
        fw[k]+=x;
        k+=k&-k;
    }
}

void bd1(ll i=1,ll l=1,ll r=n){
    if(l==r){st1[i]={a[l]};return;}
    ll md=(l+r)/2;
    bd1(i*2,l,md);
    bd1(i*2+1,md+1,r);
    st1[i].resize(st1[i*2].size()+st1[i*2+1].size());
    merge(st1[i*2].begin(),st1[i*2].end(),st1[i*2+1].begin(),st1[i*2+1].end(),st1[i].begin());
}

void bd2(ll i=1,ll l=1,ll r=n){
    st[i].resize(st1[i].size()+1,0);
    for(ll j=0;j<st1[i].size();++j)
        add(j,st1[i][j],st[i]);
    if(l==r)return;
    ll md=(l+r)/2;
    bd2(i*2,l,md);
    bd2(i*2+1,md+1,r);
}

ll qry(ll l,ll r,ll x,ll i=1,ll tl=1,ll tr=n){
    if(tl>=l&&tr<=r){
        ll it=upper_bound(st1[i].begin(),st1[i].end(),x)-st1[i].begin()-1;
        return get(it,st[i]);
    }
    ll md=(tl+tr)/2,ret=0;
    if(md>=l)ret+=qry(l,r,x,i*2,tl,md);
    if(md+1<=r)ret+=qry(l,r,x,i*2+1,md+1,tr);
    return ret;
}

void upd(ll id,ll sa,ll na,ll i=1,ll tl=1,ll tr=n){
    ll it=lower_bound(st1[i].begin(),st1[i].end(),sa)-st1[i].begin();
    st1[i][it]+=na-sa;
    add(it,na-sa,st[i]);
    if(tl==tr)return;
    ll md=(tl+tr)/2;
    if(id<=md)upd(id,sa,na,i*2,tl,md);
    else upd(id,sa,na,i*2+1,md+1,tr);
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    //nema promene (2)
    
    cin>>n>>q;
    for(int i=1;i<=n;++i)
        cin>>a[i];
    
    bd1();
    bd2();

    while(q--){
        ll tp;cin>>tp;
        if(tp==2){
            ll i,x;cin>>i>>x;
            upd(i,a[i],x);
            a[i]=x;
        }else{
            ll l,r;cin>>l>>r;
            ll cur=0;
            while(1){
                ll x1=qry(l,r,cur+1);
                if(x1<=cur)break;
                cur=x1;
            }
            cout<<cur+1<<'\n';
        }
    }
    
}