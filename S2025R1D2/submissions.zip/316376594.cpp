#include <bits/stdc++.h>

using namespace std;
using ll = long long;
#define pb push_back


const int N = 1e7 + 5, M = 1e5 + 5;
int lc[N], rc[N];
int R[N], nn, C = 0;
ll S[N];
int build(int l = 1, int r = nn) {
    if (l == r) return ++C;
    int m = (l + r)/2, nd = ++C;
    lc[nd] = build(l, m);
    rc[nd] = build(m+1, r);
    return nd;
}
int build2(int nd, int p, int x, int l2 = 1, int r2 = nn) {
    if (l2 == r2) {
        int ND = ++C;
        S[ND] = S[nd] + x;
        return ND;
    }
    int m2 = (l2 + r2)/2, ND = ++C;
    lc[ND] = lc[nd], rc[ND] = rc[nd];
    if (p <= m2)    
        lc[ND] = build2(lc[nd], p, x, l2, m2);
    else
        rc[ND] = build2(rc[nd], p, x, m2+1, r2);
    S[ND] = S[lc[ND]] + S[rc[ND]];
    return ND;
}
ll sum(int ndl, int ndr, int l, int r, int l2 = 1, int r2 = nn) {
    if (l <= l2 && r2 <= r) return S[ndr] - S[ndl];
    int m2 = (l2 + r2)/2;
    ll s = 0;
    if (l <= m2)    s += sum(lc[ndl], lc[ndr], l, r, l2, m2);
    if (m2+1 <= r)  s += sum(rc[ndl], rc[ndr], l, r, m2+1, r2);
    return s;
}

struct segtree {
    int st[M];
    void upd(int i, int x) {
        for (; i < N; i |= (i+1))   st[i] += x;    
    }
    int sum(int i) {
        int S = 0;
        for (; i >= 0; i = (i & (i+1)) - 1) S += st[i];
        return S;
    }
    int sum(int l, int r) {
        return sum(r) - (l ? sum(l-1) : 0);
    }
} b[21];
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, q;
    cin >> n >> q; nn = n;
    ll a[n+1];
    vector<ll> v;
    bool sigma = 1;
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
        sigma &= a[i] <= 20;
        v.pb(a[i]);
    }
    vector<array<int, 3>> qu(q);
    for (int i = 0; i < q; ++i) {
        cin >> qu[i][0] >> qu[i][1] >> qu[i][2];
        sigma &= qu[i][0] == 2 || qu[i][2] <= 20;
    }
    // if (sigma) {
    //     for (int i = 1; i <= n; ++i)    b[a[i]].upd(i, 1);
    //     for (int i = 0; i < q; ++i) {
    //         if (qu[i][0] == 1) {
    //             int l = qu[i][1], r = qu[i][2];
    //             int R = 1, S = 1;
    //             // cout << "uaaaa" << endl;
    //             // cout << b[1].sum(3, 4) << '\n';
    //             while (R <= min(S, 20)) {
    //                 S += b[R].sum(l, r) * R;
    //                 ++R;
    //             }
    //             // cout << "uaaaa" << endl;
    //             cout << S << '\n';
    //         }
    //         else {
    //             int p = qu[i][1], x = qu[i][2];
    //             b[a[p]].upd(p, -1);
    //             b[x].upd(p, 1);
    //             a[p] = x;
    //         }
    //     }
    //     return 0;
    // }
    sort(v.begin(), v.end());
    v.erase(unique(v.begin(), v.end()), v.end());
    auto f = [&](ll x) {
        return lower_bound(v.begin(), v.end(), x) - v.begin() + 1;
    };
    R[0] = build();
    for (int i = 1; i <= n; ++i)    R[i] = build2(R[i-1], (int)f(a[i]), (int)a[i]);
    for (int i = 0; i < q; ++i) {
        int l, r;
        // cin >> l >> r; 
        l = qu[i][1], r = qu[i][2];
        ll s = 1;
        if (f(s+1) != 1) {
            while (1) {
                ll s2 = s;
                // cout << s << ' ' << f(s+1)-1 << endl;
                s = sum(R[l-1], R[r], 1, (int)f(s+1)-1)+1;
                if (s == s2)    break;
            }
        }
        cout << s << '\n';
    }
}