#include <bits/stdc++.h>

void solve() {
  int n, m, k;
  std::cin >> n >> m >> k;
  std::vector<int> s(n + 1);
  for(int i = 1; i <= n; i++) {
    std::cin >> s[i];
  }
  std::vector<int> p(m + 1);
  for(int i = 2; i <= m; i++) {
    std::cin >> p[i];
  }
  if(m == k) {
    int siz = 1;
    std::vector<int> t(n + 1, - 1);
    for(int i = 1; i <= n; i++) {
      if(s[i]) {
        t[siz++] = i;
      }
    }
    siz--;
    std::cout << t[siz / 2 + 1];
    return;
  }
}

/**


izbrisi k podstabala tako da medijana bude minimalna

**/

int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

