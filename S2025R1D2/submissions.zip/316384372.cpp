#include <bits/stdc++.h>
#define endl '\n'
#define int long long

using namespace std;

const long long longlongmax=9223372036854775807;
const int modul=998244353;
const long long mod = 1e9 + 7;


mt19937 mt(chrono::steady_clock::now().time_since_epoch().count());

const int N=200009,M=2009,INF=2000000000;
vector<int> graf[N],val[N];
int dp[M][M],pomocni[M][M];
int n,m,k;
void reset(){
    for(int i=0; i<M; i++) for(int j=0; j<M; j++) dp[i][j]=pomocni[i][j]=0;
}
void dfs(int node,int med){
    for(auto&x:graf[node])
        dfs(x,med);
    int cnt=0;
    for(auto&x:val[node]){///!!!
        if(x<=med) cnt++;
        else cnt--;
    }
    if(graf[node].empty()){
        dp[node][0]=cnt;
        return;
    }
    for(int i=0; i<=k; i++)
        dp[node][i]=dp[graf[node][0]][i];
    for(auto&x:graf[node]){
        if(x==graf[node][0]) continue;
        for(int i=0; i<=k; i++)
            pomocni[node][i]=dp[node][i];
        for(int i=0; i<=k; i++){
            for(int j=0; j+i<=k; j++){
                pomocni[node][i+j]=max(pomocni[node][i+j],dp[node][i]+dp[x][j]);
            }
        }
        for(int i=0; i<=k; i++)
            dp[node][i]=pomocni[node][i];
    }

    /*pair<int,int> maximumi[k+1];
    for(int i=0; i<=k; i++) maximumi[i].first=maximumi[i].second=-INF;
    for(auto&x:graf[node]){
        for(int i=0; i<=k; i++){
            if(maximumi[i].second>dp[x][i]) continue;
            if(maximumi[i].first<dp[x][i]){
                maximumi[i].second=maximumi[i].first;
                maximumi[i].first=dp[x][i];
                continue;
            }
            maximumi[i].second=dp[x][i];
        }
    }
    for(int i=0; i<=k; i++){
        for(int j=0; i+j<=k; j++){
            if(i==j){
                dp[node][i]=maximumi[i].first+maximumi[i].second;
                continue;
            }
            dp[node][i]=maximumi[i].first+maximumi[j].first;
        }
    }*/
    for(int i=0; i<=k; i++) dp[node][i]+=cnt;
    for(int i=1; i<=k; i++) dp[node][i]=max(dp[node][i],NULL);
    return;
}


int DFSSS(int node,int med){
    int rez=0;
    for(auto&x:graf[node]){
        rez+=DFSSS(x,med);
    }
    int cnt=0;
    for(auto x:val[node]){
        if(x<=med) cnt++;
        else cnt--;
    }
    rez+=cnt;
    rez=max(rez,NULL);
    return rez;
}



signed main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    //freopen("seating.in","r",stdin);
    //freopen("seating.out","w",stdout);

    cin >> n >> m >> k;
    for(int i=1; i<=n; i++){
        int a;cin >> a;val[a].push_back(i);
    }
    for(int i=2; i<=m; i++){
        int a;cin >> a;graf[a].push_back(i);
    }
    if(k==m){
        int l=0,d=N,rez;
        while(l<=d){
            int med=l+d>>1;
            int cnt=0;
            for(auto& x:val[0]){
                if(x<=med) cnt++;
                else cnt--;
            }

            if(DFSSS(1,med)+cnt>0){
                rez=med;
                d=med-1;
            }
            else
                l=med+1;

        }
        cout << rez;
        return 0;
    }
    int l=0,d=N,rez;
    while(l<=d){
        int med=l+d>>1;
        reset();
        dfs(1,med);
        int cnt=0;
        for(auto& x:val[0]){
            if(x<=med) cnt++;
            else cnt--;
        }
        int maxi_poeni=0;
        for(int i=0; i<=k; i++){
            maxi_poeni=max(maxi_poeni,dp[1][i]);
        }

        if(maxi_poeni+cnt>0){
            rez=med;
            d=med-1;
        }
        else
            l=med+1;
        /*if(med==1){
            for(int i=1; i<=m; i++){
                cout << "node " << i << ": ";
                for(int j=0; j<=k; j++)
                    cout << dp[i][j] << " ";
                cout << endl;
            }
        }*/
    }
    cout << rez;



    return 0;
}
/*
    abcde
    01234
    04321 --> 12340
              0   1
    011
    110

1
3 1
1 2 3
3 5

*/
