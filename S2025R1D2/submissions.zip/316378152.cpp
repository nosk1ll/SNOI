#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=2e5+50,M=2010,inf=1e9;
vector<int>E[N],Vals[N];
int n,m,K;
int s[N],par[N],in[N],out[N],tajm;
int num[N];
void DFSsetup(int u){
	in[u]=++tajm;
	for(auto i:E[u]) DFSsetup(i);
	out[u]=tajm;
}
void DFS1(int u,int mid){
	for(auto i:Vals[u]){
		if(i>mid) num[u]++;
		else if(i<=mid) num[u]--;
	}
	for(auto i:E[u]) DFS1(i,mid),num[u]+=num[i];
}
bool Podstablo(int u,int v){
	if(in[u]<=in[v]&&in[v]<=out[u]) return true;
	if(in[v]<=in[u]&&in[u]<=out[v]) return true;
	return false;
}
int dp[M+50][M+50];
void DFS(int u){
	for(auto i:E[u]) DFS(i);
	for(int k=1;k<=K;k++) dp[u][k]=max(0,num[u]);
	int m=E[u].size();
	int dp1[m+1][M+10];memset(dp1,0,sizeof(dp1));
	for(int i=1;i<=m;i++){
		int v=E[u][i-1];
		for(int k=0;k<=K;k++){
			for(int k1=0;k1<=k;k1++){
				dp1[i][k]=max({dp1[i][k],dp1[i-1][k-k1]+dp[v][k1]});
			}
		}
	}
	for(int k=0;k<=K;k++) dp[u][k]=max(dp[u][k],dp1[m][k]);
}
bool Check(int mid){
	for(int i=1;i<=m;i++) num[i]=0;
	DFS1(1,mid);
	//for(int i=1;i<=m;i++) printf("%i ",num[i]);printf("\n");
	/*vector<pair<int,int>>nesto;
	for(int i=1;i<=m;i++) nesto.pb({num[i],i});
	sort(nesto.begin(),nesto.end());reverse(nesto.begin(),nesto.end());
	int k=K,S=0;
	for(int i=1;i<=n;i++){if(i<=mid)S--;else if(i>mid) S++;}
	vector<int>vtx;
	for(auto [x,u]:nesto){
		if(k<=0||x<=0) break;
		bool moze=true;
		for(auto v:vtx) if(Podstablo(u,v)) moze=false;
		if(!moze) continue;
		k--;
		S-=x;
		vtx.pb(u);
	}*/
	//for(auto i:vtx) printf("%i ",i);printf("\n");
	//printf("%i\n",S);
	for(int i=1;i<=m;i++) for(int k=0;k<=K;k++) dp[i][k]=0;
	DFS(1);
	//for(int i=1;i<=m;i++) printf("%i: %i\n",i,dp[i][K]);
	int S=0;for(int i=1;i<=n;i++){if(i<=mid)S--;else if(i>mid) S++;}
	S-=dp[1][K];
	if(S<0) return true;
	return false;
}

int T[N+50];
void Update(int i,int x){for(;i<=N;i+=i&-i)T[i]+=x;}
int Get(int i){int x=0;for(;i>=1;i-=i&-i)x+=T[i];return x;}
int Get(int l,int r){return Get(r)-Get(l-1);}

int Dp[M+50];
void DFS2(int u){
	int x=0;
	for(auto i:E[u]) DFS2(i),x+=Dp[i];
	Dp[u]=max({0,num[u],x});
}

bool Check1(int mid){
	for(int i=1;i<=m;i++) num[i]=0;
	DFS1(1,mid);
	for(int i=1;i<=m;i++) Dp[i]=0;
	DFS2(1);
	int S=0;for(int i=1;i<=n;i++){if(i<=mid)S--;else if(i>mid) S++;}
	S-=Dp[1];
	if(S<0) return true;
	return false;
}

int main(){
    scanf("%i%i%i",&n,&m,&K);
    for(int i=1;i<=n;i++) scanf("%i",&s[i]),Vals[s[i]].pb(i);
    bool subtask2=true,subtask3=false;
    for(int i=2,p;i<=m;i++){
		scanf("%i",&p);
		E[p].pb(i);
		par[i]=p;
		if(p!=i-1) subtask2=false;
    }
    if(K==m) subtask3=true;

	if(subtask3){
		cerr<<"s3\n";
		DFSsetup(1);
		//for(int i=1;i<=n;i++) cerr<<Check(i)<<" ";cerr<<endl;
		//for(int i=1;i<=n;i++){printf("%i:\n",i);printf("%i\n",Check(i));}
		int l=1,r=n,res=n;
		while(l<=r){
			int mid=l+r>>1;
			if(Check1(mid)){res=mid;r=mid-1;}
			else l=mid+1;
		}
		printf("%i\n",res);
		return 0;
	}

	if(subtask2){
		cerr<<"s2\n";
		int res=inf;
		for(int i=0;i<=m;i++){
			for(auto j:Vals[i]) Update(j,1);
			int l=1,r=n,ans=0;
			while(l<=r){
				int mid=l+r>>1;
				int x=Get(mid),y=Get(mid+1,n);
				if(x>y){ans=mid;r=mid-1;}
				else l=mid+1;
			}
			if(Get(ans,ans)==0) ans--;
			//for(int j=1;j<=n;j++) printf("%i ",Get(j,j));printf("\n");
			//printf("%i\n",ans);
			res=min(res,ans);
		}
		printf("%i\n",res);
		return 0;
	}

    DFSsetup(1);
    //for(int i=1;i<=n;i++) cerr<<Check(i)<<" ";cerr<<endl;
    //for(int i=1;i<=n;i++){printf("%i:\n",i);printf("%i\n",Check(i));}
	int l=1,r=n,res=n;
	while(l<=r){
		int mid=l+r>>1;
		if(Check(mid)){res=mid;r=mid-1;}
		else l=mid+1;
	}
	printf("%i\n",res);

    return 0;
}
