#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 105;
ll n;
bool dbg = 0;
ll dp[maxn][maxn];
ll was[maxn][maxn];
ll ask(ll x,ll y) {
	ll ans = 0;
	if(was[x][y]) return was[x][y];
	cout<<"? "<<x<< " "<<y<<endl;
	if(dbg) return dp[x][y];
	cin >> ans;
	return ans;
}
ll a[maxn];
int main(){
	cin >> n;
	if(dbg) {
		for(ll i = 1;i<=n;i++) {
			for(ll j = 1;j<=n;j++){
				cin >> dp[i][j];
			}
		}
	}
	ll c = 1;
	a[c] = -1;
	for(ll i = 2;i<=n;i++) {
		a[i] = ask(i,1);
		if(a[i]>a[c]) c = i;
	}
	if(c!=1) {
		ll x = c-1;
		if(x==1) x = c+1;
		if(ask(1,x)>ask(c,x)) c = 1;
	}
	for(ll i = 1;i<=n;i++) a[i] = ask(c,i);
	cout<<"! ";
	for(ll i = 1;i<=n;i++) cout<<a[i]<< " ";
	cout<<endl;
	return (0-0);
}
/**
3
11 4 7
10 5 8
6 3 10

3
10 5 8
5 10 7
10 5 8
**/