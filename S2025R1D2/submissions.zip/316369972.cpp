#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
int Ask(int i,int j){
	cout<<"? "<<i<<" "<<j<<endl;
	int x;cin>>x;
	return x;
}
int main(){
    int n;cin>>n;
    vector<pair<int,int>>nesto;
	for(int i=2;i<=n;i++){
		nesto.pb({Ask(i,1),i});
	}
	sort(nesto.begin(),nesto.end());
	int I=nesto.back().se;
	vector<int>res(n+1,0);
	int ind;
	for(int i=1;i<=n;i++){
		if(i!=1&&i!=I) {
			int x=Ask(1,i),y=Ask(I,i);
			res[i]=max(x,y);
			if(x>y) ind=1;
			else ind=I;
			break;
		}
	}
	for(int i=1;i<=n;i++) if(res[i]==0) res[i]=Ask(ind,i);
	cout<<"! ";for(int i=1;i<=n;i++) cout<<res[i]<<" ";cout<<endl;
    return 0;
}
