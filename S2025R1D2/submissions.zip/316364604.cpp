#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=2e5+50,inf=1e9;
vector<int>E[N],Vals[N];
int n,m,K;
int s[N],par[N],in[N],out[N],tajm;
int num[N];
void DFSsetup(int u){
	in[u]=++tajm;
	for(auto i:E[u]) DFSsetup(i);
	out[u]=tajm;
}
void DFS(int u,int mid){
	for(auto i:Vals[u]){
		if(i>mid) num[u]++;
		else if(i<=mid) num[u]--;
	}
	for(auto i:E[u]) DFS(i,mid),num[u]+=num[i];
}
bool Podstablo(int u,int v){
	if(in[u]<=in[v]&&in[v]<=out[u]) return true;
	if(in[v]<=in[u]&&in[u]<=out[v]) return true;
	return false;
}
bool Check(int mid){
	for(int i=1;i<=m;i++) num[i]=0;
	DFS(1,mid);
	//for(int i=1;i<=m;i++) printf("%i ",num[i]);printf("\n");
	vector<pair<int,int>>nesto;
	for(int i=1;i<=m;i++) nesto.pb({num[i],i});
	sort(nesto.begin(),nesto.end());reverse(nesto.begin(),nesto.end());
	int k=K,S=0;
	for(int i=1;i<=n;i++){if(i<=mid)S--;else if(i>mid) S++;}
	vector<int>vtx;
	for(auto [x,u]:nesto){
		if(k<=0||x<=0) break;
		bool moze=true;
		for(auto v:vtx) if(Podstablo(u,v)) moze=false;
		if(!moze) continue;
		k--;
		S-=x;
		vtx.pb(u);
	}
	//for(auto i:vtx) printf("%i ",i);printf("\n");
	//printf("%i\n",S);
	if(S<0) return true;
	else return false;
}
int main(){
    scanf("%i%i%i",&n,&m,&K);
    for(int i=1;i<=n;i++) scanf("%i",&s[i]),Vals[s[i]].pb(i);
    for(int i=2,p;i<=m;i++){
		scanf("%i",&p);
		E[p].pb(i);
		par[i]=p;
    }
    DFSsetup(1);
    /*for(int i=1;i<=n;i++){
		printf("%i:\n",i);
		printf("%i\n",Check(i));
    }*/
	int l=1,r=n,res=n;
	while(l<=r){
		int mid=l+r>>1;
		if(Check(mid)){res=mid;r=mid-1;}
		else l=mid+1;
	}
	printf("%i\n",res);
    return 0;
}
