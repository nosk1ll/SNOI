#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=2e5+50,inf=1e9;
vector<int>E[N],Vals[N];
int s[N],par[N];
int T[N+50];
void Update(int i,int x){for(;i<=N;i+=i&-i)T[i]+=x;}
int Get(int i){int x=0;for(;i>=1;i-=i&-i)x+=T[i];return x;}
int Get(int l,int r){return Get(r)-Get(l-1);}
int main(){
    int n,m,K;scanf("%i%i%i",&n,&m,&K);
    for(int i=1;i<=n;i++) scanf("%i",&s[i]),Vals[s[i]].pb(i);
    for(int i=2,p;i<=m;i++){
		scanf("%i",&p);
		E[p].pb(i);
		par[i]=p;
    }
    int res=inf;
    for(int i=0;i<=m;i++){
		for(auto j:Vals[i]) Update(j,1);
		int l=1,r=n,ans=0;
		while(l<=r){
			int mid=l+r>>1;
			int x=Get(mid),y=Get(mid+1,n);
			if(x>y){ans=mid;r=mid-1;}
			else l=mid+1;
		}
		if(Get(ans,ans)==0) ans--;
		//for(int j=1;j<=n;j++) printf("%i ",Get(j,j));printf("\n");
		//printf("%i\n",ans);
		res=min(res,ans);
    }
    printf("%i\n",res);
    return 0;
}
