#include <bits/stdc++.h>
#define endl '\n'
#define int long long

using namespace std;

const long long longlongmax=9223372036854775807;
const int modul=998244353;
const long long mod = 1e9 + 7;


mt19937 mt(chrono::steady_clock::now().time_since_epoch().count());

const int N=209;

int rez[N],prviupit[N];
int istinoljubac;
int upit(int i,int j){
    cout << "? " << i << " " << j << endl << flush;
    int odg;cin >> odg;return odg;
}
int n;

bool pretpostavka(int ind,vector<vector<int>> matr){
    bool lazov[4];lazov[1]=lazov[2]=lazov[3]=0;
    bool istina[4];istina[1]=istina[2]=istina[3]=0;
    istina[ind]=1;
    for(int i=1; i<=3; i++){
        if(i==ind){
            for(int j=1; j<=3; j++){
                if(matr[j][i]==matr[ind][i])
                    istina[j]=1;
                else
                    lazov[j]=1;
            }
        }
        else{
            for(int j=1; j<=3; j++){
                if(i==j){
                    if(matr[j][j]==matr[ind][j])
                        istina[j]=1;
                    else
                        lazov[j]=1;
                    continue;
                }
                if(j==ind) continue;
                if(matr[j][i]>=matr[ind][i])
                    istina[j]=1;
                else
                    lazov[j]=1;
            }
        }
    }
    if((istina[1]&&lazov[1])||(istina[2]&&lazov[2])||(istina[3]&&lazov[3])) return false;
    return true;
}

vector<int> resi_trojku(vector<int> trojka){
    vector<vector<int>> matr(4,vector<int>(4));
    for(int i=1; i<=3; i++){
        for(int j=1; j<=3; j++)
            matr[i][j]=upit(trojka[i],trojka[j]);
    }
    vector<int> rez(4,0);
    if(pretpostavka(1,matr)) rez[1]=1;
    if(pretpostavka(2,matr)) rez[2]=1;
    if(pretpostavka(3,matr)) rez[3]=1;
    return rez;
}


signed main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    //freopen("seating.in","r",stdin);
    //freopen("seating.out","w",stdout);

    cin >> n;
    for(int i=1; i<=n; i++)
        prviupit[i]=upit(i,1);
    int maxi=-1,ind;
    for(int i=2; i<=n; i++){
        if(prviupit[i]>maxi){
            maxi=prviupit[i];
            ind=i;
        }
    }
    int treci;
    for(int i=2; i<=n; i++){
        if(i!=ind){
            treci=i;
            break;
        }
    }
    vector<int> odg=resi_trojku({-1,1,ind,treci});
    if(odg[1]==1) istinoljubac=1;
    if(odg[2]==1) istinoljubac=ind;
    if(odg[3]==1) istinoljubac=treci;
    for(int i=1; i<=n; i++)
        rez[i]=upit(istinoljubac,i);
    cout << "! ";
    for(int i=1; i<=n; i++)
        cout << rez[i] << " ";
    cout << flush;



    return 0;
}
/*
    abcde
    01234
    04321 --> 12340
              0   1
    011
    110

1
3 1
1 2 3
3 5

*/
