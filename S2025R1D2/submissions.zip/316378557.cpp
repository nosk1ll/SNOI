#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define PI acos(-1)
#define LSB(i) ((i) & -(i))
#define ll long long
#define pb push_back
#define mp make_pair
#define mt make_tuple
#define fi first
#define sc second
#define th third
#define fo fourth
#define pii pair<int,int>
#define pll pair<ll,ll>
#define ldb double
#define INF 1e15
#define MOD 1000000007
#define endl "\n"

#define all(data)       data.begin(),data.end()
#define TYPEMAX(type)   std::numeric_limits<type>::max()
#define TYPEMIN(type)   std::numeric_limits<type>::min()
#define MAXN 200007
#define MAXM 2007
ll s[MAXN],p[MAXM],prv[MAXN],nxt[MAXN];
vector<ll> adj[MAXM],ss[MAXM];
bool prf[MAXN];
vector<ll> vv;
void DFS(ll u,ll p)
{
    if(prf[u]) return;
    for(auto x:ss[u]) vv.pb(x);
    for(auto v:adj[u])
    {
        if(v==p) continue;
        DFS(v,u);
    }
}
int main()
{
    ios::sync_with_stdio(false); cin.tie(0);
    ll n,m,k; cin>>n>>m>>k;
    for(int i=1;i<=n;i++) {cin>>s[i]; ss[s[i]].pb(i);}
    for(int i=2;i<=m;i++)
    {
        cin>>p[i];
        adj[i].pb(p[i]); adj[p[i]].pb(i);
    }
    if(n<=16 && m<=16)
    {
        ll rez=INF;
        for(int mask=0;mask<(1<<m);mask++)
        {
            ll cnt=0;
            for(int j=1;j<=m;j++) {prf[j]=mask&(1<<(j-1)); cnt+=prf[j];}
            if(cnt>k) continue;
            vv.clear();
            for(int i=1;i<=n;i++)
            {
                if(s[i]==0) vv.pb(i);
            }
            DFS(1,0); sort(all(vv));
            ll sz=vv.size();
            rez=min(rez,vv[sz/2]);
        }
        cout<<rez<<endl;
    }
    else
    {
        set<ll> vv;
        for(int i=1;i<=n;i++)
        {
            if(s[i]==0) vv.insert(i);
        }
        ll sz=vv.size();
        ll rez=*next(vv.begin(),sz/2);
        for(int i=1;i<=m;i++)
        {
            for(auto xx:ss[i])
            {
                sz++; vv.insert(xx);
            }
            rez=min(rez,*next(vv.begin(),sz/2));
        }
        cout<<rez<<endl;
    }
    return 0;
}
