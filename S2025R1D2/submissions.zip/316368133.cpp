#include <bits/stdc++.h>
using namespace std;
int N, M, K, sol = INT_MAX;
int I[200096];
vector <int> D[2006];
vector <int> VG[2006];
bool P[2006];
vector <int> V;
inline void DFS(int node, int parent = 0)
{
  for(int x : D[node]) V.push_back(x);
  for(int x : VG[node]) if((x != parent) && !P[x]) DFS(x, node);
  return;
}
inline void Brute()
{
  for(int i = 1; i < (1 << M); i++)
  {
    if(__builtin_popcount(i) > K) continue;
    for(int j = 0; j < M; j++) P[j + 1] = bool(i & (1 << j));
    V = D[0];
    if(!P[1]) DFS(1);
    sort(V.begin(), V.end());
    sol = min(V[V.size() >> 1], sol);
  }
  return;
}
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> K;
  for(int i = 1; i <= N; i++)
  {
    cin >> I[i];
    D[I[i]].push_back(i);
  }
  for(int i = 2, j; i <= M; i++)
  {
    cin >> j;
    VG[i].push_back(j);
    VG[j].push_back(i);
  }
  if((N <= 20) && (M <= 20)) Brute();
  cout << sol << '\n';

  return 0;
}
