#include<bits/stdc++.h>
using namespace std;
using ll=long long;

const ll N=2e3+2;
vector<ll>g[N],na[N],ost;
ll f[N][N],jk[N],sl[N],n,m,k;

void dfs1(ll u,ll p,ll x){
	sl[u]=upper_bound(na[u].begin(),na[u].end(),x)-na[u].begin();
	jk[u]=na[u].size()-sl[u];
	for(int v:g[u]){
		if(!(v^p))continue;
		dfs1(v,u,x);
		sl[u]+=sl[v];
		jk[u]+=jk[v];
	}
}

void dfs(ll u,ll p){
	for(int i=0;i<=k;++i)
		f[u][i]=1e18;
	f[u][0]=0;
	for(int v:g[u]){
		if(!(v^p))continue;
		dfs(v,u);
		for(int i=k;i>=0;--i){
			for(int j=0;j<=i;++j)
				f[u][i]=min(f[u][i],f[u][i-j]+f[v][j]);
		}
	}
	f[u][1]=min(f[u][1],sl[u]-jk[u]);
}

bool chk(ll x){
	dfs1(1,0,x);
	dfs(1,0);
	ll mn=f[1][k]+1;
	for(int i=0;i<k;++i)mn=min(mn,f[1][i]+1);
	return(mn<=2*x-n);
}

bool chk2(ll x){
	dfs1(1,0,x);
	ll mn=sl[1]-jk[1]+1;
	for(int i=2;i<=m;++i)mn=min(mn,sl[i]-jk[i]+1);
	return(mn<=2*x-n);
}

ll w[N],ff[N][2];

void calc(ll u,ll p){
	ff[u][0]=0;
	ff[u][1]=w[u];
	for(int v:g[u]){
		if(!(v^p))continue;
		calc(v,u);
		ff[u][0]+=min(ff[v][0],ff[v][1]);
	}
}

bool chk3(ll x){
	assert(k==m);
	dfs1(1,0,x);
	for(int i=1;i<=m;++i)w[i]=sl[i]-jk[i];
	calc(1,0);
	return(min(ff[1][0],ff[1][1])+1<=2*x-n);
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    
    cin>>n>>m>>k;

    for(int i=1,u;i<=n;++i){
    	cin>>u;
    	if(!u)ost.push_back(i);
    	else na[u].push_back(i);
    }

    bool glista=1;
    for(int i=2;i<=m;++i){
    	ll par;cin>>par;
    	glista&=(par==i-1);
    	g[i].push_back(par);
    	g[par].push_back(i);
    }

    for(int i=1;i<=m;++i)
    	sort(na[i].begin(),na[i].end());

    ll l=1,r=n,ans=r;
    while(l<=r){
    	ll md=(l+r)/2;
    	if((glista||k==m?(k==m?chk3(md):chk2(md)):chk(md))){
    		r=md-1;
    		ans=md;
    	}else
    		l=md+1;
    }

    cout<<ans<<'\n';
}