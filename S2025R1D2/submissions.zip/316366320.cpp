#include<bits/stdc++.h>
using namespace std;
using ll=long long;

const ll N=1e5+2;
ll a[N],n,q;
vector<ll>st1[4*N],st[4*N];
     
ll get(ll k,vector<ll>&fw){
    ll s=0;++k;
    while(k>0){
        s+=fw[k];
        k-=k&-k;
    }
    return s;
}
 
void add(ll k,ll x,vector<ll>&fw){
    ++k;
    while(k<fw.size()){
        fw[k]+=x;
        k+=k&-k;
    }
}

void bd1(ll i=1,ll l=1,ll r=n){
    if(l==r){st1[i]={a[l]};return;}
    ll md=(l+r)/2;
    bd1(i*2,l,md);
    bd1(i*2+1,md+1,r);
    st1[i].resize(st1[i*2].size()+st1[i*2+1].size());
    merge(st1[i*2].begin(),st1[i*2].end(),st1[i*2+1].begin(),st1[i*2+1].end(),st1[i].begin());
}

void bd2(ll i=1,ll l=1,ll r=n){
    st[i].resize(st1[i].size()+1,0);
    for(ll j=0;j<st1[i].size();++j)
        add(j,st1[i][j],st[i]);
    if(l==r)return;
    ll md=(l+r)/2;
    bd2(i*2,l,md);
    bd2(i*2+1,md+1,r);
}

ll qry(ll l,ll r,ll x,ll i=1,ll tl=1,ll tr=n){
    if(tl>=l&&tr<=r){
        ll it=upper_bound(st1[i].begin(),st1[i].end(),x)-st1[i].begin()-1;
        return get(it,st[i]);
    }
    ll md=(tl+tr)/2,ret=0;
    if(md>=l)ret+=qry(l,r,x,i*2,tl,md);
    if(md+1<=r)ret+=qry(l,r,x,i*2+1,md+1,tr);
    return ret;
}

void upd(ll id,ll sa,ll na,ll i=1,ll tl=1,ll tr=n){
    ll it=lower_bound(st1[i].begin(),st1[i].end(),sa)-st1[i].begin();
    st1[i][it]+=na-sa;
    add(it,na-sa,st[i]);
    if(tl==tr)return;
    ll md=(tl+tr)/2;
    if(id<=md)upd(id,sa,na,i*2,tl,md);
    else upd(id,sa,na,i*2+1,md+1,tr);
}

vector<ll>fenw[21];

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    
    cin>>n>>q;
    for(int i=1;i<=n;++i)
        cin>>a[i];

    if(n<=1000&&q<=1000){
        while(q--){
            ll tp;cin>>tp;
            if(tp==2){
                ll i,x;cin>>i>>x;
                a[i]=x;
            }else{
                ll l,r;cin>>l>>r;
                vector<ll>v;
                for(int i=l;i<=r;++i)
                    v.push_back(a[i]);
                sort(v.begin(),v.end());
                ll cur=0;
                for(int x:v){
                    if(x>cur+1)break;
                    cur+=x;
                }
                cout<<1+cur<<'\n';
            }
        }
        return 0;
    }

    ll ovaj=1;
    for(int i=1;i<=n;++i)if(a[i]>20)ovaj=0;

    if(ovaj){
        for(int i=1;i<=20;++i)fenw[i].resize(n+1,0);
        for(int i=1;i<=20;++i){
            for(int j=1;j<=n;++j){
                if(a[j]!=i)continue;
                add(j-1,1,fenw[i]);
            }
        }
        while(q--){
            ll tp;cin>>tp;
            if(tp==2){
                ll i,x;cin>>i>>x;
                add(i-1,-1,fenw[a[i]]);
                a[i]=x;
                add(i-1,1,fenw[a[i]]);
            }else{
                ll l,r;cin>>l>>r;
                --l,--r;
                ll cnt[21];
                for(int i=1;i<=20;++i)
                    cnt[i]=get(r,fenw[i])-get(l-1,fenw[i]);
                ll put[21];
                put[0]=0;
                for(int i=1;i<=20;++i)
                    put[i]=put[i-1]+cnt[i]*i;
                ll cur=0;
                while(q){
                    ll x=put[min(20ll,cur+1)];
                    if(x<=cur)break;
                    cur=x;
                }
                cout<<cur+1<<'\n';
            }
        }
        return 0;
    }
    
    bd1();
    bd2();

    while(q--){
        ll tp;cin>>tp;
        if(tp==2){
            ll i,x;cin>>i>>x;
            upd(i,a[i],x);
            a[i]=x;
        }else{
            ll l,r;cin>>l>>r;
            ll cur=0;
            while(1){
                ll x1=qry(l,r,cur+1);
                if(x1<=cur)break;
                cur=x1;
            }
            cout<<cur+1<<'\n';
        }
    }
}