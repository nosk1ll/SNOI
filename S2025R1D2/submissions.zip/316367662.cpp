#include <bits/stdc++.h>

using namespace std;


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n, x, best = 0;
    cin >> n;
    deque<int> q;
    for (int i = 2; i <= n; i++){
        cout << "? " << i << " " << 1 << endl;
        cin >> x;
        if (x >= best){
            q.push_front(i);
            best = x;
        }
        else q.push_back(i);
    }
    cout << "? " << 1 << " " << 1 << endl;
    int self;
    cin >> self;
    vector<int> ans(n + 1, -1);
    if (self == best){
        ans[1] = self;
        for (int i = 2; i <= n; i++){
            cout << "? " << 1 << " " << i << endl;
            cin >> ans[i];
        }
    }
    else{
        int a_ans, b_ans;
        cout << "? " << 1 << " " << q.back() << endl;
        cin >> a_ans;
        cout << "? " << q.front() << " " << q.back() << endl;
        cin >> b_ans;
        if (a_ans > b_ans){
            ans[q.back()] = a_ans;
            ans[1] = self;
            for (int i = 2; i <= n; i++) if (ans[i] == -1){
                cout << "? " << 1 << " " << i << endl;
                cin >> ans[i];
            }
        }
        else{
            ans[q.back()] = b_ans;
            ans[1] = best;
            for (int i = 2; i <= n; i++) if (ans[i] == -1){
                cout << "? " << q.front() << " " << i << endl;
                cin >> ans[i];
            }
        }
    }
    cout << "! ";
    for (int i = 1; i <= n; i++) cout << ans[i] << " ";
    cout << endl;
    return 0;
}
/*
5 12
1 2 3 4 5
1 1 5
2 1 2
1 1 5
*/
