#include <bits/stdc++.h>
using namespace std;
int N, X, I;
int D[101];
int main()
{
  cin >> N;
  map <int, int> MAP;
  for(int i = 2; i <= N; i++)
  {
    cout << "? " << i << " 1" << endl;
    cin >> X;
    MAP[X] = i;
  }
  if(MAP.size() > 2) exit(333); ///lose sam razumeo tekst onda
  if(MAP.size() == 1)
  {
    cout << "? 1 1" << endl;
    cin >> X;
    MAP[X] = 1;
  }
  D[1] = MAP.rbegin()->first;
  I = MAP.rbegin()->second;
  for(int i = 2; i <= N; i++)
  {
    cout << "? " << I << ' ' << i << endl;
    cin >> D[i];
  }
  cout << "!";
  for(int i = 1; i <= N; i++) cout << ' ' << D[i];
  cout << endl;

  return 0;
}
