#include <bits/stdc++.h>

using namespace std;
using ll = long long;
#define pb push_back


const int N = 1e7 + 5;
int lc[N], rc[N];
int R[N], nn, C = 0;
ll S[N];
int build(int l = 1, int r = nn) {
    if (l == r) return ++C;
    int m = (l + r)/2, nd = ++C;
    lc[nd] = build(l, m);
    rc[nd] = build(m+1, r);
    return nd;
}
int build2(int nd, int p, int x, int l2 = 1, int r2 = nn) {
    if (l2 == r2) {
        int ND = ++C;
        S[ND] = S[nd] + x;
        return ND;
    }
    int m2 = (l2 + r2)/2, ND = ++C;
    lc[ND] = lc[nd], rc[ND] = rc[nd];
    if (p <= m2)    
        lc[ND] = build2(lc[nd], p, x, l2, m2);
    else
        rc[ND] = build2(rc[nd], p, x, m2+1, r2);
    S[ND] = S[lc[ND]] + S[rc[ND]];
    return ND;
}
ll sum(int ndl, int ndr, int l, int r, int l2 = 1, int r2 = nn) {
    if (l <= l2 && r2 <= r) return S[ndr] - S[ndl];
    int m2 = (l2 + r2)/2;
    ll s = 0;
    if (l <= m2)    s += sum(lc[ndl], lc[ndr], l, r, l2, m2);
    if (m2+1 <= r)  s += sum(rc[ndl], rc[ndr], l, r, m2+1, r2);
    return s;
}
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, q;
    cin >> n >> q; nn = n;
    int a[n+1];
    vector<int> v;
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
        v.pb(a[i]);
    }
    sort(v.begin(), v.end());
    v.erase(unique(v.begin(), v.end()), v.end());
    auto f = [&](int x) {
        return lower_bound(v.begin(), v.end(), x) - v.begin() + 1;
    };
    R[0] = build();
    for (int i = 1; i <= n; ++i)    R[i] = build2(R[i-1], f(a[i]), a[i]);
    while (q--) {
        int t;
        cin >> t;
        if (t == 1) {
            int l, r;
            cin >> l >> r;
            ll s = 1;
            while (s <= 1e9) {
                ll s2 = s;
                s = sum(R[l-1], R[r], 1, f(s+1)-1)+1;
                if (s == s2)    break;
            }
            cout << s << '\n';
        }
    }
}