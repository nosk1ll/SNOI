#include <bits/stdc++.h>
#define int long long
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define sc second
#define endl "\n"
#define pii pair<int,int>

using namespace std;

const int MAXN = 1e5+5;
const int mod7 = 1e9+7;
const long long inf = 1e18;

signed main()
{
    ios_base::sync_with_stdio(false),cin.tie(0), cout.tie(0);
    int tt=1;
    //cin >> tt;
    while(tt--)
    {
        int n,q;
        cin >> n >> q;
        vector<int> niz(n+1);
        for(int i=1; i<=n; i++)cin >> niz[i];
        while(q--)
        {
            int a,b,c;
            cin >> a >> b >> c;
            if(a&1)
            {
                vector<int> niz2;
                for(int i=b; i<=c; i++)niz2.pb(niz[i]);
                sort(all(niz2));
                int rez = 1;
                for(int i=0; i<(int)niz2.size(); i++)
                {
                    if(niz2[i] > rez)break;
                    rez+=niz2[i];
                }
                cout << rez << endl;
            }
            else
            {
                niz[b] = c;
            }
        }
    }
}
