#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 100005;
ll n,q;
ll a[maxn];

int main(){
	ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
	cin >> n >> q;
	for(ll i = 1;i<=n;i++) cin >> a[i];
	if(n>1000||q>1000) return 0;
	vector<ll> v;
	while(q--) {
		ll tip,l,r; cin >> tip >> l >> r;
		if(tip==1) {
			v.clear();
			for(ll i = l;i<=r;i++) v.pb(a[i]);
			sort(all(v));
			ll x = 0;
			for(ll y : v) {
				if(y>x+1) break;
				x+=y;
			}
			cout<<x+1<<endl;
		}else a[l] = r;
	}
	return (0-0);
}