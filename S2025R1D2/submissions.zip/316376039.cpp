#include<bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);

typedef long long ll;
struct SQuery{int nT,iL,iR;ll llX;};

int nN,nQ;
vector<ll> vllCurr;
vector<vector<ll>> vvvllTreeVals;
vector<vector<ll>> vvvllBit;
vector<SQuery> vQQueries;

void fBuildVals(int iNode,int iL,int iR,const vector<vector<ll>>& vvvllValsAtPos){
if(iL==iR){
vvvllTreeVals[iNode]=vvvllValsAtPos[iL];
sort(vvvllTreeVals[iNode].begin(),vvvllTreeVals[iNode].end());
vvvllTreeVals[iNode].erase(unique(vvvllTreeVals[iNode].begin(),vvvllTreeVals[iNode].end()),vvvllTreeVals[iNode].end());
}else{
int iM=(iL+iR)>>1;
fBuildVals(iNode<<1,iL,iM,vvvllValsAtPos);
fBuildVals(iNode<<1|1,iM+1,iR,vvvllValsAtPos);
auto& vL=vvvllTreeVals[iNode<<1];
auto& vR=vvvllTreeVals[iNode<<1|1];
auto& vV=vvvllTreeVals[iNode];
vV.resize(vL.size()+vR.size());
merge(vL.begin(),vL.end(),vR.begin(),vR.end(),vV.begin());
vV.erase(unique(vV.begin(),vV.end()),vV.end());
}

}

void fBitUpdate(int iNode,int idx,ll llDelta){
for(;idx<(int)vvvllBit[iNode].size();idx+=idx&-idx)vvvllBit[iNode][idx]+=llDelta;
}

void fUpdateST(int iNode,int iL,int iR,int iPos,ll llVal,ll llDelta){
int idx=upper_bound(vvvllTreeVals[iNode].begin(),vvvllTreeVals[iNode].end(),llVal)-vvvllTreeVals[iNode].begin();
if(idx>0&&vvvllTreeVals[iNode][idx-1]==llVal)fBitUpdate(iNode,idx,llDelta);
if(iL==iR)return;
int iM=(iL+iR)>>1;
if(iPos<=iM)fUpdateST(iNode<<1,iL,iM,iPos,llVal,llDelta);
else fUpdateST(iNode<<1|1,iM+1,iR,iPos,llVal,llDelta);
}
ll fQueryST(int iNode,int iL,int iR,int iQL,int iQR,ll llLim){
if(iQR<iL||iR<iQL)return 0;
if(iQL<=iL&&iR<=iQR){
int idx=upper_bound(vvvllTreeVals[iNode].begin(),vvvllTreeVals[iNode].end(),llLim)-vvvllTreeVals[iNode].begin();
ll llSum=0;
for(;idx>0;idx-=idx&-idx)llSum+=vvvllBit[iNode][idx];
return llSum;
}
int iM=(iL+iR)>>1;
return fQueryST(iNode<<1,iL,iM,iQL,iQR,llLim)+fQueryST(iNode<<1|1,iM+1,iR,iQL,iQR,llLim);
}


int main(){

ubrzaj

cin>>nN>>nQ;
vllCurr.resize(nN);
for(int i=0;i<nN;i++)cin>>vllCurr[i];
vector<vector<ll>> vvvllValsAtPos(nN);
for(int i=0;i<nN;i++)vvvllValsAtPos[i].push_back(vllCurr[i]);
for(int i=0;i<nQ;i++){
int t;cin>>t;
if(t==1){
int l,r;cin>>l>>r;--l;--r;
vQQueries.push_back({t,l,r,0});
}else{
int p;ll x;cin>>p>>x;--p;
vQQueries.push_back({t,p,0,x});
vvvllValsAtPos[p].push_back(x);
}
}
vvvllTreeVals.assign(4*nN,{});
fBuildVals(1,0,nN-1,vvvllValsAtPos);
vvvllBit.assign(4*nN,{});

for(int i=1;i<4*nN;i++)vvvllBit[i].assign(vvvllTreeVals[i].size()+1,0);
for(int i=0;i<nN;i++)fUpdateST(1,0,nN-1,i,vllCurr[i],vllCurr[i]);
for(auto&q:vQQueries){
if(q.nT==1){
ll cur=0,nxt;
do{
nxt=fQueryST(1,0,nN-1,q.iL,q.iR,cur+1);
if(nxt==cur)break;
cur=nxt;
}while(true);
cout<<cur+1<<"\n";
}else{
ll oldv=vllCurr[q.iL],newv=q.llX;
fUpdateST(1,0,nN-1,q.iL,oldv,-oldv);
vllCurr[q.iL]=newv;
fUpdateST(1,0,nN-1,q.iL,newv,newv);
}
}
return 0;
}
