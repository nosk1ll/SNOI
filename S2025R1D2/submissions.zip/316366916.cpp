#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define int long long
#define ldb long double
typedef pair<int, int> pl;
typedef vector<int> vi;
typedef vector<int> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()

int ask(int i, int j) {
	cout << "? " << i << " " << j << endl;
	int ret; cin >> ret;
	return ret;
}

int medijana(int x, int y, int z) {
	return (x+y+z-max({x, y, z})-min({x, y, z}));
}

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

	int n; cin >> n;
	if (n<=65) {
		vpi rez;
		int mx=0;
		map<int, int> cnt;
		for (int i=1; i<=n; i++) {
			int ret=ask(i, 1);
			rez.pb({ret, i});
			cnt[ret]++;
			mx=max(mx, ret);
		}
		vi res;
		if (cnt[mx]>=2) {
			for (int i=1; i<=n; i++)
				res.pb(ask(1, i));
		}
		else {
			sort(all(rez));
			vi upiti;
			int x=1, y=rez[sz(rez)-2].s, z=(n==y?n-1:n);
			upiti.pb(x); upiti.pb(y); upiti.pb(z);
			vector<vi> vec(3, vi(3));
			for (int i=0; i<3; i++)
				for (int j=0; j<3; j++)
					vec[i][j]=ask(upiti[i], upiti[j]);
			int istinit=0;
			for (int i=0; i<3; i++) {
				bool ok=true;
				for (int j=0; j<3; j++) {
					if (i!=j) {
						ok&=(vec[i][j]==medijana(vec[0][j], vec[1][j], vec[2][j]));
					}
				}
				if (ok)
					istinit=upiti[i];
			}
			for (int i=1; i<=n; i++)
				res.pb(ask(istinit, i));
		}
		cout << "! ";
		for (int x:res)
			cout << x << " ";
		cout << endl;
	}
	else if (n<=100) {
		vpi rez;
		int mx=0;
		map<int, int> cnt;
		for (int i=1; i<=n; i++) {
			int ret=ask(i, 1);
			rez.pb({ret, i});
			cnt[ret]++;
			mx=max(mx, ret);
		}
		vi res;
		if (cnt[mx]>=2) {
			for (int i=1; i<=n; i++)
				res.pb(ask(1, i));
		}
		else {
			for (int i=1; i<=n; i++)
				res.pb(ask(2, i));
		}
		cout << "! ";
		for (int x:res)
			cout << x << " ";
		cout << endl;
	}
	return 0;
}
