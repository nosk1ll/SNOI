#include <bits/stdc++.h>

using namespace std;

// Macros
#define f first
#define s second
#define ll long long
#define db double
#define vi vector<int>
#define vl vector<ll>
#define vp vector<pair<ll, ll>>
#define vvi vector<vi>
#define mi map<int, int>
#define beg begin
#define nl "\n"
#define yes "YES\n"
#define no "NO\n"

// Loops
#define FOR(i, a, b) for(int i = a; i < b; i++)
#define ROF(i, a, b) for(int i = a - 1; a >= b; i--)

int ask(int i, int j) {
    cout << "? " << i + 1 << " " << j + 1 << nl;
    cout.flush();
    int h;
    cin >> h;
    return h;
}

int q1(vi a, int l, int r) {
    sort(a.begin() + l - 1, a.begin() + r);
    int res = 1;
    FOR(i, l - 1, r){
        if(a[i] > res) return res;
        res += a[i];
    }
    return res;
}

void solve(){
    int n, q;
    cin >> n >> q;
    vi a(n);
    FOR(i, 0, n){
        cin >> a[i];
    }
    vi v;
    while(q--){
        int a1, b, c;
        cin >> a1 >> b >> c;
        if(a1 == 1){
            v.push_back(q1(a, b, c));
        }
        else a[b - 1] = c;
    }
    for(auto i : v){
        cout << i << nl;
    }
}

int main(){
    cin.tie(0);cout.tie(0);ios_base::sync_with_stdio(false);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
