#include<bits/stdc++.h>
using namespace std;
using ll=long long;

map<array<ll,2>,int>mp;
ll ask(ll i,ll j){
    if(mp[{i,j}])return mp[{i,j}];
    cout<<"? "<<i<<" "<<j<<endl;
    ll x;cin>>x;
    return(mp[{i,j}]=x);
}

ll a[102];

signed main(){
    ll n;cin>>n;

    ll A=1,B=0,kolko=0;
    for(int i=2;i<=n;++i){
        ll x=ask(i,1);
        if(x>kolko){
            B=i;
            kolko=x;
        }
    }

    ll C=(B==2?n:2),dobar=A;
    if(ask(B,C)>=ask(A,C))dobar=B;

    for(int i=1;i<=n;++i)
        a[i]=ask(dobar,i);

    cout<<"! ";
    for(int i=1;i<=n;++i)cout<<a[i]<<" ";
    cout<<endl;
}
