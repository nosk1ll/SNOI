#include<bits/stdc++.h>
#define int long long
using namespace std;
int q(int i,int j){
	cout<<"? "<<i <<' '<<j<<'\n';
	cout.flush();
	int x;cin>>x;
	return x;
}
void solve() {
	int n;cin>>n;
	int m=-1e18,j=-1;
	for(int i=2;i<=n;i++){
		int x=q(i,1);
		if(m<x){
			m=x;
			j=i;
		}
	}
	vector<int>vis(n+1,-1);
	for(int i=2;i<=n;i++){
		if(j!=i){
			int x1=q(1,i),x2=q(j,i);
			if(x1>x2){
				j=1;
				m=q(j,1);
				vis[i]=x1;
			}else{
				vis[i]=x2;
			}
			break;
		}
	}
	vis[1]=m;
	for(int i=2;i<=n;i++){
		if(vis[i]==-1){
			vis[i]=q(j,i);
		}
	}
	cout<<"! ";
	for(int i=1;i<=n;i++){
		cout<<vis[i]<<' ';
	}cout.flush();
}
int32_t main() {
	ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int32_t T=1;
	while(T--) {
		solve();
	}
	return 0;
}