#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
typedef long long int lint;

bool sledeci(vector<int>& b){
	bool sve1 = true;
	for(int i = 0; i < b.size(); i++){
		if(b[i] == 0){
			sve1 = false;
		}
	}
	if(sve1){
		return false;
	}
	for(int i = 0; i < b.size(); i++){
		if(b[i] == 0){
			b[i] = 1;
			break;
		}
		else{
			b[i] = 0;
		}
	}
	return true;
}

bool zad(vector<int> b, int k){
	int suma = 0;
	for(int i = 0; i < b.size(); i++){
		if(b[i] == 1){
			suma++;
		}
	}
	if(suma <= k){
		return true;
	}
	return false;
}

int med(set<int>& a, int n){
	set<int> b;
	for(int i = 0; i < n; i++){
		b.insert(i);
	}
	for(int x : a){
		b.erase(x);
	}
	vector<int> c;
	for(int x : b){
		c.push_back(x);
	}
	if((c.size() % 2) == 0){
		return (c[c.size() / 2] + 1);
	}
	else{
		return (c[c.size() / 2] + 1);
	}
}


//int node = 1;
//int nodel = 0;
//int noder = n - 1;


vector<int> segmentno(vector<int>& a){
	int n = a.size();
	while(__builtin_popcount(n) != 1){
		a.push_back(0);
		n++;
	}
	vector<int> seg(2 * n);
	for(int i = 0; i < n; i++){
		seg[n + i] = a[i];
	}
	for(int i = n - 1; i > 0; i--){
		seg[i] = seg[2 * i] + seg[2 * i + 1];
	}
	return seg;
}

//NE POMESATI NODEL I L!!!
//node = 1, l = n - 1, r = 0, l i r su od gde do gde
int keri(vector<int>& seg, int node, int l, int r, int nodel, int noder){
	if((l <= nodel) && (r >= noder)){
		return seg[node];
	}
	if((l > noder) || (nodel > r)){
		return 0;
	}
	int mid = (nodel + noder) / 2;
	return keri(seg, (2 * node), l, r, nodel, mid) + keri(seg, (2 * node + 1), l, r, (mid + 1), noder);
}

//PAZI NA RASPORED NODEL I L
//node = 1, nodel = 0, noder = n - 1, l i r su od koje do koje pozicije, vr je vrednost na koju se menja
void promeni(vector<int>& seg, int node, int l, int r, int nodel, int noder, int vr){
	if((l <= nodel) && (r >= noder)){
		seg[node] = vr;
		return;
	}
	if((l > noder) || (nodel > r)){
		return;
	}
	int mid = (nodel + noder) / 2;
	promeni(seg, (2 * node), l, r, nodel, mid, vr);
	promeni(seg, (2 * node + 1), l, r, (mid + 1), noder, vr);    
	seg[node] = seg[2 * node] + seg[2 * node + 1];
}


int f(vector<int>& mark, vector<int>& segm, int n, int ntr){
	int l = 0;
	int r = n - 1;
	int mid = (r + l) / 2;
	int rez = r;
	while(l <= r){
		mid = (l + r) / 2;
		int ntrr;
		int trr = keri(segm, 1, 0, mid, 0, (mark.size() - 1));
		if(trr > (ntr / 2)){
			r = mid - 1;
			rez = mid;
		}
		else{
			l = mid + 1;
		}
	}
	return (rez + 1);
}


void solve(){
	int n, m, k;
	cin >> n >> m >> k;
	vector<int> s(n);
	for(int i = 0; i < n; i++){
		cin >> s[i];
		s[i]--;
	}
	vector<int> p(m);
	bool svi = true;
	vector<vector<int>> graf(m);
	for(int i = 1; i < m; i++){
		cin >> p[i];
		p[i]--;
		if(p[i] != (i - 1)){
			svi = false;
		}
		graf[i].push_back(p[i]);
		graf[p[i]].push_back(i);
	}
	if((n <= 16) && (m <= 16)){
		vector<set<int>> skup(m);
		for(int i = 0; i < n; i++){
			if(s[i] != -1){
				skup[s[i]].insert(i);	
			}
		}
		queue<int> red;
		for(int i = 1; i < m; i++){
			if((graf[i].size() == 1)){
				red.push(i);
			}
		}
		while(!red.empty()){
			int node = red.front();
			red.pop();
			if(node != 0){
				for(int x : skup[node]){
					skup[p[node]].insert(x);
				}
				red.push(p[node]);
			}
		}
		vector<int> b(m, 0);
		int mini = INT_MAX;
		set<int> random111;
		mini = min(mini, med(random111, n));
		while(sledeci(b)){
			if(zad(b, k)){
				set<int> sk;
				for(int i = 0; i < b.size(); i++){
					if(b[i] == 1){
						for(int x : skup[i]){
							sk.insert(x);
						}
					}
				}
				mini = min(mini, med(sk, n));
			}
		}
		cout << mini << endl;
	}
	else if(svi){
		vector<set<int>> skup(m);
		for(int i = 0; i < n; i++){
			if(s[i] != -1){
				skup[s[i]].insert(i);	
			}
		}
		
		vector<int> mark(n, 1);
		vector<int> segm = segmentno(mark);
		int nn = mark.size();
		int mini = (n / 2) + 1;

		int ntr = n;

		for(int node = m - 1; node >= 0; node--){
			for(int x : skup[node]){
				mark[x] = 0;
				ntr--;
				promeni(segm, 1, x, x, 0, (nn - 1), 0);
			}
			int tr = f(mark, segm, n, ntr);
			mini = min(mini, tr);
		}
		cout << mini << endl;
	}
}   
 


signed main(){
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}   
