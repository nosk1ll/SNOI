#include <bits/stdc++.h>
#define ll long long
#define MAXN 100010
using namespace std;
ll a[MAXN];
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll n,q;
    cin >> n >> q;
    for (ll i=1;i<=n;i++)
        cin >> a[i];
    ll t,l,r;
    while (q--)
    {
        cin >> t >> l >> r;
        if (t==2)
        {
            a[l]=r;
            continue;
        }
        if (n<=1000 && q<=1000)
        {
            vector<ll> v;
            for (ll i=l;i<=r;i++)
                v.push_back(a[i]);
            sort(v.begin(),v.end());
            ll cur=1;
            set<ll> s,s1;
            s.insert(0);
            for (ll i=0;i<v.size();i++)
            {
                while (s.count(cur))
                    cur++;
                if (v[i]+*(s.begin())>cur)
                    break;
                for (ll j : s)
                {
                    s1.insert(j);
                    s1.insert(j+v[i]);
                }
                swap(s,s1);
            }
            while (s.count(cur))
                cur++;
            cout << cur << "\n";
        }
    }
    return 0;
}
