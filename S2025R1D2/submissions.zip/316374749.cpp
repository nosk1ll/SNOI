#include<bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);

struct BIT{
int nSize,pwVal;
vector<int> fArr;
BIT(int nSize):nSize(nSize),fArr(nSize+1,0){
pwVal=1;
while((pwVal<<1)<=nSize)pwVal<<=1;
}
void add(int iIndex,int vVal){
for(;iIndex<=nSize;iIndex+=iIndex&-iIndex)fArr[iIndex]+=vVal;
}
int kth(int kPos){
int iPos=0;
for(int bVal=pwVal;bVal>0;bVal>>=1)
if(iPos+bVal<=nSize&&fArr[iPos+bVal]<kPos){
kPos-=fArr[iPos+bVal];
iPos+=bVal;
}
return iPos+1;
}
};

int main(){
ubrzaj

int nCount,mCount,kCount;
cin>>nCount>>mCount>>kCount;
vector<int> arrS(nCount+1);
for(int iIndex=1;iIndex<=nCount;iIndex++)
cin>>arrS[iIndex];
for(int iIndex=2;iIndex<=mCount;iIndex++){
int pParent;
cin>>pParent;
}
vector<vector<int>> vecAt(mCount+1);
vector<int> vecZero;
for(int iIndex=1;iIndex<=nCount;iIndex++){
if(arrS[iIndex]==0)
vecZero.push_back(iIndex);
else
vecAt[arrS[iIndex]].push_back(iIndex);
}
//struct
BIT bitInstance(nCount);
int iTotal=0;
for(int xIndex:vecZero){
bitInstance.add(xIndex,1);
iTotal++;
}
int iIdx=iTotal/2+1;
int iAnswer=bitInstance.kth(iIdx);
for(int jIndex=2;jIndex<=mCount+1;jIndex++){
if(jIndex-1<=mCount)
for(int xIndex:vecAt[jIndex-1]){
bitInstance.add(xIndex,1);
iTotal++;
}
iIdx=iTotal/2+1;
iAnswer=min(iAnswer,bitInstance.kth(iIdx));
}
cout<<iAnswer<<"\n";
return 0;
}
