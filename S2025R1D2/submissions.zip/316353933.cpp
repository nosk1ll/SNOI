#include <bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define ll long long
#define ld long double
const int N=1e5+50;
const ll inf=1e18;
void Unique(vector<ll>&a){sort(a.begin(),a.end());int m=unique(a.begin(),a.end())-a.begin();a.resize(m);}
ll a[N];
int main(){
    int n,q;scanf("%i%i",&n,&q);
    for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
    while(q--){
		int type,l,r;scanf("%i%i%i",&type,&l,&r);
		if(type==1){
			vector<ll>b={0};
			for(int i=l;i<=r;i++){
				int m=b.size();
				for(int j=0;j<m;j++) b.pb(b[j]+a[i]);
				Unique(b);
			}
			//for(auto i:b) printf("%lld ",i);printf("\n");
			b.pb(inf);
			ll res=0;
			for(int i=0;i+1<b.size();i++) if(b[i+1]>b[i]+1){res=b[i]+1;break;}
			printf("%lld\n",res);
		}
		else{
			a[l]=r;
		}
    }
    return 0;
}
