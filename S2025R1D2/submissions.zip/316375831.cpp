#include <bits/stdc++.h>

#define int long long

using namespace std;

const int N = 2e5 + 10;

const int inf = 1e16;

signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  int n, q;
  cin >> n >> q;
  vector<int> a(n + 1);
  for(int i = 1; i <= n; i++) cin >> a[i];
  while(q--) {
    int type;
    cin >> type;
    if(type == 1) {
      int l, r;
      cin >> l >> r;
      vector<int> v;
      for(int i = l; i <= r; i++) v.push_back(a[i]);
      sort(v.begin(), v.end());
      int res = v[0];
      for(int i = 1; i < r - l + 1; i++) {
        if(v[i] - res > 1) break;
        res += v[i];
      }
      cout << (v[0] == 1 ? res + 1 : 1) << "\n";
    } else {
      int i, x;
      cin >> i >> x;
      a[i] = x;
    }
  }
}
