#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define PI acos(-1)
#define LSB(i) ((i) & -(i))
#define ll long long
#define pb push_back
#define mp make_pair
#define mt make_tuple
#define fi first
#define sc second
#define th third
#define fo fourth
#define pii pair<int,int>
#define pll pair<ll,ll>
#define ldb double
#define INF 1e15
#define MOD 1000000007
#define endl "\n"

#define all(data)       data.begin(),data.end()
#define TYPEMAX(type)   std::numeric_limits<type>::max()
#define TYPEMIN(type)   std::numeric_limits<type>::min()
#define MAXN 207
ll h[MAXN];
ll n;
ll Query(ll i,ll j)
{
    cout<<"? "<<i<<" "<<j<<endl;
    ll x; cin>>x; return x;
}
ll Try(ll i,ll j)
{
    ll k;
    for(int l=1;l<=n;l++)
    {
        if(l!=i && l!=j) {k=l; break;}
    }
    ll ik=Query(i,k),jk=Query(j,k);
    if(ik==jk) return i;
    else if(ik>jk) return i;
    else return j;
}
vector<ll> Solve(vector<ll> a)
{
    //cout<<"a ";
    //for(auto xx:a) cout<<xx<<" "; cout<<endl;
    ll m=a.size();
    vector<ll> b;
    //cout<<"kroz b ";
    for(int i=0;i+1<m;i+=2)
    {
        //cout<<i<<" ";
        b.pb(Try(a[i],a[i+1]));
    }
    //cout<<endl;
    if(m&1) b.pb(a[m-1]);
    return b;
}
int main()
{
    //ios::sync_with_stdio(false); cin.tie(0);
    cin>>n;
    vector<ll> a;
    for(int i=1;i<=n;i++) a.pb(i);
    while(a.size()>1)
    {
        vector<ll> b=Solve(a);
        a=b;
    }
    ll x=a[0];
    for(int i=1;i<=n;i++) h[i]=Query(x,i);
    cout<<"!";
    for(int i=1;i<=n;i++) cout<<" "<<h[i];
    cout<<endl;
    return 0;
}
