#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
typedef long long int lint;

bool sledeci(vector<int>& b){
	bool sve1 = true;
	for(int i = 0; i < b.size(); i++){
		if(b[i] == 0){
			sve1 = false;
		}
	}
	if(sve1){
		return false;
	}
	for(int i = 0; i < b.size(); i++){
		if(b[i] == 0){
			b[i] = 1;
			break;
		}
		else{
			b[i] = 0;
		}
	}
	return true;
}

bool zad(vector<int> b, int k){
	int suma = 0;
	for(int i = 0; i < b.size(); i++){
		if(b[i] == 1){
			suma++;
		}
	}
	if(suma <= k){
		return true;
	}
	return false;
}

int med(set<int>& a, int n){
	set<int> b;
	for(int i = 0; i < n; i++){
		b.insert(i);
	}
	for(int x : a){
		b.erase(x);
	}
	vector<int> c;
	for(int x : b){
		c.push_back(x);
	}
	if((c.size() % 2) == 0){
		return (c[c.size() / 2] + 1);
	}
	else{
		return (c[c.size() / 2] + 1);
	}
}

void solve(){
	int n, m, k;
	cin >> n >> m >> k;
	vector<int> s(n);
	for(int i = 0; i < n; i++){
		cin >> s[i];
		s[i]--;
	}
	vector<int> p(m);
	vector<vector<int>> graf(m);
	for(int i = 1; i < m; i++){
		cin >> p[i];
		p[i]--;
		graf[i].push_back(p[i]);
		graf[p[i]].push_back(i);
	}
	if((n <= 16) && (m <= 16)){
		vector<set<int>> skup(m);
		for(int i = 0; i < n; i++){
			if(s[i] != -1){
				skup[s[i]].insert(i);	
			}
		}
		queue<int> red;
		for(int i = 1; i < m; i++){
			if((graf[i].size() == 1)){
				red.push(i);
			}
		}
		while(!red.empty()){
			int node = red.front();
			red.pop();
			if(node != 0){
				for(int x : skup[node]){
					skup[p[node]].insert(x);
				}
				red.push(p[node]);
			}
		}
		vector<int> b(m, 0);
		int mini = INT_MAX;
		set<int> random111;
		mini = min(mini, med(random111, n));
		while(sledeci(b)){
			if(zad(b, k)){
				set<int> sk;
				for(int i = 0; i < b.size(); i++){
					if(b[i] == 1){
						for(int x : skup[i]){
							sk.insert(x);
						}
					}
				}
				mini = min(mini, med(sk, n));
			}
		}
		cout << mini << endl;
	}
}   
 


signed main(){
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}   
