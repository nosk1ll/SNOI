#include <bits/stdc++.h>
using namespace std;
#define nl '\n'
#define f first
#define s second
#define ar array
#define me memset
#define ins insert
#define mp make_pair
#define pb push_back
#define ll long long
#define ldb long double
typedef pair<int, int> pl;
typedef vector<int> vi;
typedef vector<int> vl;
typedef vector<pl> vpl;
typedef pair<int, int> pi;
typedef vector<pi> vpi;
#define sz(x) (int)(x).size()
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
const int N=1e5+10;

int n, q, a[N];

int32_t main () {
    ios::sync_with_stdio(false), cin.tie(0);

    cin >> n >> q;
	if (max(n, q)<=1000) {
		for (int i=0; i<n; i++) 
			cin >> a[i]; 
		while (q--) {
			int tp; cin >> tp;
			if (tp==1) {  
				vi v;
				int l, r; cin >> l >> r;
				l--, r--; 
				for (int i=l; i<=r; i++) 
					v.pb(a[i]);  
				ll res=1;
				sort(all(v));
				for (int i=0; i<sz(v)&&res>=v[i]; i++) 
					res+=v[i];
				cout << res << nl; 	
			}
			else if (tp==2) {
				int i, x; cin >> i >> x;
				i--;
				a[i]=x;	
			}
		}
	} 
		
	return 0;
}
