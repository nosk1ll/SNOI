#include <bits/stdc++.h>
#define int long long
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define fi first
#define sc second
#define endl "\n"
#define pii pair<int,int>

using namespace std;

const int MAXN = 1e5+5;
const int mod7 = 1e9+7;
const long long inf = 1e18;

vector<vector<int>> graf(MAXN);

signed main()
{
    ios_base::sync_with_stdio(false),cin.tie(0), cout.tie(0);
    int tt=1;
    //cin >> tt;
    while(tt--)
    {
        int n,m,k;
        cin >> n >> m>> k;
        vector<int> niz(n);
        vector<int> parent(m+1,-1);
        for(int i=0; i<n; i++)cin >> niz[i];
        bool subtask2 = true;
        bool subtask1 = false;
        if(m<=16 && n<=16)subtask1 = true;
        for(int i=2; i<=m; i++)
        {
            int x;
            cin >> x;
            parent[i] = x;
            if(x != i-1)subtask2 = 0;
            graf[i].pb(x);
            graf[x].pb(i);
        }

        if(subtask1)
        {

            int mn = INT_MAX;
           for(int mask = 0; mask<(1<<m); mask++)
           {

               vector<bool> marked(m+1, false);
               vector<int> resenje;
               if(__builtin_popcount(mask) > k)continue;

               for(int j=0; j<m; j++)if(mask&(1<<j))marked[j+1] = 1;
                for(int i=0; i<n; i++)
                {
                    if(niz[i] == 0)
                    {
                        resenje.pb(i+1);
                         continue;
                    }
                    int tr = niz[i];
                    bool dodaj = true;

                    while(tr!=-1)
                    {
                        if(marked[tr])
                        {
                            dodaj = 0;
                            break;
                        }
                        tr = parent[tr];
                    }

                    if(dodaj)resenje.pb(i+1);
                }
                sort(all(resenje));
                int a = resenje.size();
                mn = min(mn, resenje[a/2]);
           }
           cout <<mn << endl;
        }

    }
}
