#include <bits/stdc++.h>

using namespace std;

int n,b,m,c,b1,b2,A[200];

int main()
{
    scanf("%d",&n);
    for(int i=2; i<=n; i++)
    {
        printf("? %d 1\n",i);
        fflush(stdout);
        scanf("%d",&b);
        if(b>m)
        {
            m = b;
            c = i;
        }
    }
    if(c!=2)
    {
        printf("? 1 2\n");
        fflush(stdout);
        scanf("%d",&b1);
        printf("? %d 2\n",c);
        fflush(stdout);
        scanf("%d",&b2);
        if(b1>b2)
        {
            c = 1;
            A[2] = b1;
        }
        else A[2] = b2;
    }
    else
    {
        printf("? 1 3\n");
        fflush(stdout);
        scanf("%d",&b1);
        printf("? %d 3\n",c);
        fflush(stdout);
        scanf("%d",&b2);
        if(b1>b2)
        {
            c = 1;
            A[3] = b1;
        }
        else A[3] = b2;
    }
    for(int i=1; i<=n; i++)
    {
        if(A[i]) continue;
        printf("? %d %d\n",c,i);
        fflush(stdout);
        scanf("%d",&A[i]);
    }
    printf("! ");
    for(int i=1; i<=n; i++) printf("%d ",A[i]);
    printf("\n");
    fflush(stdout);
    return 0;
}
