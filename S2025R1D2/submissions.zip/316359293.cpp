#include <bits/stdc++.h>
//#define endl '\n'
using namespace std;
typedef long long int lint;

int keri(int i, int j){
	cout << "? " << i << " " << j << endl;
	int h;
	cin >> h;
	return h;
}

map<pair<int, int>, int> mapa;

int q(int i, int j){
	if(mapa[{i, j}] == 0){
		mapa[{i, j}] = keri(i, j);
	}
	return mapa[{i, j}];
}

void solve(){
	int n;
	cin >> n;
	vector<int> h(n + 1);
	int maxi = 0;
	for(int i = 2; i <= n; i++){
		maxi = max(maxi, q(i, 1));
	}
	int x;
	for(int i = 2; i <= n; i++){
		if(q(i, 1) == maxi){
			x = i;
			break;
		}
	}
	int y;
	if((x == n)){	
		y = n - 1;
	}
	else{
		y = n;
	}
	if(q(1, y) >= q(x, y)){
		for(int i = 1; i <= n; i++){
			h[i] = q(1, i);
		}
	}
	else{
		for(int i = 1; i <= n; i++){
			h[i] = q(x, i);
		}
	}
	cout << "! ";
	for(int i = 1; i <= n; i++){
		cout << h[i] << " ";
	}
	cout << endl;
}   
 


signed main(){
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}   
