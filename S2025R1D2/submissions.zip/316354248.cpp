#include <bits/stdc++.h>
using namespace std;
const int MAXN = 2e5+5;

int ask(int i, int j){
    cout << i << ' ' << j << endl;
    cin >> i;
    return i;
}

int n;
int ans[MAXN];

void solve(){
    cin >> n;
    int m = 0, o = 1;
    for(int i = 2; i <= n; ++i){
        int t = ask(i,1);
        if(t > m){
            m = t;
            o = i;
        }
    }
    int k = 2+(m==2), h;
    int v1 = ask(1,k), v2 = ask(o,k);
    if(v1 > v2) h = 1;
    else h = o;
    ans[k] = max(v1,v2);
    for(int i = 1; i <= n; ++i){
        if(i==k) continue;
        ans[i] = ask(h,i);
    }
    cout << "! ";
    for(int i = 1; i <= n; ++i){
        cout << ans[i] << ' ';
    }
    cout << endl;
}

int32_t main(){
    //ios_base::sync_with_stdio(0); cin.tie(0);
    int32_t qqq=1;
    //cin >> qqq;
    while(qqq--)solve();
    return 0;
}