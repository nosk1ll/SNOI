#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 2005;
const ll maxm = 200005;
ll n,m,k;
vector<ll> g[maxn];
vector<ll> v[maxn];
ll c[maxn];
ll t = maxn;
ll dp[maxn][2*maxn];
ll sub[maxn];
ll sz[maxn];
ll x;
ll cur[2*maxn];
void dfs(ll u) {
	sub[u] = 0;
	for(ll c : v[u]) {
		if(c<=x) sub[u]--;
		else sub[u]++;
	}
	sz[u] = 0;
	dp[u][t] = 0;
	for(ll s : g[u]) {
		dfs(s);
		sub[u]+=sub[s];
	}
	for(ll s : g[u]) {
		for(ll i = -sz[u];i<=sz[u];i++) cur[t+i] = dp[u][t+i];
		for(ll i = -sz[u];i<=sz[u];i++) {
			for(ll j = -sz[s];j<=sz[s];j++) {
				dp[u][t+i+j] = min(dp[u][t+i+j],cur[t+i]+dp[s][t+j]);
			}
		}
		sz[u]+=sz[s];
	}
	sz[u]+=si(v[u]);
	dp[u][sub[u]+t] = min(dp[u][sub[u]+t],1LL);
	//cerr<<"u: "<<u<<" "<<sub[u]<<endl;
	//ceri(dp[u],t-m,t+m);
}
bool check() {
	for(ll i = 1;i<=n;i++) {
		for(ll j = -m;j<=m;j++) dp[i][j+t] = n+1;
	}
	//here;
	//dbg(x);
	dfs(1);
	ll uk = 0;
	for(ll i = 1;i<=m;i++) {
		if(i<=x) uk--;
		else uk++;
	}
	//ceri(dp[1],t-m,t+m);
	for(ll i = uk+1;i<=m;i++) if(dp[1][i+t]<=k) return 1;
	return 0;
}
int main(){
	ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
	cin >> m >> n >> k;
	if(m>2000) return 0;
	for(ll i = 1;i<=m;i++) {
		cin >> c[i];
		v[c[i]].pb(i);
	}
	for(ll i = 2;i<=n;i++) {
		ll x; cin >> x;
		g[x].pb(i);
	}
	ll tl = 1,tr = n,mid,rez = -1;
	while(tl<=tr) {
		ll mid = (tl+tr)/2;
		x = mid;
		if(check()) rez = mid,tr = mid-1;
		else tl = mid+1;
	}
	cout<<rez<<endl;
	return (0-0);
}