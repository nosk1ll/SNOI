#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 5;
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, q;
    cin >> n >> q;
    int a[n+1], P[21][n+1];
    for (int i = 1; i <= 20; ++i)   fill(P[i], P[i]+n+1, 0);
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
        P[i][a[i]]++;
    }
    for (int B = 1; B <= 20; ++B) {
        for (int i = 2; i <= n; ++i)    P[B][i] += P[B][i-1];
    }
    while (q--) {
        int t;
        cin >> t;
        if (t == 1) {
            int l, r;
            cin >> l >> r;
            int S = 0, R = 1;
            while (R <= min(S+1, 20)) {
                S += (P[R][r] - P[R][l-1]) * R;
                ++R;
            }
            cout << S+1 << '\n';
        }
    }
}