#include <bits/stdc++.h>

using namespace std;

const int inf = 1e9 + 5;
const int max_n = 1e5 + 5;
const int max_d = 31;
int tree[max_d][4 * max_n];
long long int ftree[max_d][max_n];
int n, q;


int largest_b(int num){
    int ans = -1;
    while (num != 0){
        num >>= 1;
        ans++;
    }
    return ans;
}


void init(int node, int l, int r){
    for (int b = 0; b < max_d; b++) tree[b][node] = inf;
    if (l != r){
        int mid = l + (r - l) / 2;
        init(node * 2, l, mid);
        init(node * 2 + 1, mid + 1, r);
    }
}


void update(int node, int l, int r, int p, int val, int b){
    if (p < l || r < p) return;
    if (l == r) tree[b][node] = val;
    else{
        int mid = l + (r - l) / 2;
        update(node * 2, l, mid, p, val, b);
        update(node * 2 + 1, mid + 1, r, p, val, b);
        tree[b][node] = min(tree[b][node * 2], tree[b][node * 2 + 1]);
    }
}


int query(int node, int l, int r, int ql, int qr, int b){
    if (qr < l || r < ql) return inf;
    if (ql <= l && r <= qr) return tree[b][node];
    int mid = l + (r - l) / 2;
    return min(query(node * 2, l, mid, ql, qr, b), query(node * 2 + 1, mid + 1, r, ql, qr, b));
}


void f_update(int p, int delta, int b){
    for (int i = p; i < n; i |= (i + 1)) ftree[b][i] += delta;
}


long long int pref(int r, int b){
    long long int ans = 0;
    for (int i = r; i >= 0; i = (i & (i + 1)) - 1) ans += ftree[b][i];
    return ans;
}


long long int f_query(int l, int r, int b){
    long long int ans = pref(r, b);
    if (l != 0) ans -= pref(l - 1, b);
    return ans;
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin >> n >> q;
    init(1, 0, n - 1);
    vector<int> nums(n);
    for (int i = 0; i < n; i++){
        cin >> nums[i];
        int lb = largest_b(nums[i]);
        update(1, 0, n - 1, i, nums[i], lb);
        f_update(i, nums[i], lb);
    }
    int t, a, b, lb_new, lb_old;
    while (q--){
        cin >> t >> a >> b;
        if (t == 1){
            a--;
            b--;
            long long int total = 0;
            for (int cb = 0; cb < max_d; cb++){
                int c_min = query(1, 0, n - 1, a, b, cb);
                // cout << c_min << endl;
                if (c_min != inf){
                    if (total + 1 >= c_min){
                        total += f_query(a, b, cb);
                    }
                    else{
                        break;
                    }
                }
            }
            cout << total + 1 << endl;
        }
        else{
            a--;
            lb_new = largest_b(b);
            lb_old = largest_b(nums[a]);
            update(1, 0, n - 1, a, inf, lb_old);
            f_update(a, -nums[a], lb_old);
            update(1, 0, n - 1, a, b, lb_new);
            f_update(a, b, lb_new);
            nums[a] = b;
        }
    }
    return 0;
}
/*
5 12
1 2 3 4 5
1 1 5
2 1 2
1 1 5
*/
