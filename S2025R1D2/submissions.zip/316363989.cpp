#define here cerr<<"===========================================\n"
#define dbg(x) cerr<<#x<<": "<<x<<endl;
#include <bits/stdc++.h>
#define llinf 100000000000000000LL // 10^17
#define iinf 2000000000 // 2*10^9
#define pb push_back
#define eb emplace_back
#define popb pop_back
#define fi first
#define sc second
#define endl '\n'
#define all(a) a.begin(),a.end()
#define ceri(a,l,r) {cerr<<#a<<": ";for(ll i_ = l;i_<=r;i_++) cerr<<a[i_]<< " ";cerr<<endl;}
#define cer(a) {cerr<<#a<<": ";for(ll x_ : a) cerr<<x_<< " ";cerr<<endl;}
#define si(a) (ll)(a.size())
using namespace std;
using ld = long double;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using pld = pair<ld,ld>;

const ll maxn = 2005;
const ll maxm = 200005;
ll n,m,k;
vector<ll> g[maxm];
vector<ll> v[maxn];
ll c[maxm];
ll t = maxn;
ll dp[maxn][maxn];
ll sub[maxn];
ll sz[maxn];
ll x;
ll cur[maxn];
void dfs(ll u) {
	sub[u] = 0;
	for(ll c : v[u]) {
		if(c<=x) sub[u]--;
		else sub[u]++;
	}
	sz[u] = 0;
	dp[u][0] = 0;
	for(ll s : g[u]) {
		dfs(s);
		sub[u]+=sub[s];
	}
	for(ll s : g[u]) {
		for(ll i = 0;i<=sz[u];i++) cur[i] = dp[u][i];
		for(ll i = 0;i<=sz[u];i++) {
			for(ll j = 0;j<=sz[s];j++) {
				if(abs(i+j)<=n) dp[u][i+j] = max(dp[u][i+j],cur[i]+dp[s][j]);
			}
		}
		sz[u]+=sz[s];
	}
	sz[u]++;
	dp[u][1] = max(dp[u][1],sub[u]);
}
bool check() {
	ll uk = 0;
	for(ll i = 1;i<=m;i++) {
		if(i<=x) uk--;
		else uk++;
	}
	for(ll i = 1;i<=n;i++) {
		for(ll j = 0;j<=n;j++) dp[i][j] = -m-1;
	}
	dfs(1);
	for(ll i = 0;i<=k;i++) if(dp[1][i]>uk) return 1;
	return 0;
}
int main(){
	ios_base::sync_with_stdio(false);cerr.tie(0);cout.tie(0);cin.tie(0);
	cin >> m >> n >> k;
	for(ll i = 1;i<=m;i++) {
		cin >> c[i];
		v[c[i]].pb(i);
	}
	for(ll i = 2;i<=n;i++) {
		ll x; cin >> x;
		g[x].pb(i);
	}
	ll tl = 1,tr = m,mid,rez = -1;
	while(tl<=tr) {
		ll mid = (tl+tr)/2;
		x = mid;
		if(check()) rez = mid,tr = mid-1;
		else tl = mid+1;
	}
	cout<<rez<<endl;
	return (0-0);
}