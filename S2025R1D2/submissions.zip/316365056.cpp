#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define PI acos(-1)
#define LSB(i) ((i) & -(i))
#define ll long long
#define pb push_back
#define mp make_pair
#define mt make_tuple
#define fi first
#define sc second
#define th third
#define fo fourth
#define pii pair<int,int>
#define pll pair<ll,ll>
#define ldb double
#define INF 1e15
#define MOD 1000000007
#define endl "\n"

#define all(data)       data.begin(),data.end()
#define TYPEMAX(type)   std::numeric_limits<type>::max()
#define TYPEMIN(type)   std::numeric_limits<type>::min()
#define MAXN 207
ll h[MAXN];
ll n;
ll Query(ll i,ll j)
{
    cout<<"? "<<i<<" "<<j<<endl;
    ll x; cin>>x; return x;
}
int main()
{
    //ios::sync_with_stdio(false); cin.tie(0);
    cin>>n;
    vector<ll> a;
    for(int i=1;i<=n;i++) a.pb(i);
    ll i=1,x=Query(1,n),idx=n;
    for(int j=2;j<n;j++)
    {
        ll y=Query(j,n);
        if(x<y) {i=j; x=y; idx=n;}
    }
    ll k;
    for(int l=1;l<=n;l++)
    {
        if(l!=i && l!=n) {k=l; break;}
    }
    ll ik=Query(i,k),nk=Query(n,k);
    if(ik>=nk)
    {
        for(int j=1;j<=n;j++)
        {
            if(j==n) h[j]=x;
            else if(j==k) h[j]=ik;
            else h[j]=Query(i,j);
        }
    }
    else
    {
        for(int j=1;j<=n;i++)
        {
            if(j==k) h[j]=nk;
            else h[j]=Query(n,j);
        }
    }
    cout<<"!";
    for(int i=1;i<=n;i++) cout<<" "<<h[i];
    cout<<endl;
    return 0;
}
