#include <bits/stdc++.h>

using namespace std;

const int inf = 1e9 + 5;
const int max_n = 1e5 + 5;
const int max_m = 1e2 + 5;
vector<int> adjs[max_m], elements[max_m];
int home_node[max_n];
int n, m, k;


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int v;
    cin >> n >> m >> k;
    vector<int> s(n + 1), bad;
    for (int i = 1; i <= n; i++){
        cin >> home_node[i];
        if (home_node[i] == 0) bad.push_back(i);
        else elements[home_node[i]].push_back(i);
    }
    for (int i = 2; i <= m; i++){
        cin >> v;
        adjs[v].push_back(i);
        adjs[i].push_back(v);
    }
    int low = 1, high = n, g = n + 2, g_ans = n + 1;
    while (g--){
        // int g = low + (high - low) / 2;
        int bad_balance = 0;
        bool found_g = false;
        for (int elm : bad){
            if (elm > g) bad_balance++;
            else bad_balance--;
            if (elm == g) found_g = true;
        }
        int total = bad_balance;
        int best_total = bad_balance;
        bool good = false;
        int len = bad.size();
        for (int i = 1; i <= m; i++){
            for (int elm : elements[i]){
                if (elm > g) total++;
                else total--;
                if (elm == g) found_g = true;
            }
            len += elements[i].size();
            best_total = min(best_total, total);
            if (found_g) if (total < 0 || (total == 0 && len % 2 != 0)) good = true;
        }
        // if (best_total < 0) high = g - 1;
        // else low = g + 1;
        if (good) g_ans = min(g_ans, g);
    }
    cout << g_ans << endl;
    return 0;
}
/*

*/
