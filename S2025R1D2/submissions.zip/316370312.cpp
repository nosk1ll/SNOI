#include<bits/stdc++.h>

using namespace std;

#define ubrzaj ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);

int main(){
ubrzaj

int iN;
if(!(cin>>iN))return 0;
vector<int> aiResp(iN+1), aiResp2(iN+1);
int iC1=2;
for(int i=2;i<=iN;i++){
 cout<<"?"<<i<<' '<<1<<endl;
 cin>>aiResp[i];
}
for(int i=3;i<=iN;i++)if(aiResp[i]>aiResp[iC1])iC1=i;
int iC2=(1!=2?1:3);
for(int i=1;i<=iN;i++)if(i!=2){
 cout<<"?"<<i<<' '<<2<<endl;
 cin>>aiResp2[i];
}
for(int i=1;i<=iN;i++)if(i!=2&&aiResp2[i]>aiResp2[iC2])iC2=i;
int iT;
if(iC1==iC2)iT=iC1;
else if(iC1==2)iT=iC1;
else if(iC2==1)iT=iC2;
else iT=iC1;
vector<int> aiH(iN+1);
for(int j=1;j<=iN;j++){
 cout<<"?"<<iT<<' '<<j<<endl;
 cin>>aiH[j];
}
cout<<"!";
for(int i=1;i<=iN;i++)cout<<' '<<aiH[i];
cout<<endl;
return 0;
}
