#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define ios ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define pb push_back
using namespace std;
using namespace __gnu_pbds;
typedef tree<pair<int,int>, null_type, less<pair<int,int>>, rb_tree_tag, tree_order_statistics_node_update> os;
typedef unsigned long long ull;
typedef long long ll;
void rte(){
    int* a = nullptr;
    int b = *a;
}
int upit(int i, int j){
    cout<<"? "<<i<<" "<<j<<endl;
    int visina;
    cin>>visina;
    return visina;
}
int main(){
    int n;
    cin>>n;
    vector<pair<int,int>> a;
    for(int i = 1;i<=n;i++){
        int visina = upit(i, n);
        a.push_back({visina, i});
    }
    sort(a.begin(), a.end());
    if(a[n-1].first==a[n-2].first){
        int x = 1/0;
        vector<int> res(n);
        for(int i = 1;i<=n;i++){
            int visina = upit(n, i);
            res[i-1]=visina;
        }
        cout<<"! ";
        for(int x : res)cout<<x<<" ";
        cout<<endl;
    }
    else{
        vector<int> res(n);
        int v1 = 0, v2 = 0;
        v1 = upit(a[n-1].second, n-1);
        v2 = upit(a[n-2].second, n-1);
        if(v1>v2){
            int x = 1/0;
            res[n-1]=a[n-1].first;
            res[n-2]=v1;
            for(int i = n-2;i>=1;i--){
                res[i-1]=upit(a[n-1].second, i);
            }
        }
        else{
            rte();
            res[n-1]=a[n-2].first;
            res[n-2]=v2;
            for(int i = n-2;i>=1;i--){
                int visina = upit(a[n-2].second, i);
                res[i-1]=visina;
            }
        }
        cout<<"! ";
        for(int x : res)cout<<x<<" ";
        cout<<endl;
 
    }
}