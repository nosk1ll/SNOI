#include <bits/stdc++.h>

using namespace std;

int n,m,k,b;
long long U[2010][2010];
vector<int> V[2010],G[2010];

void st(int x,int y)
{
    for(int i=0; i<V[x].size(); i++) st(V[x][i],y);
    U[x][0] = 0;
    for(int i=0; i<V[x].size(); i++) U[x][0] += U[V[x][i]][0];
    for(int i=0; i<G[x].size(); i++)
    {
        if(G[x][i]<=y) U[x][0]--;
        else U[x][0]++;
    }
    for(int i=1; i<=k; i++) U[x][i] = U[x][0];
    for(int i=0; i<V[x].size(); i++)
    {
        for(int j=k; j>=0; j--)
        {
            for(int o=k-j; o>0; o--) U[x][j+o] = min(U[x][j+o],U[x][j]+U[V[x][i]][o]-U[V[x][i]][0]);
        }
    }
    if(x) U[x][1] = min(U[x][1],0ll);
    return;
}

int main()
{
    scanf("%d %d %d",&n,&m,&k);
    for(int i=1; i<=n; i++)
    {
        scanf("%d",&b);
        G[b].push_back(i);
    }
    for(int i=2; i<=m; i++)
    {
        scanf("%d",&b);
        V[b].push_back(i);
    }
    V[0].push_back(1);
    int l=0,r=m;
    while(l+1<r)
    {
        int s = (l+r)/2;
        st(0,s);
        long long g = 1e9;
        for(int i=0; i<=k; i++) g = min(g,U[0][i]);
        if(g<=-1) r = s;
        else l = s;
    }
    printf("%d\n",r);
    return 0;
}
