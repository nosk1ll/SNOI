/// 407!3 +/ \!<07!\*
#include <bits/stdc++.h>
#pragma GCC optimize ("O3")
#pragma GCC target ("sse4")

using namespace std;

using ll = long long;
using db = long double; // or double, if TL is tight
using str = string; // yay python!

using pi = pair<int,int>;
using pl = pair<ll,ll>;
using pd = pair<db,db>;

using vi = vector<int>;
using vb = vector<bool>;
using vl = vector<ll>;
using vd = vector<db>;
using vs = vector<str>;
using vpi = vector<pi>;
using vpl = vector<pl>;
using vpd = vector<pd>;
using vvi = vector<vi>;
using vvl = vector<vl>;
using vvpi = vector<vpi>;

template<class T> using pq = priority_queue<T>;
template<class T> using pqg = priority_queue<T, vector<T>, greater<T>>;

// pairs
#define mp make_pair
#define f first
#define s second

// vectors
#define sz(x) int((x).size())
#define bg(x) begin(x)
#define all(x) bg(x), end(x)
#define rall(x) x.rbegin(), x.rend()
#define sor(x) sort(all(x))
#define rsz resize
#define ins insert
#define ft front()
#define bk back()
#define pb push_back
#define eb emplace_back
#define pf push_front
#define er erase
#define ub upper_bound
#define lb lower_bound

// loops
#define FOR(i,a,b) for (ll i = (a); i < (b); ++i)
#define F0R(i,a) FOR(i,0,a)
#define ROF(i,a,b) for (ll i = (b)-1; i >= (a); --i)
#define R0F(i,a) ROF(i,0,a)
#define trav(a,x) for (auto& a: x)

const int MOD = 1e9+7; // 998244353;
const int MX = 2e5+5;
const ll INF = 1e18; // not too close to LLONG_MAX
const db PI = acos((db)-1);
const int dx[4] = {1,0,-1,0}, dy[4] = {0,1,0,-1}; // for every grid problem!
const char nl = '\n';

template<class T> bool ckmin(T& a, const T& b) { return b < a ? a = b, 1 : 0; }
template<class T> bool ckmax(T& a, const T& b) { return a < b ? a = b, 1 : 0; }

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}

template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ", "; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? ", " : ""), __print(i); cerr << "}\n";}
void _print() {cerr << "\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;

template<typename T>
using indexed_set =  tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define ook order_of_key
#define fbo find_by_order

void _input() {return;}
template <typename T, typename... V>
void _input(T &t, V&... v) {cin >> (t); if (sizeof...(v))  _input(v...);}
void __input(vi &v, const int n){F0R(i, n)cin >> v[i];}
void __input(vvi &v, const int n, const int m){F0R(i, n)F0R(j, m)cin>>v[i][j];}

ll binpow(ll a, ll b) {
    ll res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a;
        a = a * a;
        b >>= 1;
    }
    return res;
}

struct Qry { ll tp, x, y, z;};

// BIT
struct Fenwick {
    ll n;
    vl f;
    Fenwick() {}
    Fenwick(ll _n): n(_n), f(n + 1, 0) {}
    void update(ll i, ll v) {
        for (; i <= n; i += i & -i) f[i] += v;
    }
    ll query(ll i) const {
        ll s = 0;
        for (; i > 0; i -= i & -i) s += f[i];
        return s;
    }
};

struct Fenwick2d {
    ll n;
    vvl c;
    // bits[i] - Fenvikovo na Fenvikovom
    vector<Fenwick> bits;
    Fenwick2d(ll _n): n(_n), c(n + 1) {}

    void fupdate(ll pos, ll val) {
        for (ll i = pos; i <= n; i += i & -i) c[i].pb(val);
    }

    void init() {
        bits.resize(n+1);
        FOR(i, 1, n + 1) {
            sor(c[i]);
            c[i].er(unique(all(c[i])), end(c[i]));
            bits[i] = Fenwick(sz(c[i]));
        }
    }

    void update(ll pos, ll val, ll dt) {
        for (ll i = pos; i <= n; i += i & -i) {
            ll idx = lb(all(c[i]), val) - bg(c[i]) + 1;
            bits[i].update(idx, dt);
        }
    }

    ll query(ll pos, ll val) const {
        ll s = 0;
        for (ll i = pos; i > 0; i -= i & -i) {
            ll idx = ub(all(c[i]), val) - bg(c[i]);
            s += bits[i].query(idx);
        }
        return s;
    }

    ll range_query(ll l, ll r, ll val) const {
        return query(r, val) - query(l - 1, val);
    }
};

ll mex(ll l, ll r, vl& av, Fenwick2d& ds){
    ll reach = 0;
    while (true) {
        ll idx = ll(ub(all(av), reach + 1) - bg(av));
        if (!idx) break;
        ll s = ds.range_query(l, r, idx);
        if (s == reach) break;
        reach = s;
    }
    return reach + 1;
}

void solve(){
    ll n, q;
    cin >> n >> q;
    vl a(n + 1);
    FOR(i, 1, n + 1)cin >> a[i];
    vector<Qry> qs(q);
    vl av(n);
    F0R(i, n) av[i] = a[i + 1];

    F0R(i, q) {
        cin >> qs[i].tp;
        if (qs[i].tp == 1) cin >> qs[i].x >> qs[i].y;
        else {
            cin >> qs[i].x >> qs[i].z;
            av.pb(qs[i].z);
        }
    }
    sor(av);
    av.er(unique(all(av)), end(av));

    Fenwick2d ds(n);
    FOR(i, 1, n + 1) ds.fupdate(i, lb(all(av), a[i]) - bg(av) + 1);
    trav(qr, qs){
        if(qr.tp == 1)continue;
        ds.fupdate(qr.x, lb(all(av), qr.z) - bg(av) + 1);
    }
    ds.init();
    FOR(i, 1, n + 1) ds.update(i, lb(all(av), a[i]) - bg(av) + 1, a[i]);

    trav(qr, qs){
        if(qr.tp == 1) cout << mex(qr.x, qr.y, av, ds) << nl;
        else {
            ll pos = qr.x;
            ll old = a[pos];
            ll nw  = qr.z;
            ds.update(pos, lb(all(av), old) - bg(av) + 1, -old);
            ds.update(pos, lb(all(av), nw) - bg(av) + 1, +nw);
            a[pos] = nw;
        }
    }
}


/*

*/

int main()
{
    ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    ll t; t = 1;while(t--){
        solve();
    }
    return 0;
}

