#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void DBG() { cerr << "]" << endl; }
template<class H, class... T> void DBG(H h, T... t) { cerr << to_string(h); if(sizeof...(t)) cerr << ", "; DBG(t...); }
#define dbg(...) cerr << "[" << #__VA_ARGS__ << "]: [", DBG(__VA_ARGS__)

const int N = 103;
const int inf = 1e9;
int h[N];

int ask(int i, int j) {
    cout << i << " " << j << "\n";
    cout.flush();
    int x; cin >> x;
    return x;
}

void solve() {
    int n; cin >> n;
    int mx = -inf, ind = -1;
    for (int i = 2; i <= n; i++) {
        int v = ask(i, 1);
        if (mx == -inf) {
            ind = i; mx = v;
        } else if (v > mx) {
            ind = i; mx = v;
        }
    }
    int p = 2;
    if (ind == p) p++;

    int gut=ind;
    int v1 = ask(1, p), v2 = ask(ind, p);
    if (v1 >= v2)
        gut = 1;
    else
        gut = ind;

    for (int i = 1; i <= n; i++)
        h[i] = ask(gut, i);

    cout << "! ";
    cout.flush();
    for (int i = 1; i <= n; i++) {
        cout << h[i] << " " << flush;
    }
    cout << "\n";
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(0);
	int t=1; //cin >> t;
	while (t--) {
        solve();
	}
}
