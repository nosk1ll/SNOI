#include <bits/stdc++.h>



void solve() {
  int n;
  std::cin >> n;
  std::function<int(int, int)> ask = [&] (int x, int y) {
    std::cout << "? " << x << " " << y << std::endl;
    int r;
    std::cin >> r;
    return r;
  };
  std::vector<int> ask1(n + 1);
  std::vector<int> ask2(n + 1);
  std::vector<int> ans(n + 1);
  for(int i = 1; i <= n; i++) {
    ask1[i] = ask(i, 1);
  }
  /**
  ili je 1 il index "istina"
  **/
  int some = - 1;
  int mx = - 1;
  for(int i = 2; i <= n; i++) {
    mx = std::max(mx, ask1[i]);
  }
  for(int i = 2; i <= n; i++) {
    if(mx == ask1[i]) {
      some = i;
    }
  }
  /**
  ko laze some ili 1 lazu
  sada ako uzmes neki treci index ko kaze manje on je lazov
  **/
  int ath = - 1;
  for(int i = 2; i <= n; i++) {
    if(i == some) {
      continue;
    }
    ath = i;
    break;
  }
  if(ask(1, ath) >= ask(some, ath)) {
    for(int i = 1; i <= n; i++) {
      ans[i] = ask(1, i);
    }
  }
  else {
    for(int i = 1; i <= n; i++) {
      ans[i] = ask(some, i);
    }
  }
  std::cout << "! ";
  for(int i = 1; i <= n; i++) {
    std::cout << ans[i] << " ";
  }
}


int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);

  int t = 1;
  //std::cin >> t;
  while (t--) {
      solve();
  }

  return 0;
}

