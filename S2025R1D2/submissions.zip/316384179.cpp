#include <bits/stdc++.h>
using namespace std;
int N, M, K, sol = INT_MAX;
int I[200096];
vector <int> D[2006];
vector <int> VG[2006];
int DP[2006][2006];
int FROM[206][206][206];
inline void BRUTEDFS(bool *P, vector <int> &V, int node, int parent = 0)
{
  for(int x : D[node]) V.push_back(x);
  for(int x : VG[node]) if((x != parent) && !P[x]) BRUTEDFS(P, V, x, node);
  return;
}
inline void Brute()
{
  bool P[M + 1];
  vector <int> V;
  for(int i = 1; i < (1 << M); i++)
  {
    if(__builtin_popcount(i) > K) continue;
    for(int j = 0; j < M; j++) P[j + 1] = bool(i & (1 << j));
    V = D[0];
    if(!P[1]) BRUTEDFS(P, V, 1);
    sort(V.begin(), V.end());
    sol = min(V[V.size() >> 1], sol);
  }
  return;
}
int FT[200096];
inline void Add(int i, int X)
{
  for(; i <= N; i += i & (-i)) FT[i] += X;
  return;
}
inline int Sum(int i)
{
  int RET = 0;
  for(; i; i -= i & (-i)) RET += FT[i];
  return RET;
}
inline void Chain()
{
  int n = 0;
  auto BS = [&]()
  {
    int RET, L = 1, R = N, S;
    while(L <= R)
    {
      S = (L + R) >> 1;
      if(Sum(S) < ((n + 2) >> 1)) L = S + 1;
      else {R = S - 1; RET = S;}
    }
    return RET;
  };
  for(int i = 0; i <= M; i++)
  {
    n += D[i].size();
    for(int x : D[i]) Add(x, 1);
    sol = min(BS(), sol);
  }
  return;
}
int EDP[2006];
inline void EDFS(int X, int node, int parent = 0)
{
  for(int x : D[node])
  {
    if(x > X) EDP[node]--;
    else EDP[node]++;
  }
  for(int x : VG[node])
  {
    if(x == parent) continue;
    EDFS(X, x, node);
    if(EDP[x] > 0) EDP[node] += EDP[x];
  }
  return;
}
inline bool EOK(int X)
{
  memset(EDP, 0, sizeof(EDP));
  EDFS(X, 1);
  int temp = 0;
  for(int x : D[0])
  {
    if(x > X) temp--;
    else temp++;
  }
  return (temp + DP[1]) > 0;
}
inline void Equal()
{
  int L = 1, R = N, S;
  while(L <= R)
  {
    S = (L + R) >> 1;
    if(!EOK(S)) L = S + 1;
    else {R = S - 1; sol = S;}
  }
  return;
}
inline void DFS(int X, int node, int parent = 0)
{
  for(int x : D[node])
  {
    if(x > X) DP[0][node]--;
    else DP[0][node]++;
  }
  for(int x : VG[node])
  {
    if(x == parent) continue;
    DFS(X, x, node);
    DP[0][node] += DP[0][x];
    FROM[0][node][x] = 0;
  }
  for(int i = 1; i <= K; i++)
  {
    for(int x : VG[node])
    {
      if(x == parent) continue;
      for(int j = 1; j <= i; j++)
      {
        if((DP[i - j][node] + DP[j][x] - DP[FROM[i - j][node][x]][x]) > DP[i][node])
        {
          DP[i][node] = DP[i - j][node] + DP[j][x] - DP[FROM[i - j][node][x]][x];
          FROM[i][node][x] = j;
          for(int y : VG[node])
          {
            if((y == parent) || (y == x)) continue;
            FROM[i][node][y] = FROM[i - j][node][y];
          }
        }
      }
    }
  }
  return;
}
inline bool OK(int X)
{
  memset(DP, 0, sizeof(DP));
  memset(FROM, 0, sizeof(FROM));
  int temp = 0;
  for(int x : D[0])
  {
    if(x > X) temp--;
    else temp++;
  }
  DFS(X, 1);
  return (temp + DP[K][1]) > 0;
}
inline void BS()
{
  int L = 1, R = N, S;
  while(L <= R)
  {
    S = (L + R) >> 1;
    if(!OK(S)) L = S + 1;
    else {R = S - 1; sol = S;}
  }
  return;
}
int main()
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> N >> M >> K;
  for(int i = 1; i <= N; i++)
  {
    cin >> I[i];
    D[I[i]].push_back(i);
  }
  sol = D[0][D[0].size() >> 1]; ///ovo radi?
  bool doChain = true;
  for(int i = 2, j; i <= M; i++)
  {
    cin >> j;
    doChain &= j == (i - 1);
    VG[i].push_back(j);
    VG[j].push_back(i);
  }
  if((N <= 20) && (M <= 20)) Brute();
  else if(doChain) Chain();
  else if(K == M) Equal();
  else BS();
  cout << sol << '\n';

  return 0;
}
